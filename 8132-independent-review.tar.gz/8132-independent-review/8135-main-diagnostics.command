cargo test --locked -p ripr --lib gap_record_diagnostic
