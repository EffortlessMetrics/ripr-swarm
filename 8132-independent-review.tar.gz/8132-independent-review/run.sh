#!/bin/bash
set -u
label=$1
filter=$2
export PATH=/workspace/.cargo/bin:$PATH CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/scratch/review-target CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_BUILD_JOBS=3
base=/workspace/scratch/evidence-8132/$label
git rev-parse HEAD HEAD^{tree} > "$base.identity"
git diff > "$base.patch"
git add -N crates/ripr/src/output/gap_decision_ledger/review_matrix.rs 2>/dev/null || true
git diff > "$base.patch"
git add crates/ripr/src/output/gap_decision_ledger.rs crates/ripr/src/output/gap_decision_ledger/review_matrix.rs 2>/dev/null || true
git write-tree >> "$base.identity"
printf '%s\n' "cargo test --locked -p ripr --lib $filter -- --nocapture" > "$base.command"
cargo test --locked -p ripr --lib "$filter" -- --nocapture > "$base.log" 2>&1
rc=$?
echo "$rc" > "$base.exit"
tail -10 "$base.log"
exit "$rc"
