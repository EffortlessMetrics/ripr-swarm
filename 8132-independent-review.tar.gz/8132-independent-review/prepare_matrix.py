import pathlib,sys
out=pathlib.Path('/workspace/scratch/evidence-8132')
kind=sys.argv[1]
s=(out/'matrix-original.rs').read_text()
# Retain original stimulus and full-record oracles; adjudicate each candidate's permitted precision.
if kind=='8142':
 s=s.replace('expected_pytest_record(None)?','expected_pytest_record(Some(28))?')
 s=s.replace('record["repair_route"]["target_line"],\n        Value::Null,','record["repair_route"]["target_line"],\n        json!(28),')
 s=s.replace('let line = (total <= 8 && !namesake).then_some(selected_line as u64);','let line = (namesake || total <= 8).then_some(selected_line as u64);')
 s=s.replace('"nonobject-row" => {','"nonobject-row" => {')
 # This is an observed robustness policy difference, not an oracle requirement.
 s=s.replace('line = None;\n            }\n            _ => return Err("unknown review case"', 'line = Some(60);\n            }\n            _ => return Err("unknown review case"')
 marker='fn python_lossy_inventory_withholds_precision_for_complete_record()'
 a,b=s.split(marker)
 b=b.replace('None,\n                SECOND_COMMAND','if case == "over-total" { None } else { Some(60) },\n                SECOND_COMMAND')
 s=a+marker+b
s=s.replace('assert_eq!(\n                    actual, expected,','eprintln!("MATRIX early={early_count} first={selected_first} namesake={namesake} FINDING={} RECORD={}", finding, actual);\n                assert_eq!(\n                    actual, expected,')
s=s.replace('assert_eq!(\n            projected_record(&payload)?,','eprintln!("CONTROL case={case} FINDING={} RECORD={}", payload["findings"][0], projected_record(&payload)?);\n        assert_eq!(\n            projected_record(&payload)?,')
# The replacement above only appears inside loops with case; selected-first assertion has different indentation.
s += r'''

#[test]
fn review_evidence_and_corrupt_cap_observations() -> Result<(), String> {
    for case in ["valid-capped", "capped-absent-total-no-evidence", "capped-text-total-no-evidence", "capped-null-total-no-evidence", "capped-negative-total-no-evidence", "capped-fraction-total-no-evidence", "capped-under-total-no-evidence", "capped-duplicate-line-last25", "capped-duplicate-line-last28", "capped-duplicate-identical", "capped-duplicate-file-mismatch-last", "capped-duplicate-file-match-last", "capped-invalid-last-line", "capped-no-rows-valid-evidence", "complete-namesake-valid-evidence", "complete-unique-conflicting-evidence"] {
        let mut payload = if case == "complete-unique-conflicting-evidence" { check_output("tests/test_checkout.v2.py")? } else { capped_identity_output()? };
        let f=&mut payload["findings"][0];
        match case {
            "capped-absent-total-no-evidence" | "capped-text-total-no-evidence" | "capped-null-total-no-evidence" | "capped-negative-total-no-evidence" | "capped-fraction-total-no-evidence" | "capped-under-total-no-evidence" => {
                f["evidence"].as_array_mut().ok_or("evidence")?.retain(|x| !x.as_str().is_some_and(|x| x.starts_with("suggested_test_line:")));
                if case=="capped-absent-total-no-evidence" { f.as_object_mut().ok_or("finding")?.remove("related_tests_total"); }
                else { f["related_tests_total"] = match case { "capped-text-total-no-evidence" =>json!("9"), "capped-null-total-no-evidence" =>Value::Null, "capped-negative-total-no-evidence" =>json!(-1), "capped-fraction-total-no-evidence"=>json!(9.5), _=>json!(7)}; }
            },
            "capped-duplicate-line-last25" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_line: 25")),
            "capped-duplicate-line-last28" => f["evidence"].as_array_mut().ok_or("evidence")?.insert(0,json!("suggested_test_line: 25")),
            "capped-duplicate-identical" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_line: 28")),
            "capped-duplicate-file-mismatch-last" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_file: other.py")),
            "capped-duplicate-file-match-last" => f["evidence"].as_array_mut().ok_or("evidence")?.insert(0,json!("suggested_test_file: other.py")),
            "capped-invalid-last-line" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_line: invalid")),
            "capped-no-rows-valid-evidence" => {f.as_object_mut().ok_or("finding")?.remove("related_tests");},
            "complete-namesake-valid-evidence" => {payload=bounded_identity_output(5,false,true)?;},
            "complete-unique-conflicting-evidence" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_line: 99")),
            _=>{},
        }
        let record=projected_record(&payload)?;
        let observed=record["repair_route"]["target_line"].as_u64();
        let expected = EXPECTED;
        eprintln!("EXTRA case={case} FINDING={} RECORD={record}",payload["findings"][0]);
        assert_eq!(observed,expected,"observation case={case}");
        let full = if case=="complete-unique-conflicting-evidence" {expected_record("tests/test_plain.py",Some("test_same"),expected,SECOND_COMMAND)?} else {expected_pytest_record(expected)?};
        assert_eq!(record,full,"full record case={case}");
    }
    Ok(())
}
'''.replace('let expected = EXPECTED;', '''let expected = match case {
 "capped-absent-total-no-evidence" | "capped-text-total-no-evidence" | "capped-null-total-no-evidence" | "capped-negative-total-no-evidence" | "capped-fraction-total-no-evidence" | "capped-under-total-no-evidence" | "capped-duplicate-line-last25" => Some(25),
 "capped-duplicate-file-mismatch-last" | "capped-invalid-last-line" | "complete-unique-conflicting-evidence" => None,
 "complete-namesake-valid-evidence" => Some(22),
 _ => Some(28),
};''' if kind=='8142' else 'let expected = if case=="complete-unique-conflicting-evidence" {Some(60)} else {None};')
(out/f'matrix-{kind}.rs').write_text(s)
