#!/bin/bash
set -u
label=$1
export PATH=/workspace/.cargo/bin:$PATH CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/scratch/review-target CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_BUILD_JOBS=3
for filter in output::gap_decision_ledger related_tests::verify_command_tests gap_record_diagnostic; do
 suffix=${filter//::/-}
 base=/workspace/scratch/evidence-8132/$label-$suffix
 git rev-parse HEAD HEAD^{tree} > "$base.identity"
 printf '%s\n' "cargo test --locked -p ripr --lib $filter" > "$base.command"
 cargo test --locked -p ripr --lib "$filter" > "$base.log" 2>&1
 rc=$?
 echo "$rc" > "$base.exit"
 tail -3 "$base.log"
 if [ "$rc" -ne 0 ]; then exit "$rc"; fi
done
