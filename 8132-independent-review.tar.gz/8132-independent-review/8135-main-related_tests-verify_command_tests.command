cargo test --locked -p ripr --lib related_tests::verify_command_tests
