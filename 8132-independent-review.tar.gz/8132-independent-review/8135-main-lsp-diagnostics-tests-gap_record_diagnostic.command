cargo test --locked -p ripr --lib lsp::diagnostics::tests::gap_record_diagnostic
