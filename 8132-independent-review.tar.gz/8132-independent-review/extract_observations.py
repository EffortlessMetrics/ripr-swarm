import pathlib,re,json
p=pathlib.Path(__file__).parent
dec=json.JSONDecoder()
for n in ['8135','8142']:
 rows=[]
 for line in (p/f'{n}-matrix.log').read_text().splitlines():
  m=re.search(r'((?:MATRIX |CONTROL |EXTRA ).*?) FINDING=(.*?) RECORD=(.*)',line)
  if m:rows.append({'case':m[1],'finding':dec.raw_decode(m[2])[0],'record':dec.raw_decode(m[3])[0]})
 assert len(rows)==67,(n,len(rows))
 (p/f'{n}-observations.json').write_text(json.dumps(rows,indent=2)+'\n')
a={r['case']:r for r in json.loads((p/'8135-observations.json').read_text())}
b={r['case']:r for r in json.loads((p/'8142-observations.json').read_text())}
assert a.keys()==b.keys()
comparison=[]
for k in sorted(a):
 assert a[k]['finding']==b[k]['finding'],k
 comparison.append({'case':k,'8135_line':a[k]['record']['repair_route'].get('target_line'),'8142_line':b[k]['record']['repair_route'].get('target_line'),'identical_stimulus':True})
(p/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
print('67 observations per head; all finding inputs identical, including mutations')
