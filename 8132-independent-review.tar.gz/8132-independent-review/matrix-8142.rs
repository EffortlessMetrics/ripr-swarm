use super::*;
use crate::analysis::{AnalysisMode, AnalysisOptions};
use crate::app::{CheckOutput, Mode};
use crate::config::OraclePolicy;
use crate::domain::{ExposureClass, LanguageId, Summary};
use serde_json::json;
use std::path::PathBuf;

// Run the real parser, candidate ordering, runnable selector, card and check
// renderer. Only the failure-boundary tests below mutate the resulting JSON.
fn check_output(first_file: &str) -> Result<Value, String> {
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|error| error.to_string())?
        .as_nanos();
    let root =
        std::env::temp_dir().join(format!("ripr-ledger-8132-{}-{stamp}", std::process::id()));
    std::fs::create_dir_all(root.join("src")).map_err(|error| error.to_string())?;
    std::fs::create_dir_all(root.join("tests")).map_err(|error| error.to_string())?;
    let result = (|| {
        std::fs::write(root.join("src/pricing.py"), "def calculate_discount(amount, threshold):\n    if amount >= threshold:\n        return amount - 10\n    return amount\n").map_err(|error| error.to_string())?;
        for (file, line) in [(first_file, 10), ("tests/test_plain.py", 60)] {
            let source = format!(
                "import unittest\nfrom src.pricing import calculate_discount\n{}class CheckoutTests(unittest.TestCase):\n    def test_same(self):\n        self.assertTrue(calculate_discount(150, 100))\n",
                "\n".repeat(line - 4)
            );
            std::fs::write(root.join(file), source).map_err(|error| error.to_string())?;
        }
        let options = AnalysisOptions {
            root: root.clone(),
            base: None,
            diff_file: Some(root.join("change.patch")),
            mode: AnalysisMode::Draft,
            include_unchanged_tests: false,
            resolve_tsconfig_paths: false,
            perl_facts_path: None,
            perl_producer_failure: None,
            git_timeout: None,
            git_candidate: None,
            production_like_targets: Default::default(),
            test_harnesses: Vec::new(),
            resolved_subject_identity: None,
            open_rust_index_paths: Default::default(),
        };
        std::fs::write(root.join("change.patch"), "diff --git a/src/pricing.py b/src/pricing.py\n--- a/src/pricing.py\n+++ b/src/pricing.py\n@@ -1,4 +1,4 @@\n def calculate_discount(amount, threshold):\n-    if amount > threshold:\n+    if amount >= threshold:\n         return amount - 10\n     return amount\n").map_err(|error| error.to_string())?;
        let analyzed = crate::analysis::run_analysis_with_oracle_policy(
            &options,
            &OraclePolicy::default(),
            &[LanguageId::Python],
        )
        .map_err(|error| error.to_string())?;
        assert_eq!(analyzed.findings.len(), 1);
        assert_eq!(analyzed.findings[0].class, ExposureClass::WeaklyExposed);
        let output = CheckOutput {
            schema_version: "0.2".to_string(),
            harness_projections: Vec::new(),
            tool: "ripr".to_string(),
            mode: Mode::Draft,
            root: PathBuf::from("."),
            base: None,
            analysis_outcome: None,
            summary: Summary::default(),
            findings: analyzed.findings,
            preview_language_advisories: Vec::new(),
            language_runs: Vec::new(),
            no_scope_provided: false,
            unanalyzed_working_tree: false,
            untracked_working_tree_source_paths: Vec::new(),
            unlinked_python_tests: None,
            suppression: None,
            partial_scope: None,
            analyzed_revisions: None,
        };
        serde_json::from_str(&crate::output::json::render(&output))
            .map_err(|error| error.to_string())
    })();
    std::fs::remove_dir_all(root).map_err(|error| error.to_string())?;
    result
}

fn projected_record(payload: &Value) -> Result<Value, String> {
    let report = build_gap_decision_ledger_report(GapDecisionLedgerInput {
        root: ".".to_string(),
        generated_at: "test".to_string(),
        source_kind: GapDecisionLedgerSourceKind::CheckOutput,
        records_path: "check.json".to_string(),
        records_json: Ok(payload.to_string()),
    });
    assert!(report.warnings.is_empty(), "{:?}", report.warnings);
    assert_eq!(report.records.len(), 1);
    let rendered: Value = serde_json::from_str(&render_gap_decision_ledger_json(&report)?)
        .map_err(|error| error.to_string())?;
    Ok(rendered["records"][0].clone())
}

fn expected_record(
    file: &str,
    name: Option<&str>,
    line: Option<u64>,
    command: &str,
) -> Result<Value, String> {
    let mut expected: Value =
        serde_json::from_str(&EXPECTED_RECORD.replace(SECOND_COMMAND, command))
            .map_err(|error| error.to_string())?;
    let route = expected["repair_route"]
        .as_object_mut()
        .ok_or("expected route missing")?;
    route.insert("target_file".to_string(), json!(file));
    match name {
        Some(name) => {
            route.insert("related_test".to_string(), json!(name));
        }
        None => {
            route.remove("related_test");
        }
    }
    match line {
        Some(line) => {
            route.insert("target_line".to_string(), json!(line));
        }
        None => {
            route.remove("target_line");
        }
    }
    expected["verification_commands"] = json!([command]);
    Ok(expected)
}

const SECOND_COMMAND: &str = "python -m unittest tests.test_plain.CheckoutTests.test_same";

#[test]
fn python_selected_second_line_follows_runnable_card_identity() -> Result<(), String> {
    let payload = check_output("tests/test_checkout.v2.py")?;
    let finding = &payload["findings"][0];
    assert_eq!(
        finding["related_tests"][0]["file"],
        "tests/test_checkout.v2.py"
    );
    assert_eq!(finding["related_tests"][0]["line"], 10);
    assert_eq!(finding["related_tests"][1]["file"], "tests/test_plain.py");
    assert_eq!(finding["related_tests"][1]["line"], 60);
    assert_eq!(
        finding["python_repair_card"]["suggested_location"]["test_file"],
        "tests/test_plain.py"
    );
    assert_eq!(
        finding["python_repair_card"]["verify"]["command"],
        SECOND_COMMAND
    );
    assert!(
        !finding["evidence"]
            .as_array()
            .ok_or("missing evidence")?
            .iter()
            .filter_map(Value::as_str)
            .any(|entry| entry.starts_with("test_verify_command:")
                && entry.contains("test_checkout.v2"))
    );
    let record = projected_record(&payload)?;
    assert_eq!(record["repair_route"]["target_line"], 60);
    assert_eq!(
        record,
        expected_record(
            "tests/test_plain.py",
            Some("test_same"),
            Some(60),
            SECOND_COMMAND
        )?
    );
    Ok(())
}

#[test]
fn python_selected_first_keeps_its_line_with_same_name_in_other_file() -> Result<(), String> {
    let payload = check_output("tests/test_checkout.py")?;
    assert_eq!(
        payload["findings"][0]["related_tests"]
            .as_array()
            .ok_or("missing related rows")?
            .len(),
        2
    );
    let command = "python -m unittest tests.test_checkout.CheckoutTests.test_same";
    assert_eq!(
        payload["findings"][0]["python_repair_card"]["verify"]["command"],
        command
    );
    assert_eq!(
        projected_record(&payload)?,
        expected_record(
            "tests/test_checkout.py",
            Some("test_same"),
            Some(10),
            command
        )?
    );
    Ok(())
}

#[test]
fn python_selected_identity_missing_unmatched_or_ambiguous_withholds_line() -> Result<(), String> {
    let original = check_output("tests/test_checkout.v2.py")?;
    for case in [
        "absent-name",
        "unmatched-name",
        "unmatched-file",
        "absent-rows",
        "duplicate-identity",
        "missing-line",
        "zero-line",
        "blank-name",
    ] {
        let mut payload = original.clone();
        let finding = &mut payload["findings"][0];
        let mut file = "tests/test_plain.py";
        let mut name = Some("test_same");
        match case {
            "absent-name" => {
                finding["python_repair_card"]["suggested_location"]
                    .as_object_mut()
                    .ok_or("missing location")?
                    .remove("test_name");
                name = None;
            }
            "unmatched-name" => {
                name = Some("test_other");
                finding["python_repair_card"]["suggested_location"]["test_name"] =
                    json!("test_other");
            }
            "unmatched-file" => {
                file = "tests/test_absent.py";
                finding["python_repair_card"]["suggested_location"]["test_file"] = json!(file);
            }
            "absent-rows" => {
                finding["related_tests"] = json!([]);
            }
            "duplicate-identity" => {
                let mut duplicate = finding["related_tests"][1].clone();
                duplicate["line"] = json!(90);
                finding["related_tests"]
                    .as_array_mut()
                    .ok_or("missing rows")?
                    .push(duplicate);
            }
            "missing-line" => {
                finding["related_tests"][1]
                    .as_object_mut()
                    .ok_or("missing row")?
                    .remove("line");
            }
            "zero-line" => {
                finding["related_tests"][1]["line"] = json!(0);
            }
            "blank-name" => {
                name = Some("");
                finding["python_repair_card"]["suggested_location"]["test_name"] = json!("");
                finding["related_tests"][1]["name"] = json!("");
            }
            _ => return Err("unknown case".to_string()),
        }
        if let Some(rows) = finding["related_tests"].as_array() {
            finding["related_tests_total"] = json!(rows.len());
        }
        eprintln!("CONTROL case={case} FINDING={} RECORD={}", payload["findings"][0], projected_record(&payload)?);
        assert_eq!(
            projected_record(&payload)?,
            expected_record(file, name, None, SECOND_COMMAND)?,
            "{case}"
        );
    }
    Ok(())
}

// Complete rendered record: route identity is varied explicitly by each case.
const EXPECTED_RECORD: &str = r#"{
  "anchor": {
    "dedupe_fingerprint": "gap:python:src/pricing.py:calculate_discount:predicate_boundary:predicate:amount>=threshold",
    "file": "src/pricing.py",
    "line": 2,
    "owner": "calculate_discount"
  },
  "authority_boundary": "preview_advisory_only",
  "canonical_gap_id": "gap:python:src/pricing.py:calculate_discount:predicate_boundary:predicate:amount>=threshold",
  "evidence_class": "predicate_boundary",
  "evidence_ids": [
    "probe:src_pricing.py:python_preview:b6c16437",
    "gap:python:src/pricing.py:calculate_discount:predicate_boundary:predicate:amount>=threshold"
  ],
  "gap_id": "gap:pr:gap:python:src/pricing.py:calculate_discount:predicate_boundary:predicate:amount>=threshold",
  "gap_state": "actionable",
  "kind": "MissingBoundaryAssertion",
  "language": "python",
  "language_status": "preview",
  "policy_state": "new",
  "projection_eligibility": {
    "agent_packet": {
      "eligible": true,
      "reason": "python_no_strong_oracle_with_bounded_repair_route"
    },
    "ci_summary": {
      "eligible": true,
      "reason": "pr_local_gap_record"
    },
    "gate_candidate": {
      "eligible": false,
      "reason": "policy_target_not_supplied"
    },
    "lsp_diagnostic": {
      "eligible": true,
      "reason": "local_file_scope"
    },
    "pr_comment": {
      "eligible": true,
      "reason": "stable_anchor_and_repair_route"
    },
    "report_packet": {
      "eligible": true,
      "reason": "all_gap_records_are_reportable"
    },
    "ripr_plus_count": {
      "eligible": false,
      "reason": "pr_local_not_repo_scoped"
    },
    "ripr_zero_count": {
      "eligible": false,
      "reason": "pr_local_not_repo_scoped"
    }
  },
  "receipt_command": "ripr receipt write --gap 'gap:python:src/pricing.py:calculate_discount:predicate_boundary:predicate:amount>=threshold' --verify-command 'python -m unittest tests.test_plain.CheckoutTests.test_same' --status not_run --out target/ripr/receipts/gap-python-src-pricing.py-calculate_discount-predicate_boundary-predicate-amount-threshold.json",
  "regeneration_commands": [
    "ripr check --root . --json > target/ripr/reports/after-check.json"
  ],
  "repair_route": {
    "assertion_shape": "Assert the owner result or effect at the boundary `amount == threshold`.",
    "changed_behavior": "predicate_boundary changed at src/pricing.py:2: `if amount >= threshold:`",
    "missing_discriminator": "amount == threshold",
    "related_test": "test_same",
    "route_kind": "StrengthenExistingTest",
    "stop_conditions": [
      "Stop if imports, fixtures, or test setup cannot call the changed owner.",
      "Stop if the expected value for the missing discriminator is ambiguous.",
      "Stop if adding the test appears to require a production-code edit."
    ],
    "target_file": "tests/test_plain.py",
    "target_line": 60
  },
  "repairability": "repairable",
  "scope": "pr_local",
  "source_currentness": "candidate_current",
  "static_limit_detail": "Python repair cards are preview advisory evidence.",
  "static_limit_kind": "python_preview",
  "static_limits": [
    {
      "detail": "Syntax-first Python preview evidence only.",
      "kind": "python_preview_limit"
    },
    {
      "detail": "No source edits, generated tests, mutation execution, provider calls, or gate authority.",
      "kind": "python_preview_limit"
    },
    {
      "detail": "Verify success alone is not a gap-closure receipt.",
      "kind": "python_preview_limit"
    }
  ],
  "verification_commands": [
    "python -m unittest tests.test_plain.CheckoutTests.test_same"
  ]
}"#;

fn capped_identity_output() -> Result<Value, String> {
    bounded_identity_output(7, false, true)
}

fn bounded_identity_output(
    early_count: usize,
    selected_first: bool,
    namesake: bool,
) -> Result<Value, String> {
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|error| error.to_string())?
        .as_nanos();
    let root =
        std::env::temp_dir().join(format!("ripr-ledger-8132-{}-{stamp}", std::process::id()));
    std::fs::create_dir_all(root.join("src")).map_err(|error| error.to_string())?;
    std::fs::create_dir_all(root.join("tests")).map_err(|error| error.to_string())?;
    let result = (|| {
        std::fs::write(root.join("src/pricing.py"), "def calculate_discount(amount, threshold):\n    if amount >= threshold:\n        return amount - 10\n    return amount\n").map_err(|error| error.to_string())?;
        let mut source =
            "import unittest\nfrom src.pricing import calculate_discount\n".to_string();
        let selected = if selected_first {
            "class TestGood:\n    def test_same(self):\n        assert calculate_discount(150, 100)\n"
        } else {
            "class TestGood:\n    def test_same(self):\n        calculate_discount(150, 100)\n"
        };
        if selected_first {
            source.push_str(selected);
        }
        for index in 0..early_count {
            let order = if selected_first { "zzz" } else { "aaa" };
            source.push_str(&format!("class Early{index}(unittest.TestCase):\n    def test_{order}{index}(self):\n        self.assertTrue(calculate_discount(150, 100))\n"));
        }
        if namesake {
            source.push_str("class Bad(unittest.TestCase):\n    def test_same(self):\n        self.assertTrue(calculate_discount(150, 100))\n");
        }
        if !selected_first {
            source.push_str(selected);
        }
        std::fs::write(root.join("tests/test_mixed.v2.py"), source)
            .map_err(|error| error.to_string())?;
        let options = AnalysisOptions {
            root: root.clone(),
            base: None,
            diff_file: Some(root.join("change.patch")),
            mode: AnalysisMode::Draft,
            include_unchanged_tests: false,
            resolve_tsconfig_paths: false,
            perl_facts_path: None,
            perl_producer_failure: None,
            git_timeout: None,
            git_candidate: None,
            production_like_targets: Default::default(),
            test_harnesses: Vec::new(),
            resolved_subject_identity: None,
            open_rust_index_paths: Default::default(),
        };
        std::fs::write(root.join("change.patch"), "diff --git a/src/pricing.py b/src/pricing.py\n--- a/src/pricing.py\n+++ b/src/pricing.py\n@@ -1,4 +1,4 @@\n def calculate_discount(amount, threshold):\n-    if amount > threshold:\n+    if amount >= threshold:\n         return amount - 10\n     return amount\n").map_err(|error| error.to_string())?;
        let analyzed = crate::analysis::run_analysis_with_oracle_policy(
            &options,
            &OraclePolicy::default(),
            &[LanguageId::Python],
        )
        .map_err(|error| error.to_string())?;
        assert_eq!(analyzed.findings.len(), 1);
        assert_eq!(analyzed.findings[0].class, ExposureClass::WeaklyExposed);
        let output = CheckOutput {
            schema_version: "0.2".to_string(),
            harness_projections: Vec::new(),
            tool: "ripr".to_string(),
            mode: Mode::Draft,
            root: PathBuf::from("."),
            base: None,
            analysis_outcome: None,
            summary: Summary::default(),
            findings: analyzed.findings,
            preview_language_advisories: Vec::new(),
            language_runs: Vec::new(),
            no_scope_provided: false,
            unanalyzed_working_tree: false,
            untracked_working_tree_source_paths: Vec::new(),
            unlinked_python_tests: None,
            suppression: None,
            partial_scope: None,
            analyzed_revisions: None,
        };
        serde_json::from_str(&crate::output::json::render(&output))
            .map_err(|error| error.to_string())
    })();
    std::fs::remove_dir_all(root).map_err(|error| error.to_string())?;
    result
}

#[test]
fn independent_review_capped_rows_must_not_lend_another_tests_line() -> Result<(), String> {
    let payload = capped_identity_output()?;
    let finding = &payload["findings"][0];
    eprintln!(
        "CAPPED_FINDING={}",
        serde_json::to_string(finding).map_err(|e| e.to_string())?
    );
    assert_eq!(finding["related_tests_total"], 9);
    assert_eq!(finding["related_tests"].as_array().ok_or("rows")?.len(), 8);
    assert_eq!(
        finding["python_repair_card"]["suggested_location"]["test_name"],
        "test_same"
    );
    assert_eq!(
        finding["python_repair_card"]["verify"]["command"],
        "python -m pytest tests/test_mixed.v2.py::TestGood::test_same"
    );
    assert!(
        finding["evidence"]
            .as_array()
            .ok_or("evidence")?
            .iter()
            .any(|v| v.as_str() == Some("suggested_test_line: 28"))
    );
    assert_eq!(finding["related_tests"][7]["name"], "test_same");
    assert_eq!(finding["related_tests"][7]["line"], 25);
    let record = projected_record(&payload)?;
    eprintln!(
        "CAPPED_RECORD={}",
        serde_json::to_string(&record).map_err(|e| e.to_string())?
    );
    assert_eq!(
        record["repair_route"]["target_line"],
        json!(28),
        "selected pytest row was omitted by the JSON cap; visible unittest namesake must not supply its line"
    );
    assert_eq!(record, expected_pytest_record(Some(28))?);
    Ok(())
}

#[test]
fn independent_review_complete_record_identity_controls() -> Result<(), String> {
    let original = check_output("tests/test_checkout.v2.py")?;
    for case in [
        "reverse",
        "other-file",
        "other-name",
        "duplicate-same-line",
        "duplicate-without-line",
        "negative",
        "null-line",
        "text-line",
        "fraction-line",
        "missing-file",
        "missing-row-name",
        "null-rows",
        "object-rows",
        "missing-rows",
        "whitespace-name",
        "nonobject-row",
    ] {
        let mut payload = original.clone();
        let finding = &mut payload["findings"][0];
        let mut line = Some(60);
        let mut name = "test_same";
        match case {
            "reverse" => finding["related_tests"]
                .as_array_mut()
                .ok_or("rows")?
                .reverse(),
            "other-file" | "other-name" => {
                let mut row = finding["related_tests"][1].clone();
                row[if case == "other-file" { "file" } else { "name" }] = json!("other");
                row["line"] = json!(90);
                finding["related_tests"]
                    .as_array_mut()
                    .ok_or("rows")?
                    .insert(0, row);
            }
            "duplicate-same-line" | "duplicate-without-line" => {
                let mut row = finding["related_tests"][1].clone();
                if case == "duplicate-without-line" {
                    row.as_object_mut().ok_or("row")?.remove("line");
                }
                finding["related_tests"]
                    .as_array_mut()
                    .ok_or("rows")?
                    .push(row);
                line = None;
            }
            "negative" | "null-line" | "text-line" | "fraction-line" => {
                finding["related_tests"][1]["line"] = match case {
                    "negative" => json!(-1),
                    "text-line" => json!("60"),
                    "fraction-line" => json!(60.5),
                    _ => Value::Null,
                };
                line = None;
            }
            "missing-file" | "missing-row-name" => {
                finding["related_tests"][1]
                    .as_object_mut()
                    .ok_or("row")?
                    .remove(if case == "missing-file" {
                        "file"
                    } else {
                        "name"
                    });
                line = None;
            }
            "null-rows" | "object-rows" | "missing-rows" => {
                if case == "missing-rows" {
                    finding
                        .as_object_mut()
                        .ok_or("finding")?
                        .remove("related_tests");
                } else {
                    finding["related_tests"] = if case == "null-rows" {
                        Value::Null
                    } else {
                        json!({})
                    };
                }
                line = None;
            }
            "whitespace-name" => {
                name = " \t";
                finding["python_repair_card"]["suggested_location"]["test_name"] = json!(name);
                finding["related_tests"][1]["name"] = json!(name);
                line = None;
            }
            "nonobject-row" => {
                finding["related_tests"]
                    .as_array_mut()
                    .ok_or("rows")?
                    .insert(0, json!("not a row"));
                line = Some(60);
            }
            _ => return Err("unknown review case".to_string()),
        }
        if let Some(rows) = finding["related_tests"].as_array() {
            finding["related_tests_total"] = json!(rows.len());
        }
        eprintln!("CONTROL case={case} FINDING={} RECORD={}", payload["findings"][0], projected_record(&payload)?);
        assert_eq!(
            projected_record(&payload)?,
            expected_record("tests/test_plain.py", Some(name), line, SECOND_COMMAND)?,
            "{case}"
        );
    }
    Ok(())
}

fn expected_pytest_record(line: Option<u64>) -> Result<Value, String> {
    let mut expected = expected_record(
        "tests/test_mixed.v2.py",
        Some("test_same"),
        line,
        "python -m pytest tests/test_mixed.v2.py::TestGood::test_same",
    )?;
    expected["repair_route"]["assertion_shape"] = json!(
        "Assert the owner result or effect at `amount == threshold` first. Optional pytest shape: @pytest.mark.parametrize(\"amount, expected\", [(threshold - 1, ...), (threshold, ...), (threshold + 1, ...)]); fill expected values from domain behavior only."
    );
    expected["repair_route"]["stop_conditions"]
        .as_array_mut().ok_or("expected stop conditions")?
        .push(json!("Stop before adding parametrized below/above rows if their expected values are not clear; keep only the equality-boundary assertion."));
    Ok(expected)
}

#[test]
fn python_inventory_cap_boundaries_preserve_complete_records() -> Result<(), String> {
    // Exercise below/at/above eight, a selected row retained/omitted, and
    // same-file namesakes both visible and hidden by the real JSON producer.
    for early_count in [5, 6, 7, 8] {
        for selected_first in [false, true] {
            for namesake in [false, true] {
                let payload = bounded_identity_output(early_count, selected_first, namesake)?;
                let finding = &payload["findings"][0];
                let total = early_count + 1 + usize::from(namesake);
                let selected_line = if selected_first {
                    4
                } else {
                    4 + early_count * 3 + usize::from(namesake) * 3
                };
                let rows = finding["related_tests"].as_array().ok_or("rows")?;
                assert_eq!(finding["related_tests_total"], total);
                assert_eq!(rows.len(), total.min(8));
                assert_eq!(
                    finding["python_repair_card"]["suggested_location"]["test_file"],
                    "tests/test_mixed.v2.py"
                );
                assert_eq!(
                    finding["python_repair_card"]["suggested_location"]["test_name"],
                    "test_same"
                );
                assert_eq!(
                    finding["python_repair_card"]["verify"]["command"],
                    "python -m pytest tests/test_mixed.v2.py::TestGood::test_same"
                );
                assert_eq!(
                    rows.iter()
                        .any(|row| row["name"] == "test_same" && row["line"] == selected_line),
                    selected_first || total <= 8
                );
                let line = (namesake || total <= 8).then_some(selected_line as u64);
                let expected = expected_pytest_record(line)?;
                let actual = projected_record(&payload)?;
                eprintln!("MATRIX early={early_count} first={selected_first} namesake={namesake} FINDING={} RECORD={}", finding, actual);
                assert_eq!(
                    actual, expected,
                    "early={early_count}, selected_first={selected_first}, namesake={namesake}"
                );
                assert_eq!(projected_record(&payload)?, actual, "repeat projection");
            }
        }
    }
    Ok(())
}

#[test]
fn python_lossy_inventory_withholds_precision_for_complete_record() -> Result<(), String> {
    let original = check_output("tests/test_checkout.v2.py")?;
    for case in [
        "absent-total",
        "null-total",
        "text-total",
        "negative-total",
        "fraction-total",
        "under-total",
        "over-total",
        "unselected-missing-file",
        "unselected-missing-name",
        "unselected-blank-file",
        "unselected-null-name",
    ] {
        let mut payload = original.clone();
        let finding = &mut payload["findings"][0];
        match case {
            "absent-total" => {
                finding
                    .as_object_mut()
                    .ok_or("finding")?
                    .remove("related_tests_total");
            }
            "null-total" => finding["related_tests_total"] = Value::Null,
            "text-total" => finding["related_tests_total"] = json!("2"),
            "negative-total" => finding["related_tests_total"] = json!(-2),
            "fraction-total" => finding["related_tests_total"] = json!(2.5),
            "under-total" => finding["related_tests_total"] = json!(1),
            "over-total" => finding["related_tests_total"] = json!(3),
            "unselected-missing-file" | "unselected-missing-name" => {
                finding["related_tests"][0]
                    .as_object_mut()
                    .ok_or("row")?
                    .remove(if case == "unselected-missing-file" {
                        "file"
                    } else {
                        "name"
                    });
            }
            "unselected-blank-file" => finding["related_tests"][0]["file"] = json!(" \t"),
            "unselected-null-name" => finding["related_tests"][0]["name"] = Value::Null,
            _ => return Err("unknown inventory case".to_string()),
        }
        eprintln!("CONTROL case={case} FINDING={} RECORD={}", payload["findings"][0], projected_record(&payload)?);
        assert_eq!(
            projected_record(&payload)?,
            expected_record(
                "tests/test_plain.py",
                Some("test_same"),
                if case == "over-total" { None } else { Some(60) },
                SECOND_COMMAND
            )?,
            "{case}"
        );
    }
    Ok(())
}


#[test]
fn review_evidence_and_corrupt_cap_observations() -> Result<(), String> {
    for case in ["valid-capped", "capped-absent-total-no-evidence", "capped-text-total-no-evidence", "capped-null-total-no-evidence", "capped-negative-total-no-evidence", "capped-fraction-total-no-evidence", "capped-under-total-no-evidence", "capped-duplicate-line-last25", "capped-duplicate-line-last28", "capped-duplicate-identical", "capped-duplicate-file-mismatch-last", "capped-duplicate-file-match-last", "capped-invalid-last-line", "capped-no-rows-valid-evidence", "complete-namesake-valid-evidence", "complete-unique-conflicting-evidence"] {
        let mut payload = if case == "complete-unique-conflicting-evidence" { check_output("tests/test_checkout.v2.py")? } else { capped_identity_output()? };
        let f=&mut payload["findings"][0];
        match case {
            "capped-absent-total-no-evidence" | "capped-text-total-no-evidence" | "capped-null-total-no-evidence" | "capped-negative-total-no-evidence" | "capped-fraction-total-no-evidence" | "capped-under-total-no-evidence" => {
                f["evidence"].as_array_mut().ok_or("evidence")?.retain(|x| !x.as_str().is_some_and(|x| x.starts_with("suggested_test_line:")));
                if case=="capped-absent-total-no-evidence" { f.as_object_mut().ok_or("finding")?.remove("related_tests_total"); }
                else { f["related_tests_total"] = match case { "capped-text-total-no-evidence" =>json!("9"), "capped-null-total-no-evidence" =>Value::Null, "capped-negative-total-no-evidence" =>json!(-1), "capped-fraction-total-no-evidence"=>json!(9.5), _=>json!(7)}; }
            },
            "capped-duplicate-line-last25" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_line: 25")),
            "capped-duplicate-line-last28" => f["evidence"].as_array_mut().ok_or("evidence")?.insert(0,json!("suggested_test_line: 25")),
            "capped-duplicate-identical" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_line: 28")),
            "capped-duplicate-file-mismatch-last" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_file: other.py")),
            "capped-duplicate-file-match-last" => f["evidence"].as_array_mut().ok_or("evidence")?.insert(0,json!("suggested_test_file: other.py")),
            "capped-invalid-last-line" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_line: invalid")),
            "capped-no-rows-valid-evidence" => {f.as_object_mut().ok_or("finding")?.remove("related_tests");},
            "complete-namesake-valid-evidence" => {payload=bounded_identity_output(5,false,true)?;},
            "complete-unique-conflicting-evidence" => f["evidence"].as_array_mut().ok_or("evidence")?.push(json!("suggested_test_line: 99")),
            _=>{},
        }
        let record=projected_record(&payload)?;
        let observed=record["repair_route"]["target_line"].as_u64();
        let expected = match case {
 "capped-absent-total-no-evidence" | "capped-text-total-no-evidence" | "capped-null-total-no-evidence" | "capped-negative-total-no-evidence" | "capped-fraction-total-no-evidence" | "capped-under-total-no-evidence" | "capped-duplicate-line-last25" => Some(25),
 "capped-duplicate-file-mismatch-last" | "capped-invalid-last-line" | "complete-unique-conflicting-evidence" => None,
 "complete-namesake-valid-evidence" => Some(22),
 _ => Some(28),
};
        eprintln!("EXTRA case={case} FINDING={} RECORD={record}",payload["findings"][0]);
        assert_eq!(observed,expected,"observation case={case}");
        let full = if case=="complete-unique-conflicting-evidence" {expected_record("tests/test_plain.py",Some("test_same"),expected,SECOND_COMMAND)?} else {expected_pytest_record(expected)?};
        assert_eq!(record,full,"full record case={case}");
    }
    Ok(())
}
