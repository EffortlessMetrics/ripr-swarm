# ripr precommit v2

- Status: `pass`
- Failure kind: `none`
- Head: `720e27d14c46e8a48129dcc0d185272bbc4ca1cc`
- Merge base: `a142074061128a85e76c1ac494b9939f3a58428b`
- Changed records: `4`
- Report digest: `sha256:f3e4d7c7583dddbcbbc9e80c7d807fced9d77f6fe6d50a4ac3e012a17abeaa00`

- Composition: `ci_policy`

## Changed files

- `added` `-` -> `changelog.d/8132-python-ledger-selected-location.md` (committed)
- `added` `-` -> `crates/ripr/src/output/gap_decision_ledger/python_identity_tests.rs` (committed)
- `modified` `-` -> `.ripr/traceability.toml` (committed)
- `modified` `-` -> `crates/ripr/src/output/gap_decision_ledger.rs` (committed)

## Impact plan

- package: `ripr`
- package: `xtask`

## Commands

- `cargo metadata --format-version 1 --manifest-path $REPO/Cargo.toml`: `pass`
- `existing repository policy precommit`: `pass`
- `git diff --check a142074061128a85e76c1ac494b9939f3a58428b...HEAD`: `pass`
- `git diff --cached --check`: `pass`
- `git diff --check`: `pass`

## Child command diagnostics

Diagnostic observations of existing child calls in this invocation only. Missing rows/values are unavailable evidence, never zero compilation or completed work. Elapsed scopes differ; the captured runner polls exit and excludes pipe draining; enforced timeout duration includes termination/reaping and Unix process-group confirmation where applicable. Cargo progress counts recognize stderr lines only, not compiler-unit identities, completed artifacts, reuse proof or redundant compilation. These diagnostics waive no gate.

Capture scope: diff checks and selected Clippy children only. Metadata, aggregate policy gates and their children have unavailable diagnostics here. Argv retains argument boundaries with repository-root substitution `$REPO`. HEAD/base and changed paths are context, not an immutable digest of dirty source.

- program="git"; argv=["-C", "$REPO", "diff", "--check", "a142074061128a85e76c1ac494b9939f3a58428b...HEAD"]; outcome=pass; status=exit status: 0; exit_code=0; elapsed_ms=100; elapsed_scope=runner_start_to_observed_exit_excluding_pipe_drain; cargo_progress=unavailable
- program="git"; argv=["-C", "$REPO", "diff", "--cached", "--check"]; outcome=pass; status=exit status: 0; exit_code=0; elapsed_ms=202; elapsed_scope=runner_start_to_observed_exit_excluding_pipe_drain; cargo_progress=unavailable
- program="git"; argv=["-C", "$REPO", "diff", "--check"]; outcome=pass; status=exit status: 0; exit_code=0; elapsed_ms=100; elapsed_scope=runner_start_to_observed_exit_excluding_pipe_drain; cargo_progress=unavailable

## Skipped

- local selected Clippy is outside ci-policy; CI must run its explicit cargo clippy --workspace --all-targets -- -D warnings obligation

## Limitations

- none
