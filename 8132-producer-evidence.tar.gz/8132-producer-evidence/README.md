# Issue 8132 producer regression evidence

Bound source: 720e27d14c46e8a48129dcc0d185272bbc4ca1cc (tree 7b804108c45e50d00e189d1027aba31ba432516a).

Read provenance.json for exact commands, identities, outcomes and limitations. red.log is an intended behavioral failure; check-fast.log is an interrupted aggregate, never a pass. ci-policy.json is the policy-only receipt and explicitly skips Clippy.

Reconstruct the red source tree in a separate checkout/index from base a142074061128a85e76c1ac494b9939f3a58428b with red-tree.patch; the reconstructed tree was verified as ebfbbd8270cdde038a04716beb3e67af9764d9c9.

SHA256SUMS authenticates each included file by byte identity, not independent inspection or qualification. No binaries or caches are included.
