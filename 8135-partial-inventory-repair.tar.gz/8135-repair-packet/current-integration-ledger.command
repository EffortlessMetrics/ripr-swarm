Thu Oct 15 15:46:58 UTC 2026
1f654ab48880690b5e745a2b4c4ba32c86925a84
39d150d9aeffefc32ff0e0b82221b153b62b10c0
cargo test -p ripr --lib output::gap_decision_ledger -- --nocapture 
