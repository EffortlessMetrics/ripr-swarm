# ripr worktree doctor

Status: fail

Checks:

- branch is not dirty main
- branch is current with origin/main
- generated badge endpoints are not dirty in ordinary work
- generated target/sample artifacts are not dirty
- broad source-of-truth diffs have an obvious work item marker

Errors:

- branch is behind origin/main by 9 commit(s); refresh before opening or updating a PR

Warnings:

- target/ripr exists; remove local report artifacts before final worktree cleanup if this workspace is done
- crates/ripr/examples/sample/target exists; run `cargo clean` in that sample workspace or remove the residue before handoff

Next actions:

- refresh the branch from `origin/main` before opening or updating a PR
- remove `crates/ripr/examples/sample/target` or run `cargo clean` in that sample workspace
- remove local `target/ripr` report artifacts when the workspace is ready for handoff
- rerun `cargo xtask worktree doctor` after cleanup
