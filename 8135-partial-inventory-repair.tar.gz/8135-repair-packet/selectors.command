Thu Oct 15 15:20:14 UTC 2026
7d246801183e22bcf78e6c2efd556e387e27b1e2
10fbc4170b485e97d83e30d8d759254bc66777a2
cargo test -p ripr --lib related_tests::verify_command_tests 
