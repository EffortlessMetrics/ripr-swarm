Thu Oct 15 15:16:24 UTC 2026
720e27d14c46e8a48129dcc0d185272bbc4ca1cc
7b804108c45e50d00e189d1027aba31ba432516a
 .ripr/traceability.toml                            |   4 +
 .../8132-python-ledger-selected-location.md        |   2 +-
 crates/ripr/src/output/gap_decision_ledger.rs      |  33 +-
 .../gap_decision_ledger/python_identity_tests.rs   | 373 +++++++++++++++++++++
 4 files changed, 399 insertions(+), 13 deletions(-)
cargo test -p ripr --lib output::gap_decision_ledger -- --nocapture 
