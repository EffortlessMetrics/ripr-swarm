#!/usr/bin/env bash
set -u
export CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup
export PATH=/workspace/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/workspace/8135-target CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
label=$1
shift
{ date -u; git rev-parse HEAD HEAD^{tree}; git diff --stat; printf '%q ' "$@"; printf '\n'; } > /workspace/8135-evidence/$label.command
"$@" > /workspace/8135-evidence/$label.log 2>&1
code=$?
printf '%s\n' "$code" > /workspace/8135-evidence/$label.exit
exit "$code"
