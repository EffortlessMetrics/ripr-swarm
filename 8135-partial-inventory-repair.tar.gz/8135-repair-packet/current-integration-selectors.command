Thu Oct 15 15:50:27 UTC 2026
1f654ab48880690b5e745a2b4c4ba32c86925a84
39d150d9aeffefc32ff0e0b82221b153b62b10c0
cargo test -p ripr --lib related_tests::verify_command_tests 
