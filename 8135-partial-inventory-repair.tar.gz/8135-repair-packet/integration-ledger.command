Thu Oct 15 15:43:23 UTC 2026
7fa4aa83bf08291ce56e758a5f5de812edae8bd4
e32e9b6d66928680804d0c2f61a7a7cf173fc773
cargo test -p ripr --lib output::gap_decision_ledger -- --nocapture 
