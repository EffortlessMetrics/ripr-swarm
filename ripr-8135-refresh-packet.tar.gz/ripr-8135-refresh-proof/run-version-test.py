import subprocess,os,json,datetime,sys
from pathlib import Path
root=Path('/tmp/ripr-8135-refresh-proof')
env=os.environ.copy()
env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_TARGET_DIR='/workspace/8135-refresh-target',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
commands=[('version-test',['cargo','test','--locked','-p','ripr','--no-default-features','--features','lang-rust','--test','cli_smoke','version_is_exact_and_precedes_help_or_output_flags'])]
for name,cmd in commands:
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (root/(name+'.log')).open('w') as log:
        p=subprocess.run(cmd,cwd='/tmp/ripr-8135-refresh',env=env,stdout=log,stderr=subprocess.STDOUT)
    receipt={'name':name,'command':cmd,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'cwd':'/tmp/ripr-8135-refresh','environment':{k:env[k] for k in ['PATH','CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_INCREMENTAL']}}
    (root/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(name,p.returncode,flush=True)
    if p.returncode: sys.exit(p.returncode)
