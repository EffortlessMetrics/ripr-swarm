from pathlib import Path
import json,hashlib,subprocess
root=Path(__file__).resolve().parent
p=json.loads((root/'reports/precommit-v2.json').read_text());decl=p['report_digest'];p['report_digest']=''
calc='sha256:'+hashlib.sha256(json.dumps(p,ensure_ascii=False,separators=(',',':')).encode()).hexdigest();assert calc==decl
assert p['head_sha']=='9b0945b202cbb99ca0e708c21ba9879b7aaf71bd' and p['merge_base_sha']=='758a7c082c1c140d1d818bb3d7e5be78643d3f22'
assert p['status']=='pass' and p['skipped']==[]
expected_paths=sorted(x.decode() for x in (root/'selector-paths.z').read_bytes().split(b'\0') if x)
assert len(expected_paths)==4 and expected_paths==sorted(c['path'] for c in p['change_set']['changes'])
for name in ['check-fast','precommit','structural-rust-only','version-test']:
 assert json.loads((root/(name+'.json')).read_text())['exit']==0
assert 'test result: ok. 3 passed; 0 failed; 0 ignored;' in (root/'structural-rust-only.log').read_text()
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (root/'version-test.log').read_text()
v=json.loads((root/'binary-version.json').read_text());assert v['exit']==0 and v['stdout']=='ripr 0.11.0 (9b0945b202cbb99ca0e708c21ba9879b7aaf71bd)\n' and not v['stderr']
b=json.loads((root/'bridge-bindings.json').read_text());assert b['new_head']['tree']==b['prior_qualified']['tree']=='48bf287c742186117177822ae098a8bbe26fbfa9'
assert b['new_head']['parents']==['7d246801183e22bcf78e6c2efd556e387e27b1e2','758a7c082c1c140d1d818bb3d7e5be78643d3f22']
print('verified exact9b0945 head/base/4paths/digest; fresh check-fast,precommit,structural3,version1 and clean runtime version; original116/5/31 remain prior-object evidence')
print(calc)

r=json.loads((root/'remote-subject-verification.json').read_text())
assert r['actual_merge']=='966e5aa88559d1793eb721c39f1431f81ffdd798'
assert r['actual_parents']==['758a7c082c1c140d1d818bb3d7e5be78643d3f22','9b0945b202cbb99ca0e708c21ba9879b7aaf71bd']
assert r['actual_tree']=='48bf287c742186117177822ae098a8bbe26fbfa9'
assert r['prerequisite_fixture_blob']=='3ebc6faf435a443c6baa31bf410e53d121cadf6f' and r['prerequisite_ancestor'] and r['source_tree_diff_exit']==0
push=json.loads((root/'source-push.json').read_text());assert push['exit']==0 and all('force' not in x for x in push['command'])
assert push['before'].startswith('7d246801183e22bcf78e6c2efd556e387e27b1e2')
print('verified normal source push and actual remote merge966e/base758a/source9b/tree48bf/prerequisite3ebc; hosted job proof remains separate')
