# ripr PR shape report

Status: warn

This report is advisory. It highlights likely missing evidence before review.

## Warnings

```text
Output-facing code changed without output schema, contract registry, fixture, or golden evidence. Add the matching output evidence or explain why output is unchanged.
```

```text
Policy metadata changed without front-door process docs. Update AGENTS, CONTRIBUTING, README, docs/CI.md, or docs/PR_AUTOMATION.md when policy behavior changes.
```

