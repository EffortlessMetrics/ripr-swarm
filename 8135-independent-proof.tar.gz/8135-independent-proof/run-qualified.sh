#!/usr/bin/env bash
set -u
export CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup
export PATH=/workspace/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/workspace/qualification-target-8135 CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
qualification_label=$1
shift
qualification_receipts=/workspace/qualification-8135
{
  date -u
  git rev-parse HEAD HEAD^{tree}
  git status --porcelain
  printf '%q ' "$@"
  printf '\n'
} > "$qualification_receipts/$qualification_label.command"
"$@" > "$qualification_receipts/$qualification_label.log" 2>&1
qualification_code=$?
printf '%s\n' "$qualification_code" > "$qualification_receipts/$qualification_label.exit"
date -u >> "$qualification_receipts/$qualification_label.command"
exit "$qualification_code"
