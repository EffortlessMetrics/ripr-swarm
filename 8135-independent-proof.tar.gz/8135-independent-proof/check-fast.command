cargo xtask check-fast
cwd=/workspace/review-8135
original_tool_session=16471
720e27d14c46e8a48129dcc0d185272bbc4ca1cc
7b804108c45e50d00e189d1027aba31ba432516a
d4b67d2cd1bb3a1dfc138319bde7edd282dfef18
a142074061128a85e76c1ac494b9939f3a58428b
.ripr/traceability.toml
changelog.d/8132-python-ledger-selected-location.md
crates/ripr/src/output/gap_decision_ledger.rs
crates/ripr/src/output/gap_decision_ledger/python_identity_tests.rs
Thu Oct 15 14:36:33 UTC 2026
