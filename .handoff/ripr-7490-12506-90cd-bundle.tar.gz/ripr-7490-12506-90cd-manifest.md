# RIPR combined candidate handoff

This is an experimental qualification basis, not a release candidate or an instruction to freeze another branch.

- Observed swarm main: `90cd49ff051aafdb7ac16b4f5eb2087ab80530fd`, tree `f7f54686f590a47ba4576b1f33d2eaecd8f8559c`.
- Existing #12506 carrier: PR #12994, head `636873f223a851e96d58f6f5f6620b508662c10d` (included in the combined patch). Coordinate with its owner; do not publish a rival copy of that work.
- #7490 source candidate: `0b3917eea849e75fd691f182af0e6877822cf9ec`, tree `f6d501e5a681d264dccda40cc3899706b11fdf9d`; its lineage includes the verifier-lock fix and #12994.
- Combined result tree: `3ae02947cca2e2e9aaa8fec47936463dcc63dc4a`; no exact-tree build or test has run.
- Patch: `ripr-7490-12506-90cd-candidate.patch`, 342944 bytes, SHA-256 `7f49874872c742828a7f7c00e2646341fb4390c08484b6fd6e172a3a253e45f7`.
- Applying the patch to an index initialized at the named main commit produced exactly the combined tree above. The patch contains the owner carrier and both formerly untracked #7490 files.

The existing #12994 head and current main must be read again before publishing or integrating. A changed base requires an impact/conflict judgment; it does not automatically invalidate unrelated evidence. Preserve the existing no Draft/Ready CI hold, required checks, and branch protections.

## Reconstruct and check

On an admitted executor with the repository and patch available, verify the patch digest, check out the named main commit in a clean isolated worktree, apply the patch with `git apply --index`, and require `git write-tree` to equal `3ae02947cca2e2e9aaa8fec47936463dcc63dc4a`. Record the exact resulting tree, toolchain, feature flags, commands, exits, and artifact digests. Do not substitute this bundle for the owner's existing PR.

The following commands are a minimum starting set, not a claim that they have passed or a substitute for the current repository's required gates:

```text
cargo fmt --all -- --check
cargo test --locked -p ripr --test boundary_gap_closure
cargo test --locked -p ripr --test field_write_seam
cargo test --locked -p ripr --test repair_check_recommended_start
cargo test --locked -p ripr --test stage_metamorphic
cargo test --locked -p ripr --lib
cargo test --locked -p xtask output_properties
cargo xtask check-traceability
cargo xtask check-evidence-promotion-honesty
cargo xtask check-changelog-fragments
```

On the exact composed analyzer, also retain per-subject evidence for same-test boundary pairing and field-write behavior; cache-generation old-entry rejection for full, sharded and compact forms; a capped-full run followed by an actual compact warm hit with complete-output parity; compact prefill failure, cancellation and input-change preservation; glob and memo invalidation; and the verifier-poison race control. Regenerate producer-bound captures and dependent receipts genuinely if current rules require it; inspect semantic changes, not only hashes. Run repository-native review and required current-head gates before protected integration.

## Existing evidence and limits

The earlier `f9c200438a45deb5fcbe67bd5457472441b36328` production executable passed its bounded cache/prefill controls, and the earlier `5f9ee19b6166e51d91433a34c074a6ccf3b84fbe` boundary suite passed 26/26. Those are historical subjects, not passes on this tree. Reduced Rust-only harness results are supplemental, not a full unmodified unit-harness pass. The 7d main/candidate comparison was performed on the same isolated fixture; it does not establish current-tree integration. See the existing #12994 coordination comment and retained workspace evidence for details.

At handoff the current environment had only about 34 MB above its 3.65 GB build stop and a 17.18 GB cgroup memory limit. A prospective executor with at least 5 GiB free disk and more than 17.18 GB memory is a conservative proposed admission, not demonstrated sufficient capacity. Do not remove retained evidence or bypass resource guards to force a run.
