from pathlib import Path
import re
root=Path('/workspace/ripr-ts-cost/crates/ripr/src/analysis/language/typescript')
functions=['related_test_candidates','owner_call_relation','module_entry_relation','module_entry_owner','heuristic_relation','test_mocks_owner_module','test_spies_owner_with_fabrication_for_owner','import_alias_owner_locals','import_source_matches_owner','dynamic_import_member_call','local_identifier_declared_in_test_body','test_references_owner','contains_identifier_reference','heuristic_relation_allowed','owner_name_shadowed_by_unrelated_import','owner_export_imported_from_unrelated_source','import_references_owner_call','contains_call_name']
p=root/'related_tests.rs';text=p.read_text()
for name in functions:
 m=re.search(r'(?m)^(?:pub\(crate\) )?fn '+name+r'(?:<[^\n]*>)?\(',text)
 assert m,name
 brace=text.index('{',m.end())
 text=text[:brace+1]+f'\n    let _relation_span = super::TsRelationCostSpan::new("{name}", false);\n'+text[brace+1:]
p.write_text(text)
p=root/'classifier.rs';text=p.read_text();start=text.index("pub(crate) fn owner_line_context<'a>(");brace=text.index('{',start);p.write_text(text[:brace+1]+'\n    let _relation_span = super::TsRelationCostSpan::new("owner_line_context", true);\n'+text[brace+1:])
p=root/'mod.rs';p.write_text(p.read_text()+'''
// Disposable owner-context profiling instrument; not product source.
thread_local! {
    static TS_RELATION_COST: std::cell::RefCell<Option<std::collections::BTreeMap<&'static str, (u64, u128)>>> = const { std::cell::RefCell::new(None) };
}
struct TsRelationCostSpan { name: &'static str, started: Option<std::time::Instant>, root: bool }
impl TsRelationCostSpan {
    fn new(name: &'static str, root: bool) -> Self {
        let active = TS_RELATION_COST.with(|slot| {
            if root { *slot.borrow_mut() = Some(std::collections::BTreeMap::new()); }
            slot.borrow().is_some()
        });
        Self { name, started: active.then(std::time::Instant::now), root }
    }
}
impl Drop for TsRelationCostSpan {
    fn drop(&mut self) {
        let Some(started) = self.started else { return; };
        let ns = started.elapsed().as_nanos();
        TS_RELATION_COST.with(|slot| {
            let mut slot = slot.borrow_mut();
            if let Some(map) = slot.as_mut() {
                let entry = map.entry(self.name).or_default(); entry.0 += 1; entry.1 += ns;
            }
            if self.root {
                if let Some(map) = slot.take() {
                    for (name, (calls, ns)) in map { eprintln!("TS_RELATION_COST {name} {calls} {ns}"); }
                }
            }
        });
    }
}
''')
