import subprocess, os, json, sys
from pathlib import Path
for n in (list(map(int,sys.argv[1:])) or [1,64,512,2680]):
 root=Path(f'/workspace/ts-owner-workload-{n}');root.mkdir();(root/'src').mkdir();(root/'tests').mkdir()
 (root/'ripr.toml').write_text('[languages]\nenabled = ["typescript"]\n')
 (root/'package.json').write_text('{"name":"relation-workload","devDependencies":{"vitest":"^3.0.0"},"scripts":{"test":"vitest"}}\n')
 source='function inner(value: number): number {\n  if (value >= 100) return value - 20;\n  return value;\n}\nexport function price(value: number): number {\n  return inner(value);\n}\nexport function total(value: number): number {\n  if (value >= 100) return value - 20;\n  return value;\n}\nexport function other(value: number): number { return value; }\n'
 (root/'src/pricing.ts').write_text(source)
 (root/'tests/pricing.test.ts').write_text("import { it, expect } from 'vitest';\nimport * as pricing from '../src/pricing';\nit('total result', () => { expect(pricing.total(200)).toBe(180); });\nit('price result', () => { expect(pricing.price(200)).toBe(180); });\n")
 (root/'tests/other.test.ts').write_text("import { it, expect } from 'vitest';\nimport * as pricing from '../src/pricing';\n"+''.join(f"it('other {i}', () => {{ expect(pricing.other({i})).toBe({i}); }});\n" for i in range(n)))
 env=dict(os.environ,GIT_AUTHOR_DATE='2026-11-06T00:00:00Z',GIT_COMMITTER_DATE='2026-11-06T00:00:00Z')
 def git(*args):return subprocess.check_output(['git',*args],cwd=root,env=env,text=True).strip()
 git('init','-q');git('add','.');git('-c','user.name=Performance fixture','-c','user.email=fixture@example.invalid','commit','-qm','base')
 (root/'src/pricing.ts').write_text(source.replace('>= 100','> 100'));git('add','.');git('-c','user.name=Performance fixture','-c','user.email=fixture@example.invalid','commit','-qm','two boundary edits')
 print(root,git('rev-parse','HEAD'),git('rev-parse','HEAD^{tree}'))
