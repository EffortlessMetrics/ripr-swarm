import json
from pathlib import Path
out=Path('/workspace/ts-owner-evidence');records=[json.loads(l) for l in (out/'measurements.jsonl').read_text().splitlines()]
assert len({r['label'] for r in records})==len(records)
for r in records:
 assert r['status']==0 and not r['timed_out'],r['label']
 d=json.loads((out/(r['label']+'.json')).read_bytes())
 assert d['analysis_outcome']['analysis_complete'],r['label']
 assert len(d['findings'])==d['summary']['findings']>0,r['label']
for workload in ['zod','namespace-1','namespace-64','namespace-512','namespace-2680']:
 for trial in range(1,4):
  for phase in ['cold','warm','unchanged']:
   profile=out/f'profile-{workload}-{trial}-{phase}.json'
   baseline=out/f'paired-baseline-{workload}-{trial}-{phase}.json'
   assert profile.read_bytes()==baseline.read_bytes(),profile.name
summary=dict(measured_invocations=len(records),native_exit_zero=len(records),timeouts=0,all_complete_nonempty=True,instrumented_baseline_exact_stdout_comparisons=45,paired_baseline_candidate_comparisons=45,independent_production_edit_samples_per_binary=3,independent_assertion_edit_samples_per_binary=3,independent_config_edit_samples_per_binary=3,unknown_accounting='Every useful-reach base/production sample retains one static_unknown helper with propagation_evidence_unknown and one weakly_exposed public owner; assertion edits retain helper unknown and make the public owner exposed. Config redirection and zod remain no_static_path controls with no speed claim.')
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
