import json, statistics, collections
from pathlib import Path
out=Path('/workspace/ts-owner-evidence')
records=[json.loads(l) for l in (out/'measurements.jsonl').read_text().splitlines()]
groups=collections.defaultdict(list)
for r in records:
 label=r['label']
 if label.startswith('paired-'):
  parts=label.split('-');key='-'.join(parts[:2]+parts[2:-2]+[parts[-1]])
 elif label.startswith(('baseline-production-','baseline-assertion-','candidate-production-','candidate-assertion-')):
  parts=label.split('-');key='-'.join(parts[:2]+parts[3:])
 else:continue
 groups[key].append(r)
summary={}
for key,rows in groups.items():
 summary[key]=dict(n=len(rows),wall_median_s=statistics.median(r['wall_seconds'] for r in rows),wall_range_s=[min(r['wall_seconds'] for r in rows),max(r['wall_seconds'] for r in rows)],cpu_median_s=statistics.median(r['user_seconds']+r['system_seconds'] for r in rows),max_rss_kib=max(r['peak_rss_kib'] for r in rows),statuses=[r['status'] for r in rows],timeouts=sum(r['timed_out'] for r in rows))
profile={}
for path in out.glob('profile-*.stderr'):
 totals=collections.defaultdict(lambda:[0,0])
 for line in path.read_text().splitlines():
  if line.startswith('TS_RELATION_COST '):
   _,name,calls,ns=line.split();totals[name][0]+=int(calls);totals[name][1]+=int(ns)
 profile[path.stem]={k:dict(calls=v[0],inclusive_ms=v[1]/1e6) for k,v in totals.items()}
edits=[]
for kind in ['production','assertion','config']:
 for trial in range(1,4):
  for phase in ['clean-warm','edited-warm','edited-cold','restored-warm']:
   base=out/f'baseline-{kind}-{trial}-{phase}.json';candidate=out/f'candidate-{kind}-{trial}-{phase}.json'
   if not(base.exists() and candidate.exists()):continue
   assert base.read_bytes()==candidate.read_bytes(),(kind,trial,phase)
   edits.append(dict(kind=kind,trial=trial,phase=phase,all_stdout_bytes_equal=True))
result=dict(summary=summary,profile=profile,baseline_candidate_edit_parity=edits,excluded_samples='setup and instrumented profile samples are not baseline/candidate performance comparisons')
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary,indent=2))
