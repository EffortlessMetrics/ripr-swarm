import subprocess,sys,json
from pathlib import Path
baseline,candidate=sys.argv[1:]
out=Path('/workspace/ts-owner-evidence');observations=[]
workloads=[('zod','/workspace/ts-cost-zod')]+[(f'namespace-{n}',f'/workspace/ts-owner-workload-{n}') for n in [1,64,512,2680]]
for workload,root in workloads:
 for trial in range(1,4):
  order=[('baseline',baseline),('candidate',candidate)]
  if trial%2==0:order.reverse()
  docs={}
  for name,binary in order:
   cache=Path(f'/workspace/ts-owner-cache/paired-{name}-{workload}-{trial}')
   assert not cache.exists(),cache
   for phase in ['cold','warm','unchanged']:
    label=f'paired-{name}-{workload}-{trial}-{phase}'
    subprocess.run([sys.executable,str(out/'measure.py'),binary,root,str(cache),label],check=True)
    d=json.loads((out/(label+'.json')).read_bytes())
    assert d['analysis_outcome']['analysis_complete']
    assert len(d['findings'])==(6 if workload=='zod' else 2)
    if workload!='zod':assert all(f['related_tests'] and f['ripr']['reach']['state']=='yes' for f in d['findings'])
    docs[name,phase]=(out/(label+'.json')).read_bytes()
  for phase in ['cold','warm','unchanged']:
   assert docs['baseline',phase]==docs['candidate',phase],(workload,trial,phase)
  observations.append(dict(workload=workload,trial=trial,order=[x[0] for x in order],all_stdout_bytes_equal=True,findings=6 if workload=='zod' else 2,useful_reach=workload!='zod'))
(out/'paired-correctness.json').write_text(json.dumps(observations,indent=2)+'\n')
