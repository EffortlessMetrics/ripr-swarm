import subprocess,sys
from pathlib import Path
binary=sys.argv[1];prefix=sys.argv[2]
for workload,root in [('zod','/workspace/ts-cost-zod')]+[(f'namespace-{n}',f'/workspace/ts-owner-workload-{n}') for n in [1,64,512,2680]]:
 for trial in range(1,4):
  cache=f'/workspace/ts-owner-cache/{prefix}-{workload}-{trial}'
  for phase in ['cold','warm','unchanged']:
   subprocess.run([sys.executable,'/workspace/ts-owner-evidence/measure.py',binary,root,cache,f'{prefix}-{workload}-{trial}-{phase}'],check=True)
