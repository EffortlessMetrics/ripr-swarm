from pathlib import Path
p=Path('/workspace/ripr-ts-cost/crates/ripr/src/analysis/language/typescript/related_tests.rs')
t=p.read_text()
old='''        if !import_source_matches_owner(import, &test.file, owner, alias_map, workspace_root) {
            return false;
        }
        if local_identifier_declared_in_test_body(&test.body_text, &import.local)
            || enclosing_scope_shadows(test, &import.local)
        {
            return false;
        }
        if !import.namespace
            && owner_name_destructured_from_unrelated_source(test, owner, alias_map, workspace_root)
        {
            return false;
        }
        import_references_owner_call(import, test, owner)
'''
new='''        if !import_source_matches_owner(import, &test.file, owner, alias_map, workspace_root)
            || !import_references_owner_call(import, test, owner)
        {
            return false;
        }
        // Only a call of this owner needs binding facts. A namespace call of
        // a sibling must not build a shadow index for the whole test body.
        if local_identifier_declared_in_test_body(&test.body_text, &import.local)
            || enclosing_scope_shadows(test, &import.local)
        {
            return false;
        }
        if !import.namespace
            && owner_name_destructured_from_unrelated_source(test, owner, alias_map, workspace_root)
        {
            return false;
        }
        true
'''
assert t.count(old)==1;t=t.replace(old,new)
old='''        // Shadow guard (#4102): a test-body declaration of the local name
        // reaches the shadow, not the re-exported owner.
'''
new='''        // Establish the re-export target before asking for binding facts:
        // unrelated calls such as expect(...) otherwise build a shadow index
        // even though their import cannot reach this owner.
        if !reexport_index.resolve_to_owner(
            test,
            &import.source,
            imported_name,
            owner,
            alias_map,
            workspace_root,
        ) {
            return false;
        }
        // Shadow guard (#4102): a test-body declaration of the local name
        // reaches the shadow, not the re-exported owner.
'''
assert t.count(old)==1;t=t.replace(old,new)
old='''        reexport_index.resolve_to_owner(
            test,
            &import.source,
            imported_name,
            owner,
            alias_map,
            workspace_root,
        )
    }) {
        return Some(TypeScriptRelationKind::ReExportChainFollowed);
'''
new='''        true
    }) {
        return Some(TypeScriptRelationKind::ReExportChainFollowed);
'''
assert t.count(old)==1;t=t.replace(old,new);p.write_text(t)
