import json,os,subprocess,sys
from pathlib import Path
root=Path('/workspace/ts-owner-workload-alias');out=Path('/workspace/ts-owner-evidence')
valid='{"compilerOptions":{"baseUrl":".","paths":{"@/*":["src/*"]}}}\n'
changed=valid.replace('src/*','other/*')
if not root.exists():
 root.mkdir();(root/'src').mkdir();(root/'other').mkdir();(root/'tests').mkdir()
 original=Path('/workspace/ts-owner-workload-1')
 for relative in ['package.json','src/pricing.ts','tests/pricing.test.ts','tests/other.test.ts']:
  text=(original/relative).read_text().replace('../src/pricing','@/pricing')
  (root/relative).write_text(text)
 source=(root/'src/pricing.ts').read_text()
 (root/'other/pricing.ts').write_text(source)
 (root/'src/pricing.ts').write_text(source.replace('> 100','>= 100'))
 (root/'ripr.toml').write_text('[languages]\nenabled = ["typescript"]\n[typescript]\nresolve_tsconfig_paths = true\n')
 (root/'tsconfig.json').write_text(valid)
 env=dict(os.environ,GIT_AUTHOR_DATE='2026-11-06T00:00:00Z',GIT_COMMITTER_DATE='2026-11-06T00:00:00Z')
 def git(*args):return subprocess.run(['git',*args],cwd=root,env=env,check=True,stdout=subprocess.DEVNULL)
 git('init','-q');git('add','.');git('-c','user.name=Performance fixture','-c','user.email=fixture@example.invalid','commit','-qm','alias base')
 (root/'src/pricing.ts').write_text(source);git('add','.');git('-c','user.name=Performance fixture','-c','user.email=fixture@example.invalid','commit','-qm','two boundary changes')
if len(sys.argv)==1:sys.exit(0)
binary,prefix=sys.argv[1:];p=root/'tsconfig.json';assert p.read_text()==valid
def run(cache,label):
 subprocess.run([sys.executable,str(out/'measure.py'),binary,str(root),cache,label],check=True)
 return json.loads((out/(label+'.json')).read_bytes())
receipts=[]
try:
 for trial in range(1,4):
  stem=f'{prefix}-config-{trial}';cache=f'/workspace/ts-owner-cache/{stem}'
  run(cache,stem+'-seed');clean=run(cache,stem+'-clean-warm')
  assert len(clean['findings'])==2 and all(f['related_tests'] and f['ripr']['reach']['state']=='yes' for f in clean['findings'])
  p.write_text(changed)
  warm=run(cache,stem+'-edited-warm');cold=run(cache+'-independent-cold',stem+'-edited-cold')
  assert (out/(stem+'-edited-warm.json')).read_bytes()==(out/(stem+'-edited-cold.json')).read_bytes()
  assert len(warm['findings'])==2 and all(f['classification']=='no_static_path' for f in warm['findings'])
  p.write_text(valid);run(cache,stem+'-restored-warm')
  assert (out/(stem+'-restored-warm.json')).read_bytes()==(out/(stem+'-clean-warm.json')).read_bytes()
  receipts.append(dict(trial=trial,original_reach_rows=2,redirected_no_static_path=2,unknown_or_refused_outcome='no_static_path control; no speed claim',warm_cold_all_bytes_equal=True,restored_bytes_equal=True))
finally:p.write_text(valid)
(out/(prefix+'-config-correctness.json')).write_text(json.dumps(receipts,indent=2)+'\n')
