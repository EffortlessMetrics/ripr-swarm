import subprocess
from pathlib import Path
base=Path('/workspace')
for n in [1, 64, 512]:
 root=base/f'ts-cost-control-{n}'
 root.mkdir(exist_ok=True)
 (root/'src').mkdir(exist_ok=True); (root/'tests').mkdir(exist_ok=True)
 (root/'ripr.toml').write_text('[languages]\nenabled = ["typescript"]\n')
 (root/'package.json').write_text('{"name":"ts-cost-control","devDependencies":{"vitest":"^3.0.0"},"scripts":{"test":"vitest"}}\n')
 old='export function price(value: number) {\n  if (value >= 100) return value - 20;\n  return value;\n}\n'
 (root/'src/price.ts').write_text(old)
 (root/'src/other.ts').write_text('export function other(value: number) { return value; }\n')
 (root/'tests/price.test.ts').write_text("import { it, expect } from 'vitest';\nimport { price } from '../src/price';\nit('price', () => { expect(price(200)).toBe(180); });\n")
 (root/'tests/other.test.ts').write_text("import { it, expect } from 'vitest';\nimport { other } from '../src/other';\n"+''.join(f"it('other {i}', () => {{ expect(other({i})).toBe({i}); }});\n" for i in range(n)))
 def git(*args): return subprocess.run(['git',*args],cwd=root,check=True,stdout=subprocess.DEVNULL)
 git('init','-q'); git('add','.'); git('-c','user.name=Performance fixture','-c','user.email=fixture@example.invalid','commit','-qm','base')
 (root/'src/price.ts').write_text(old.replace('>= 100','> 100'))
 git('add','.'); git('-c','user.name=Performance fixture','-c','user.email=fixture@example.invalid','commit','-qm','boundary change')
 print(root)
