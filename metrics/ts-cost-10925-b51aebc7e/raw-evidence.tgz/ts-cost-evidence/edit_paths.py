import subprocess, sys
from pathlib import Path
binary='/workspace/ts-cost-evidence/baseline-ripr'
prefix=sys.argv[1] if len(sys.argv)>1 else 'baseline'
cache=sys.argv[2] if len(sys.argv)>2 else '/workspace/ts-cost-cache/zod-3'
root=Path('/workspace/ts-cost-zod')
measure=Path('/workspace/ts-cost-evidence/measure.py')
def runs(phase):
 for i in range(1,4):
  subprocess.run([sys.executable,str(measure),binary,str(root),cache,f'{prefix}-zod-{phase}-{i}'],check=True)
for phase, relative in [('source-edit','packages/zod/src/v4/core/schemas.ts'),('test-edit','packages/zod/src/v4/classic/tests/union.test.ts')]:
 p=root/relative; old=p.read_bytes()
 try:
  p.write_bytes(old+b'\n// bounded performance invalidation control\n')
  runs(phase)
 finally: p.write_bytes(old)
config=root/'ripr.toml'
assert not config.exists()
try:
 config.write_text('[languages]\nenabled = ["typescript"]\n')
 runs('config-edit')
finally: config.unlink()
runs('restored')
