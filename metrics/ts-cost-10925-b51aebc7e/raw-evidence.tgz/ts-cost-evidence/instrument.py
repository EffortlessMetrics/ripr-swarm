from pathlib import Path
root=Path('/workspace/ripr-ts-cost/crates/ripr/src/analysis/language/typescript')
targets={
 'fact_store.rs':['pub(crate) fn load('],
 'tests_extract.rs':['fn extract_tests_expanding_suite_factories('],
 'related_tests.rs':['pub(crate) fn module_export_facts('],
 'classifier.rs':["pub(crate) fn owner_line_context<'a>("],
 'static_limit.rs':['pub(crate) fn named_limitations_for_relative_import_unresolved(', 'pub(crate) fn named_limitations_for_unresolved_ownership(', 'pub(crate) fn named_limitations_for_spy_fabrication('],
 'enum_member_guard.rs':['pub(crate) fn enum_member_use_code('],
}
for file, funcs in targets.items():
 p=root/file; text=p.read_text()
 for fn in funcs:
  start=text.index(fn); brace=text.index('{', start)
  name=fn.split('fn ')[1].split('(')[0].split('<')[0]
  text=text[:brace+1]+f'\n    let _ts_cost_span = super::TsCostSpan::new("{name}");\n'+text[brace+1:]
 p.write_text(text)
p=root/'mod.rs'
p.write_text(p.read_text()+'''
// Disposable profiling instrument; not a product candidate.
struct TsCostSpan { name: &'static str, start: std::time::Instant }
impl TsCostSpan {
    fn new(name: &'static str) -> Self { Self { name, start: std::time::Instant::now() } }
}
impl Drop for TsCostSpan {
    fn drop(&mut self) { eprintln!("TS_COST {} {}", self.name, self.start.elapsed().as_nanos()); }
}
''')
