# Bounded TypeScript performance evidence

Owning lane: #10925 TypeScript cost investigation. Integration owner remains session 01a1a959-f983-763a-96e6-7dbe1cced019; baseline evidence coordinator is 01a1ae31-b15f-75c8-99e9-9960427fe017. This lane does not alter the central candidate or add release qualification requirements.

## Inputs and attribution

- Frozen source: `b51aebc7e4735529befd677ebf14071c7f09e477`; tree `d3142dd59d4dcfea5e6b4981732f61c8516f3fa0`, fetched from `successor/011-pr13325-composition-02cddbb27`.
- Subject: zod `680d19f7d1e042e55934209caeb79bc843b94f44`; base `40a5dba080b065cc430e5b0e64a8058d68c1660d`: 2 files, 19 additions and 4 removals.
- Source-built baseline uses the repository release profile, default features and locked dependencies. It is not an installed distribution artifact.
- `identity.json` records host/toolchain and command; `admission.txt` records isolated resources and retention.

## Current-source audit

Historical timings/profile percentages in #10925 are not current-candidate evidence. Latest issue continuations were read, including #11380 and #11949. `discovery.json` retains the issue comments and all-state #10925 PR search.

- #11320 merged as `aaf294af54ad05d589f80035024e5873682ef1d8`; its owner-pin/source-snapshot masking repair concerns Rust, not TypeScript's enum-member extraction.
- `typescript/fact_store.rs` schema 6 persists file facts, test extraction and partial-extraction verdicts. #11712 already deduplicated per-file lists in the wire representation; #12084 already persisted the partial-extraction verdict. A second extraction cache would duplicate existing work.
- `classifier.rs::owner_line_context` already calls `related_test_candidates` once and derives mock paths from it (#11949).
- `static_limit.rs::named_limitations_for_unresolved_ownership` and `named_limitations_for_spy_fabrication` still separately enumerate the relation index. The relative-import limitation scans all tests from `classify_resolved_owner` per probe. This is a lead, not yet a measured optimization claim.
- Finding-specific all-state PR searches for `named_limitations` and `relative_import_unresolved` returned no results. Open TypeScript/fact_store searches were inspected before choosing any repair.

## Reproduction

`measure.py` runs one child with a 45-second limit, pins four Rayon threads, captures stdout/stderr, and uses Linux `wait4` for child/descendant CPU and peak RSS. It records exit status and timeout explicitly. Runs with incomplete outcomes or empty findings cannot establish speed improvements.

`repeat.py <absolute-baseline-binary>` performs three independent zod cold-cache trials, each followed by two unchanged warm invocations. Cold means application cache empty, not OS page cache flushed. All invocations use the same subject, base, config and absolute binary. Controls retain one boundary change and its relevant test while increasing unrelated tests to 1, 64 and 512; `make_controls.py` constructs them.

`instrument.py` is a disposable profiling experiment, not product source: it inserts timed spans into historical extraction buckets, fact-store load, owner context and limitation consumers. Its modified-source patch and binary identity must be retained separately from exact-baseline results. Span timings overlap where nested and must not be summed as disjoint percentages.

## Restrictions

No competing CI, central-ref mutation, full-library qualification, ceiling changes, release publication, or changes to public #1889 draft/DO NOT MERGE and #1893 trust hold are authorized by this evidence lane.
