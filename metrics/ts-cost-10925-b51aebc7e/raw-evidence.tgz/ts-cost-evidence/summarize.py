import json, statistics, hashlib, collections
from pathlib import Path
root=Path('/workspace/ts-cost-evidence')
records=[json.loads(l) for l in (root/'measurements.jsonl').read_text().splitlines()]
groups=collections.defaultdict(list)
for r in records:
 if not r['label'].startswith(('clean-baseline','profile')):continue
 label=r['label']
 if '-zod-' in label:
  phase=label.rsplit('-',1)[-1]
  if phase.isdigit(): phase=label.split('-zod-',1)[1].rsplit('-',1)[0]
  group=('profile' if label.startswith('profile') else 'baseline')+'-zod-'+phase
 else:group=label.rsplit('-',1)[0]
 groups[group].append(r)
summary={}
for group, rows in groups.items():
 summary[group]=dict(n=len(rows),wall_median_seconds=statistics.median(r['wall_seconds'] for r in rows),wall_range_seconds=[min(r['wall_seconds'] for r in rows),max(r['wall_seconds'] for r in rows)],cpu_median_seconds=statistics.median(r['user_seconds']+r['system_seconds'] for r in rows),peak_rss_kib=max(r['peak_rss_kib'] for r in rows),statuses=[r['status'] for r in rows],timeouts=sum(r['timed_out'] for r in rows),output_hashes=sorted(set(r['output_sha256'] for r in rows)))
profiles={}
for p in root.glob('profile-*.stderr'):
 spans=collections.defaultdict(list)
 for line in p.read_text().splitlines():
  if line.startswith('TS_COST '):
   _,name,ns=line.split();spans[name].append(int(ns))
 profiles[p.stem]={k:dict(calls=len(v),total_ms=sum(v)/1e6,max_ms=max(v)/1e6) for k,v in spans.items()}
outcomes={}
for p in root.glob('clean-baseline-*.json'):
 try:d=json.loads(p.read_text())
 except ValueError:continue
 findings=d.get('findings',[])
 outcomes[p.stem]=dict(summary=d.get('summary'),outcome=d.get('analysis_outcome'),related_test_rows=sum(len(f.get('related_tests',[])) for f in findings))
result=dict(summary=summary,profiles=profiles,outcomes=outcomes,preliminary_samples='baseline-* observations overlap a later compilation; excluded from isolated timing summary; retained as raw calibration evidence')
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print(json.dumps(profiles,indent=2))
