import subprocess, sys
from pathlib import Path
binary=sys.argv[1]
prefix=sys.argv[2] if len(sys.argv)>2 else 'baseline'
measure='/workspace/ts-cost-evidence/measure.py'
for trial in range(1,4):
 cache=f'/workspace/ts-cost-cache/{prefix}-zod-{trial}'
 for phase in ['cold','warm','unchanged']:
  subprocess.run([sys.executable,measure,binary,'/workspace/ts-cost-zod',cache,f'{prefix}-zod-{trial}-{phase}'],check=True)
for n in [1,64,512]:
 cache=f'/workspace/ts-cost-cache/{prefix}-control-{n}'
 for phase in ['cold','warm','unchanged']:
  subprocess.run([sys.executable,measure,binary,f'/workspace/ts-cost-control-{n}',cache,f'{prefix}-control-{n}-{phase}'],check=True)
