import json, hashlib
from pathlib import Path
root=Path('/workspace/ts-cost-evidence')
def read(label): return json.loads((root/(label+'.json')).read_bytes())
baseline=(root/'clean-baseline-zod-1-cold.json').read_bytes()
comparisons={}
for prefix in ['clean-baseline','profile']:
 for trial in range(1,4):
  for phase in ['cold','warm','unchanged']:
   label=f'{prefix}-zod-{trial}-{phase}'
   comparisons[label]=(root/(label+'.json')).read_bytes()==baseline
assert all(comparisons.values())
edits={}
for phase in ['source-edit','test-edit','config-edit','restored']:
 for trial in range(1,4):
  label=f'clean-baseline-zod-{phase}-{trial}'
  edits[label]=read(label)['findings']==json.loads(baseline)['findings']
assert all(edits.values())
controls={}
for n in [1,64,512]:
 for phase in ['cold','warm','unchanged']:
  label=f'clean-baseline-control-{n}-{phase}';d=read(label)
  assert d['summary']['probes']==d['summary']['findings']==d['summary']['weakly_exposed']==1
  assert d['analysis_outcome']['analysis_complete']
  assert sum(len(f.get('related_tests',[])) for f in d['findings'])>=1
  assert (root/(f'profile-control-{n}-{phase}.json')).read_bytes()==(root/(label+'.json')).read_bytes()
 controls[n]=dict(tests=n+1,probes=1,findings=1,class_name='weakly_exposed')
for i in range(1,4): assert read(f'clean-baseline-discriminator-{i}')['summary']['exposed']==1
assert (root/'clean-baseline-discriminator-restored.json').read_bytes()==(root/'clean-baseline-control-1-warm.json').read_bytes()
corrupt=read('corrupt-cache-receipt')
assert corrupt['status']==0 and corrupt['output_equals_baseline'] and corrupt['cache_bytes_restored']
assert '1 corrupt entry ignored' in (root/'corrupt-cache.stderr').read_text()
report=dict(zod_byte_equal=comparisons,zod_edit_findings_equal=edits,controls=controls,semantic_invalidation='relevant test edit changes one weakly_exposed finding to exposed; restoring original bytes restores exact output',corrupt_cache='checksum corruption ignored and recomputed; output and envelope bytes restored')
(root/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
