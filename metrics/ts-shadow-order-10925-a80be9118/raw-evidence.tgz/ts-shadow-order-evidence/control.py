import os,subprocess,sys,json
from pathlib import Path
out=Path('/workspace/ts-shadow-order-evidence')
bins={'baseline':'/workspace/ts-cost-evidence/baseline-ripr','candidate':'/workspace/ts-owner-evidence/candidate-ripr'}
receipts=[]
for shape in ['chain3','star16']:
 root=Path('/workspace/ts-shadow-order-'+shape);root.mkdir();(root/'src').mkdir();(root/'tests').mkdir()
 (root/'ripr.toml').write_text('[languages]\nenabled = ["typescript"]\n')
 (root/'package.json').write_text('{"name":"shadow-order-control","devDependencies":{"vitest":"^3.0.0"},"scripts":{"test":"vitest"}}\n')
 old='export function price(value: number): number {\n  if (value >= 100) return value - 20;\n  return value;\n}\n'
 (root/'src/pricing.ts').write_text(old)
 if shape=='chain3':
  (root/'src/barrel0.ts').write_text("export { price } from './pricing';\n")
  (root/'src/barrel1.ts').write_text("export { price } from './barrel0';\n")
  (root/'src/index.ts').write_text("export { price } from './barrel1';\n")
 else:
  (root/'src/index.ts').write_text("export * from './pricing';\n"+''.join(f"export * from './other{i}';\n" for i in range(15)))
  for i in range(15):(root/f'src/other{i}.ts').write_text(f'export const other{i} = {i};\n')
 imports="import { it, expect } from 'vitest';\nimport { price as cost } from '../src/index';\n"
 (root/'tests/real.test.ts').write_text(imports+"it('genuine price result', () => { expect(cost(200)).toBe(180); });\n")
 (root/'tests/shadow.test.ts').write_text(imports+''.join(f"it('shadow {i}', () => {{ const cost = (value: number) => value; expect(cost({i})).toBe({i}); }});\n" for i in range(256)))
 env=dict(os.environ,GIT_AUTHOR_DATE='2026-11-06T00:00:00Z',GIT_COMMITTER_DATE='2026-11-06T00:00:00Z')
 def git(*args):return subprocess.check_output(['git',*args],cwd=root,env=env,text=True).strip()
 git('init','-q');git('add','.');git('-c','user.name=Performance fixture','-c','user.email=fixture@example.invalid','commit','-qm','base')
 (root/'src/pricing.ts').write_text(old.replace('>= 100','> 100'));git('add','.');git('-c','user.name=Performance fixture','-c','user.email=fixture@example.invalid','commit','-qm','boundary edit')
 reference=None
 for trial in range(1,4):
  order=['baseline','candidate'] if trial%2 else ['candidate','baseline']
  for binary_name in order:
   cache=Path(f'/workspace/ts-shadow-order-cache/{shape}-{trial}-{binary_name}');assert not cache.exists()
   for state in ['cold','warm']:
    label=f'{shape}-{trial}-{binary_name}-{state}'
    subprocess.run([sys.executable,str(out/'measure.py'),bins[binary_name],str(root),str(cache),label],check=True)
    raw=(out/(label+'.json')).read_bytes();data=json.loads(raw)
    assert data['analysis_outcome']['analysis_complete'] and len(data['findings'])==1
    finding=data['findings'][0]
    assert finding['ripr']['reach']['state']=='yes' and len(finding['related_tests'])==1
    assert finding['related_tests'][0]['name']=='genuine price result'
    if reference is None:reference=raw
    assert raw==reference,(shape,trial,binary_name,state)
  receipts.append(dict(shape=shape,trial=trial,shadowed_calls=256,genuine_related_tests=1,all_cold_warm_baseline_candidate_stdout_equal=True,order=order))
 subprocess.run(['git','bundle','create',str(out/(shape+'.bundle')),'--all'],cwd=root,check=True)
 (out/(shape+'-identity.json')).write_text(json.dumps(dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}')),indent=2)+'\n')
(out/'correctness.json').write_text(json.dumps(receipts,indent=2)+'\n')
