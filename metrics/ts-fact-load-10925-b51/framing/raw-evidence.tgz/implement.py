from pathlib import Path
p=Path('/workspace/ripr-ts-cost/crates/ripr/src/analysis/language/typescript/fact_store.rs')
s=p.read_text()
s=s.replace('//! Integrity is the seam_cache contract: an unkeyed semantic digest over\n//! the serialized envelope;', '//! Integrity is the seam_cache contract: an unkeyed digest over the exact\n//! serialized envelope bytes;')
s=s.replace('TYPESCRIPT_FILE_FACT_SCHEMA_VERSION: &str = "6"','TYPESCRIPT_FILE_FACT_SCHEMA_VERSION: &str = "7"')
s=s.replace('    #[serde(default, skip_serializing)]\n    payload_digest: Option<String>,\n','')
s=s.replace('            payload_digest: None,\n','')
s=s.replace('    fn expected_digest(&self) -> Result<String, String> {','    #[cfg(test)]\n    fn expected_digest(&self) -> Result<String, String> {')
a=s.index('    fn validate_integrity(&self) -> Result<(), String> {')
b=s.index('\n}\n',a)
s=s[:a]+s[b:]
idx=s.index('/// Names the entry file in a corrupt-load reason')
s=s[:idx]+'''/// The checksum prefix is separate from the JSON body, so admission hashes
/// the stored bytes instead of serializing the decoded shared graph again.
const FRAME_HEADER_BYTES: usize = 72; // "sha256:" + 64 hex digits + newline

fn split_framed_entry(bytes: &[u8]) -> Result<(&[u8], &[u8]), String> {
    let header = bytes.get(..FRAME_HEADER_BYTES).ok_or("truncated fact frame")?;
    if !header.starts_with(b"sha256:")
        || header.last() != Some(&b'\\n')
        || !header.get(7..71).is_some_and(|hex| hex.iter().all(u8::is_ascii_hexdigit))
    {
        return Err("missing or malformed fact frame checksum".to_owned());
    }
    let digest = header.get(..71).ok_or("truncated frame checksum")?;
    let body = bytes.get(FRAME_HEADER_BYTES..).ok_or("truncated fact body")?;
    Ok((digest, body))
}

fn encode_framed_entry(envelope: &TypeScriptFileFactEnvelope) -> Result<Vec<u8>, String> {
    // One growing buffer holds the prefix and body; no second body allocation
    // or copy is needed, including for files containing thousands of tests.
    let mut bytes = Vec::with_capacity(128);
    bytes.resize(FRAME_HEADER_BYTES, b'\\n');
    {
        let _wire = super::types::SharedWireScope::open();
        serde_json::to_writer(&mut bytes, envelope)
            .map_err(|err| format!("encode typescript fact body: {err}"))?;
    }
    let body = bytes.get(FRAME_HEADER_BYTES..).ok_or("missing encoded fact body")?;
    let digest = seam_cache::semantic_digest_for_bytes(ENVELOPE_DIGEST_DOMAIN, body);
    let header = bytes.get_mut(..FRAME_HEADER_BYTES - 1).ok_or("missing frame header")?;
    if header.len() != digest.len() {
        return Err("unexpected fact checksum length".to_owned());
    }
    header.copy_from_slice(digest.as_bytes());
    Ok(bytes)
}

''' +s[idx:]
s=s.replace('''        let decoded = {
            let _wire = super::types::SharedWireScope::open();
            serde_json::from_slice::<TypeScriptFileFactEnvelope>(&bytes)
        };''','''        let (digest, body) = match split_framed_entry(&bytes) {
            Ok(frame) => frame,
            Err(reason) => return corrupt_entry(&path, reason),
        };
        let decoded = {
            let _wire = super::types::SharedWireScope::open();
            serde_json::from_slice::<TypeScriptFileFactEnvelope>(body)
        };''')
s=s.replace('''                if let Err(reason) = envelope.validate_integrity() {
                    return corrupt_entry(&path, reason);
                }''','''                // Preserve identity-miss precedence. No facts are served until
                // both current identity and the full stored-body checksum pass.
                let expected = seam_cache::semantic_digest_for_bytes(ENVELOPE_DIGEST_DOMAIN, body);
                if digest != expected.as_bytes() {
                    return corrupt_entry(&path, "mismatching fact frame checksum");
                }''')
a=s.index('        let digest = envelope.expected_digest()?;',s.index('pub(crate) fn store('))
b=s.index('        let approx_bytes = bytes.len();',a)
s=s[:a]+'        let bytes = encode_framed_entry(&envelope)?;\n'+s[b:]
s=s.replace('''    if let Some(header) = header_from_prefix(&prefix) {
        return Some(header);
    }
    serde_json::from_slice(&std::fs::read(path).ok()?).ok()''','''    let (_, body) = split_framed_entry(&prefix).ok()?;
    if let Some(header) = header_from_prefix(body) {
        return Some(header);
    }
    let bytes = std::fs::read(path).ok()?;
    let (_, body) = split_framed_entry(&bytes).ok()?;
    serde_json::from_slice(body).ok()''')
s=s.replace('assert_eq!(TYPESCRIPT_FILE_FACT_SCHEMA_VERSION, "6");','assert_eq!(TYPESCRIPT_FILE_FACT_SCHEMA_VERSION, "7");')
s=s.replace('''        let digest = stale.expected_digest()?;
        let bytes = seam_cache::encode_integrity_body(&stale, digest)?;''','''        let bytes = encode_framed_entry(&stale)?;''')
s=s.replace('''        let digest = current.expected_digest()?;
        let bytes = seam_cache::encode_integrity_body(&current, digest)?;''','''        let bytes = encode_framed_entry(&current)?;''')
s=s.replace('''        let digest = envelope.expected_digest()?;
        let bytes = seam_cache::encode_integrity_body(&envelope, digest)?;
        let decoded: TypeScriptFileFactEnvelope = serde_json::from_slice(&bytes)''','''        let bytes = encode_framed_entry(&envelope)?;
        let (digest, body) = split_framed_entry(&bytes)?;
        let decoded: TypeScriptFileFactEnvelope = serde_json::from_slice(body)''')
s=s.replace('        decoded.validate_integrity()?;','        assert_eq!(digest, seam_cache::semantic_digest_for_bytes(ENVELOPE_DIGEST_DOMAIN, body).as_bytes());')
s=s.replace('''        let digest = envelope.expected_digest()?;
        let mut bytes = seam_cache::encode_integrity_body(&envelope, digest)?;''','''        let mut bytes = encode_framed_entry(&envelope)?;''')
s=s.replace('''        if let Ok(decoded) = serde_json::from_slice::<TypeScriptFileFactEnvelope>(&bytes) {
            assert!(!decoded.matches_key(&key) || decoded.validate_integrity().is_err())
        }''','''        let (digest, body) = split_framed_entry(&bytes)?;
        assert_ne!(digest, seam_cache::semantic_digest_for_bytes(ENVELOPE_DIGEST_DOMAIN, body).as_bytes());''')
s=s.replace('        // A stale-schema envelope: the exact bytes the pre-#11250 ("3")\n        // binary wrote — same identity, valid integrity digest, older\n        // schema version — sitting at the entry path the current key\n        // computes, so only the version gate can refuse it.', '        // A synthetic old-schema body inside a valid current frame has the\n        // same identity and a valid checksum. Placing it at the current\n        // entry path isolates the schema gate from framing and lookup.')
p.write_text(s)
