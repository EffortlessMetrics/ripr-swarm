import hashlib,json,sys
from pathlib import Path
entries=list(Path(sys.argv[1]).glob('*.json')); total=0
for p in entries:
 data=p.read_bytes();marker=b',"payload_digest":"'
 body,sep,suffix=data.rpartition(marker)
 assert sep and suffix.endswith(b'"}'),p
 expected=suffix[:-2].decode();body+=b'}'
 assert hashlib.sha256(b'ripr-cache:TypeScriptFileFactEnvelope:v1\0'+body).hexdigest()==expected.removeprefix('sha256:'),p
 total+=len(body)
print(json.dumps(dict(entries=len(entries),total_body_bytes=total,status='all digests equal')))
