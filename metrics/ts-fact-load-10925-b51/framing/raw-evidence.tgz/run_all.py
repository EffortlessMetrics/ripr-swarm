from pathlib import Path
import subprocess,sys,time,json,datetime
out=Path('/workspace/ts-factload-evidence');baseline,candidate=sys.argv[1:];started=time.monotonic();started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
steps=[('paired_runs.py',[baseline,candidate]),('edit_loops.py',[baseline,'baseline']),('edit_loops.py',[candidate,'candidate']),('config_control.py',[baseline,'baseline']),('config_control.py',[candidate,'candidate']),('corruption_control.py',[candidate]),('compare_edits.py',[]),('cache_inventory.py',[]),('summarize.py',[])]
records=[]
for script,args in steps:
 begin=time.monotonic();print('BEGIN',script,args,flush=True)
 result=subprocess.run([sys.executable,str(out/script),*args])
 records.append(dict(script=script,status=result.returncode,wall_seconds=time.monotonic()-begin))
 (out/'orchestration.json').write_text(json.dumps(dict(started_utc=started_utc,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),steps=records,elapsed_seconds=time.monotonic()-started),indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
print('ALL_STEPS_COMPLETE',flush=True)
