import subprocess,hashlib,json,sys
from pathlib import Path
root=Path('/workspace/ripr-ts-cost')
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
paths=git('diff','--name-only','b51aebc7e4735529befd677ebf14071c7f09e477','HEAD').splitlines()
snapshot={'source':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain'),'files':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}}
assert snapshot['source']=='9c64ecada5fb4780aa4406eaf71f28b6e6ba4905' and not snapshot['status']
Path('/workspace/ts-factload-evidence/'+sys.argv[1]+'.json').write_text(json.dumps(snapshot,indent=2)+'\n')
