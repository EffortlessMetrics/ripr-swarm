import subprocess,sys,json
from pathlib import Path
binary=sys.argv[1];out=Path('/workspace/ts-factload-evidence')
subjects=[('zod','/workspace/ts-cost-zod','/workspace/ts-cost-evidence/clean-baseline-zod-1-warm.json'),('useful','/workspace/ts-owner-workload-2680','/workspace/ts-owner-evidence/paired-baseline-namespace-2680-1-warm.json')]
for name,root,reference in subjects:
 for trial in range(1,4):
  cache=Path(f'/workspace/ts-factload-cache/profile-{name}-{trial}');assert not cache.exists()
  for phase in ['cold','warm']:
   label=f'profile-{name}-{trial}-{phase}'
   subprocess.run([sys.executable,str(out/'measure.py'),binary,root,str(cache),label],check=True)
   raw=(out/(label+'.json')).read_bytes();d=json.loads(raw)
   assert d['analysis_outcome']['analysis_complete'] and d['findings']
   assert raw==Path(reference).read_bytes(),label
