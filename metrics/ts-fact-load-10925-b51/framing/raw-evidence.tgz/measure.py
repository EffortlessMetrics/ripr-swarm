import os, sys, time, json, signal, hashlib
from pathlib import Path

binary, root, cache, label = sys.argv[1:]
out = Path('/workspace/ts-factload-evidence')
cmd = [binary, 'check', '--base', 'HEAD~1', '--format', 'json', '--mode', 'draft']
started = time.monotonic()
pid = os.fork()
if pid == 0:
    os.setsid()
    os.chdir(root)
    stdout = os.open(out / (label+'.json'), os.O_WRONLY|os.O_CREAT|os.O_TRUNC, 0o600)
    stderr = os.open(out / (label+'.stderr'), os.O_WRONLY|os.O_CREAT|os.O_TRUNC, 0o600)
    os.dup2(stdout, 1); os.dup2(stderr, 2)
    env = dict(os.environ, RIPR_CACHE_DIR=cache, RIPR_PROGRESS='1', RAYON_NUM_THREADS='4')
    os.execve(binary, cmd, env)
timed_out = False
while True:
    waited, status, usage = os.wait4(pid, os.WNOHANG)
    if waited:
        break
    if time.monotonic()-started > 45:
        timed_out = True
        os.killpg(pid, signal.SIGKILL)
        waited, status, usage = os.wait4(pid, 0)
        break
    time.sleep(.005)
record = dict(label=label, command=cmd, root=root, cache=cache,
    wall_seconds=time.monotonic()-started, user_seconds=usage.ru_utime,
    system_seconds=usage.ru_stime, peak_rss_kib=usage.ru_maxrss,
    status=os.waitstatus_to_exitcode(status), timed_out=timed_out,
    output_sha256=hashlib.sha256((out/(label+'.json')).read_bytes()).hexdigest())
with (out/'measurements.jsonl').open('a') as f: f.write(json.dumps(record)+'\n')
print(json.dumps(record))
sys.exit(1 if timed_out else 0)
