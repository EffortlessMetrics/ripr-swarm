from pathlib import Path
import subprocess,sys,json,hashlib
out=Path('/workspace/ts-factload-evidence');binary=sys.argv[1]
root='/workspace/ts-owner-workload-2680';cache=Path('/workspace/ts-factload-cache/corruption-control');assert not cache.exists()
def run(label):
 subprocess.run([sys.executable,str(out/'measure_verbose.py'),binary,root,str(cache),label],check=True)
 d=json.loads((out/(label+'.json')).read_bytes());assert d['analysis_outcome']['analysis_complete']
 assert len(d['findings'])==2 and all(f['related_tests'] and f['ripr']['reach']['state']=='yes' for f in d['findings'])
 return (out/(label+'.json')).read_bytes()
clean=run('corruption-seed');assert run('corruption-warm')==clean
entries=list((cache/'typescript-file-facts'/'7').glob('*.json'));assert entries
entry=next(p for p in entries if json.loads(p.read_bytes().split(b'\n',1)[1])['file_path']=='src/pricing.ts')
original=entry.read_bytes();header,body=original.split(b'\n',1);obj=json.loads(body)
assert obj['file_facts']['parse_error'] is None
obj['file_facts']['parse_error']='deliberate-corruption'
entry.write_bytes(header+b'\n'+json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode())
assert run('corruption-recomputed')==clean
recovered=entry.read_bytes();assert recovered==original
assert run('corruption-restored-warm')==clean
(out/'corruption-correctness.json').write_text(json.dumps(dict(entry=str(entry),nonempty_useful_reach=True,all_semantic_bytes_equal=True,recovered_bytes_identical=True,original_sha256=hashlib.sha256(original).hexdigest()),indent=2)+'\n')
