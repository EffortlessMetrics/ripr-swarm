import subprocess, sys, json
from pathlib import Path
binary=sys.argv[1];prefix=sys.argv[2]
root=Path('/workspace/ts-owner-workload-2680')
source=root/'src/pricing.ts';test=root/'tests/pricing.test.ts'
original_source=source.read_bytes();original_test=test.read_bytes()
out=Path('/workspace/ts-factload-evidence')
def run(cache,label):
 subprocess.run([sys.executable,str(out/'measure.py'),binary,str(root),str(cache),label],check=True)
 data=json.loads((out/(label+'.json')).read_bytes())
 assert data['analysis_outcome']['analysis_complete']
 assert len(data['findings'])==2
 assert all(f['related_tests'] and f['ripr']['reach']['state']=='yes' for f in data['findings'])
 return data
comparisons=[]
try:
 for kind in ['production','assertion']:
  for trial in range(1,4):
   assert source.read_bytes()==original_source and test.read_bytes()==original_test
   cache=Path(f'/workspace/ts-factload-cache/{prefix}-{kind}-{trial}')
   stem=f'{prefix}-{kind}-{trial}'
   run(cache,stem+'-seed');clean=run(cache,stem+'-clean-warm')
   if kind=='production':source.write_bytes(original_source.replace(b'> 100',b'> 101'))
   else:test.write_bytes(original_test.replace(b'pricing.total(200)).toBe(180)',b'pricing.total(100)).toBe(100)'))
   warm=run(cache,stem+'-edited-warm')
   cold=run(Path(str(cache)+'-independent-cold'),stem+'-edited-cold')
   assert (out/(stem+'-edited-warm.json')).read_bytes()==(out/(stem+'-edited-cold.json')).read_bytes()
   if kind=='production':assert all('101' in f['probe']['expression'] for f in warm['findings'])
   else:assert next(f for f in warm['findings'] if f['probe']['owner'].endswith('::total'))['classification']=='exposed'
   source.write_bytes(original_source);test.write_bytes(original_test)
   restored=run(cache,stem+'-restored-warm')
   assert (out/(stem+'-restored-warm.json')).read_bytes()==(out/(stem+'-clean-warm.json')).read_bytes()
   comparisons.append(dict(kind=kind,trial=trial,complete=True,findings=2,nonempty_related_tests=True,all_semantic_bytes_equal_warm_cold=True,restored_bytes_equal=True,classes=[f['classification'] for f in warm['findings']]))
finally:
 source.write_bytes(original_source);test.write_bytes(original_test)
(out/(prefix+'-edit-correctness.json')).write_text(json.dumps(comparisons,indent=2)+'\n')
