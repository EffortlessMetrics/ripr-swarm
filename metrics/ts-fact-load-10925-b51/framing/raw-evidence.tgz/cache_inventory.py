from pathlib import Path
import json
base=Path('/workspace/ts-factload-cache');rows=[]
for name in ['baseline','candidate']:
 for workload in ['zod','namespace-1','namespace-2680']:
  root=base/f'paired-{name}-{workload}-1'/'typescript-file-facts'/('6' if name=='baseline' else '7')
  entries=list(root.glob('*.json'));assert entries,root
  rows.append(dict(binary=name,workload=workload,schema=root.name,entries=len(entries),total_bytes=sum(p.stat().st_size for p in entries),largest_entry_bytes=max(p.stat().st_size for p in entries)))
Path('/workspace/ts-factload-evidence/cache-inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
