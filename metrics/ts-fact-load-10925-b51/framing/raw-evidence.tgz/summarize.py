import json,statistics
from pathlib import Path
out=Path('/workspace/ts-factload-evidence')
rows=[json.loads(x) for x in (out/'measurements.jsonl').read_text().splitlines()]
def stat(rs):
 return {key:{'median':statistics.median(vals),'range':[min(vals),max(vals)]} for key,vals in [('wall_ms',[x['wall_seconds']*1000 for x in rs]),('cpu_ms',[(x['user_seconds']+x['system_seconds'])*1000 for x in rs]),('rss_mib',[x['peak_rss_kib']/1024 for x in rs])]}
summary={}
for workload in ['zod','namespace-1','namespace-2680']:
 for phase in ['cold','warm','unchanged']:
  for name in ['baseline','candidate']:
   rs=[r for r in rows if r['label'].startswith(f'paired-{name}-{workload}-') and r['label'].endswith('-'+phase)]
   if rs:summary[f'{name}/{workload}/{phase}']={'n':len(rs),**stat(rs),'statuses':[r['status'] for r in rs],'timeouts':sum(r['timed_out'] for r in rs)}
for name in ['baseline','candidate']:
 for kind in ['production','assertion','config']:
  for phase in ['clean-warm','edited-warm','edited-cold','restored-warm']:
   rs=[r for r in rows if r['label'].startswith(f'{name}-{kind}-') and r['label'].endswith('-'+phase)]
   if rs:summary[f'{name}/{kind}/{phase}']={'n':len(rs),**stat(rs),'statuses':[r['status'] for r in rs],'timeouts':sum(r['timed_out'] for r in rs)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
