from pathlib import Path
import os,time,signal,json,hashlib
out=Path('/workspace/ts-factload-evidence');rows=[]
binaries={'baseline':'/workspace/ts-cost-evidence/baseline-ripr','candidate':str(out/'candidate-ripr')}
for mode in ['help','small-warm','large-warm']:
 for trial in range(1,4):
  names=['baseline','candidate'] if trial%2 else ['candidate','baseline']
  for name in names:
   root='/workspace/ts-owner-workload-'+('1' if mode=='small-warm' else '2680')
   cache='/workspace/ts-factload-cache/paired-'+name+'-namespace-'+('1' if mode=='small-warm' else '2680')+'-1'
   label=f'memory-{mode}-{name}-{trial}'
   cmd=[binaries[name],'--help'] if mode=='help' else [binaries[name],'check','--base','HEAD~1','--format','json','--mode','draft']
   pid=os.fork();start=time.monotonic()
   if pid==0:
    os.setsid();os.chdir(root)
    for fd,suffix in [(1,'.stdout'),(2,'.stderr')]:
     f=os.open(out/(label+suffix),os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600);os.dup2(f,fd)
    os.execve(cmd[0],cmd,dict(os.environ,RIPR_CACHE_DIR=cache,RIPR_PROGRESS='1',RAYON_NUM_THREADS='4'))
   peaks={};snapshots=[];timed_out=False;latest=0
   while True:
    waited,status,usage=os.wait4(pid,os.WNOHANG)
    if waited:break
    try:
     raw=Path(f'/proc/{pid}/status').read_text();fields={}
     for line in raw.splitlines():
      key,_,value=line.partition(':')
      if key in ['VmRSS','VmHWM','RssAnon','RssFile','RssShmem']:fields[key]=int(value.strip().split()[0])
     for key,value in fields.items():peaks[key]=max(peaks.get(key,0),value)
     if fields.get('VmRSS',0)>latest:
      latest=fields['VmRSS'];rollup=Path(f'/proc/{pid}/smaps_rollup').read_text()
      snapshots.append(dict(elapsed_seconds=time.monotonic()-start,status=fields,smaps_rollup=rollup))
    except (OSError,ProcessLookupError):pass
    if time.monotonic()-start>45:
     timed_out=True;os.killpg(pid,signal.SIGKILL);_,status,usage=os.wait4(pid,0);break
    time.sleep(.0005)
   output=(out/(label+'.stdout')).read_bytes()
   if mode!='help':
    data=json.loads(output);assert data['analysis_outcome']['analysis_complete'] and len(data['findings'])==2
    assert output==(out/f'paired-{name}-namespace-'+('1' if mode=='small-warm' else '2680')+'-1-warm.json').read_bytes()
   row=dict(label=label,mode=mode,binary=name,trial=trial,status=os.waitstatus_to_exitcode(status),timed_out=timed_out,peak_rss_kib=usage.ru_maxrss,observed_peaks_kib=peaks,snapshots=snapshots,output_sha256=hashlib.sha256(output).hexdigest())
   rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='snapshots'}),flush=True)
   assert row['status']==0 and not timed_out
(out/'memory-diagnostics.json').write_text(json.dumps(rows,indent=2)+'\n')
