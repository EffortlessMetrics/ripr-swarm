from pathlib import Path
p=Path('/workspace/ripr-ts-cost/crates/ripr/src/analysis/language/typescript/fact_store.rs')
s=p.read_text();idx=s.index('    #[test]\n    fn schema_version_pins_ast_probe_shape_facts')
s=s[:idx]+'''    #[test]
    fn framing_corruption_truncation_and_identity_precedence() -> Result<(), String> {
        let fixture = framing_fixture("ts-frame-integrity")?;
        let envelope = fixture_envelope(&fixture);
        let bytes = encode_framed_entry(&envelope)?;
        // Both valid JSON with a changed served field and a changed checksum
        // are corruption. A JSON decode failure is not the sole protection.
        let (_, body) = split_framed_entry(&bytes)?;
        let changed = String::from_utf8(body.to_vec()).map_err(|err| err.to_string())?
            .replace("first π", "other π");
        assert_ne!(body, changed.as_bytes());
        let mut changed_body = bytes.get(..FRAME_HEADER_BYTES).ok_or("header missing")?.to_vec();
        changed_body.extend_from_slice(changed.as_bytes());
        let mut changed_digest = bytes.clone();
        if let Some(byte) = changed_digest.get_mut(7) {
            *byte = if *byte == b'0' { b'1' } else { b'0' };
        }
        for corrupt in [changed_body, changed_digest, bytes.get(..20).ok_or("prefix missing")?.to_vec(), bytes.get(..bytes.len() - 1).ok_or("body missing")?.to_vec()] {
            write_fixture_entry(&fixture, &corrupt)?;
            assert!(matches!(fixture.store.load(&fixture.key), CacheLoad::CorruptIgnored { .. }));
        }
        // Identity still takes precedence over a bad checksum, as it did in
        // schema 6. Neither a foreign root nor a changed alias map may hit.
        for foreign in [
            TypeScriptFileFactKey { workspace_root_hash: "foreign-root".to_owned(), ..fixture.key.clone() },
            TypeScriptFileFactKey { alias_digest: (13, 17), ..fixture.key.clone() },
        ] {
            let mut invalid = bytes.clone();
            if let Some(byte) = invalid.get_mut(7) { *byte = b'!'; }
            // Keep framing syntactically valid while making the digest wrong.
            if let Some(byte) = invalid.get_mut(7) { *byte = if bytes.get(7) == Some(&b'0') { b'1' } else { b'0' }; }
            write_fixture_entry(&fixture, &invalid)?;
            assert!(matches!(fixture.store.load(&foreign), CacheLoad::Miss));
        }
        write_fixture_entry(&fixture, &bytes)?;
        assert_served_graph(fixture.store.load(&fixture.key), &fixture)?;
        assert!(fixture.store.knows_file("tests/pricing.test.ts"));
        Ok(())
    }

''' +s[idx:]
s=s.replace('''            if let Some(byte) = invalid.get_mut(7) { *byte = b'!'; }
            // Keep framing syntactically valid while making the digest wrong.
''','''            // Keep framing syntactically valid while making the digest wrong.
''')
p.write_text(s)
