from pathlib import Path
p=Path('/workspace/ripr-ts-cost/crates/ripr/src/analysis/language/typescript/fact_store.rs')
t=p.read_text()
old='''    pub(crate) fn load(&self, key: &TypeScriptFileFactKey) -> CacheLoad<PersistedFileFacts> {
'''
new=old+'''        let _overall = FactLoadSpan::new("overall");
'''
assert t.count(old)==1;t=t.replace(old,new)
old='''        let bytes = match std::fs::read(&path) {'''
new='''        let bytes = match {
            let _stage = FactLoadSpan::new("read");
            std::fs::read(&path)
        } {'''
assert t.count(old)==1;t=t.replace(old,new)
old='''        let decoded = {
            let _wire = super::types::SharedWireScope::open();'''
new='''        let decoded = {
            let _stage = FactLoadSpan::new("decode");
            let _wire = super::types::SharedWireScope::open();'''
assert t.count(old)==1;t=t.replace(old,new)
old='''                if let Err(reason) = envelope.validate_integrity() {'''
new='''                if let Err(reason) = {
                    let _stage = FactLoadSpan::new("digest_reserialize");
                    envelope.validate_integrity()
                } {'''
assert t.count(old)==1;t=t.replace(old,new)
old='''                    super::types::reshare_file_lists(tests);'''
new='''                    let _stage = FactLoadSpan::new("reshare");
                    super::types::reshare_file_lists(tests);'''
assert t.count(old)==1;t=t.replace(old,new)
t+='''
// Disposable component profile; never part of the repair candidate.
thread_local! {
    static FACT_LOAD_COST: std::cell::RefCell<std::collections::BTreeMap<&'static str, (usize,u128)>> = const { std::cell::RefCell::new(std::collections::BTreeMap::new()) };
}
struct FactLoadSpan { name: &'static str, started: std::time::Instant }
impl FactLoadSpan { fn new(name: &'static str) -> Self { Self { name, started: std::time::Instant::now() } } }
impl Drop for FactLoadSpan {
    fn drop(&mut self) {
        let ns = self.started.elapsed().as_nanos();
        FACT_LOAD_COST.with(|cost| { let mut cost=cost.borrow_mut(); let e=cost.entry(self.name).or_default(); e.0+=1; e.1+=ns; });
    }
}
impl Drop for TypeScriptFileFactStore {
    fn drop(&mut self) {
        FACT_LOAD_COST.with(|cost| {
            for (name,(calls,ns)) in std::mem::take(&mut *cost.borrow_mut()) { eprintln!("TS_FACT_LOAD {name} {calls} {ns}"); }
        });
    }
}
'''
p.write_text(t)
