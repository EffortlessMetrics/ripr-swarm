from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path('/workspace/ts-fact-load-findings/metrics/ts-fact-load-10925-b51')
results={}
for name,source in [('byte-admission',Path('/workspace/ts-fact-byte-evidence')),('framing',Path('/workspace/ts-factload-evidence'))]:
 excluded={'candidate-ripr','profile-ripr','red-tests','RAW_MANIFEST.json'}
 files=[p for p in sorted(source.rglob('*')) if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts]
 entries=[]
 for p in files:
  with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
  entries.append(dict(path=str(p.relative_to(source)),bytes=p.stat().st_size,sha256=digest))
 manifest=source/'RAW_MANIFEST.json';manifest.write_text(json.dumps(dict(files=entries,excluded_binaries=['candidate-ripr','profile-ripr','red-tests'],note='Binary identities are retained; executable payloads are excluded. This manifest excludes its own hash.'),indent=2)+'\n')
 archive=root/name/'raw-evidence.tgz'
 with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
  for p in files+[manifest]:tar.add(p,arcname=str(p.relative_to(source)),recursive=False)
 with archive.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 results[name]=dict(archive=str(archive.relative_to(root)),bytes=archive.stat().st_size,sha256=digest,files=len(entries)+1)
(root/'archives.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
