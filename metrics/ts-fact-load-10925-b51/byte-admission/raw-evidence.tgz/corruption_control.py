from pathlib import Path
import subprocess,sys,json,hashlib
out=Path('/workspace/ts-fact-byte-evidence');binary=sys.argv[1]
root='/workspace/ts-owner-workload-2680';cache=Path('/workspace/ts-fact-byte-cache/corruption-control');assert not cache.exists()
def run(label):
 subprocess.run([sys.executable,str(out/'measure_verbose.py'),binary,root,str(cache),label],check=True)
 d=json.loads((out/(label+'.json')).read_bytes());assert d['analysis_outcome']['analysis_complete']
 assert len(d['findings'])==2 and all(f['related_tests'] and f['ripr']['reach']['state']=='yes' for f in d['findings'])
 return (out/(label+'.json')).read_bytes()
clean=run('corruption-seed');assert run('corruption-warm')==clean
entries=list((cache/'typescript-file-facts'/'6').glob('*.json'));assert entries
entry=next(p for p in entries if json.loads(p.read_bytes())['file_path']=='src/pricing.ts')
original=entry.read_bytes();obj=json.loads(original)
assert obj['file_facts']['parse_error'] is None
obj['file_facts']['parse_error']='deliberate-corruption'
entry.write_bytes(json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode())
assert run('corruption-recomputed')==clean
assert entry.read_bytes()==original
assert run('corruption-restored-warm')==clean
# A valid foreign-build body at the current filename remains an identity miss,
# even though its stored checksum is correct. No cached analysis is ported.
legacy_root=Path('/workspace/ts-factload-cache/paired-baseline-namespace-2680-1/typescript-file-facts/6')
legacy=next(p for p in legacy_root.glob('*.json') if json.loads(p.read_bytes())['file_path']=='src/pricing.ts')
foreign=legacy.read_bytes();assert json.loads(foreign)['analyzer_version']!=json.loads(original)['analyzer_version']
entry.write_bytes(foreign)
assert run('foreign-build-recomputed')==clean
assert entry.read_bytes()==original
assert run('foreign-build-restored-warm')==clean
(out/'corruption-correctness.json').write_text(json.dumps(dict(entry=str(entry),nonempty_useful_reach=True,all_semantic_bytes_equal=True,recovered_bytes_identical=True,foreign_build_identity_refused=True,original_sha256=hashlib.sha256(original).hexdigest()),indent=2)+'\n')
