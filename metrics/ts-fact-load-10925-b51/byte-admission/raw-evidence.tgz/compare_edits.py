from pathlib import Path
import json,re
out=Path('/workspace/ts-fact-byte-evidence');rows=[]
for baseline in sorted(out.glob('baseline-*.json')):
 if not re.fullmatch(r'baseline-(production|assertion|config)-[1-3]-(seed|clean-warm|edited-warm|edited-cold|restored-warm)',baseline.stem):continue
 candidate=out/baseline.name.replace('baseline-','candidate-',1)
 assert candidate.exists(),candidate
 assert baseline.read_bytes()==candidate.read_bytes(),(baseline,candidate)
 rows.append({'baseline':baseline.name,'candidate':candidate.name,'all_semantic_bytes_equal':True})
assert len(rows)==45,len(rows)
(out/'edit-cross-binary-correctness.json').write_text(json.dumps(rows,indent=2)+'\n')
