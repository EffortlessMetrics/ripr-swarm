from pathlib import Path
import subprocess
p=Path('/workspace/ripr-ts-cost/crates/ripr/src/analysis/language/typescript/fact_store.rs');s=p.read_text()
s=s.replace('''        let bytes = seam_cache::encode_integrity_body(&envelope, digest)?;
        let decoded:''','''        let mut bytes = seam_cache::encode_integrity_body(&envelope, digest)?;
        let decoded:''')
s=s.replace('decoded.validate_integrity()?;','decoded.validate_integrity(&mut bytes)?;').replace('decoded.validate_integrity().is_err()','decoded.validate_integrity(&mut bytes).is_err()')
old=subprocess.check_output(['git','show','9c64ecada:crates/ripr/src/analysis/language/typescript/fact_store.rs'],cwd='/workspace/ripr-ts-cost',text=True)
parts=[]
parts.append(old[old.index('    const FRAMING_TEST_SOURCE:'):old.index('    fn compact_wire_body(')])
parts.append(old[old.index('    fn write_fixture_entry('):old.index('    #[test]\n    fn framing_digest_equals_')])
extra='''    #[test]
    fn admission_preserves_noncompact_semantic_entries() -> Result<(), String> {
        let fixture = framing_fixture("ts-byte-noncompact")?;
        let envelope = fixture_envelope(&fixture);
        let digest = envelope.expected_digest()?;
        let pretty = {
            let _wire = super::super::types::SharedWireScope::open();
            seam_cache::encode_integrity_body(&envelope, digest.clone())?
        };
        let compact = {
            let _wire = super::super::types::SharedWireScope::open();
            seam_cache::encode_integrity_body_compact(&envelope, digest)?
        };
        let mut whitespace = compact;
        whitespace.insert(1, b' ');
        for bytes in [pretty, whitespace] {
            write_fixture_entry(&fixture, &bytes)?;
            let before = ENVELOPE_RESERIALIZATIONS.with(std::cell::Cell::get);
            assert_served_graph(fixture.store.load(&fixture.key), &fixture)?;
            assert_eq!(ENVELOPE_RESERIALIZATIONS.with(std::cell::Cell::get) - before, 1,
                "noncompact input retains the original semantic verification");
            assert_eq!(std::fs::read(fixture.store.entry_path(Path::new("tests/pricing.test.ts"), FRAMING_TEST_SOURCE)).map_err(|err| err.to_string())?, bytes,
                "loading never rewrites the entry file");
        }
        Ok(())
    }

    #[test]
    fn admission_preserves_canonical_wire_and_foreign_key_precedence() -> Result<(), String> {
        let fixture = framing_fixture("ts-byte-integrity")?;
        assert!(fixture.store.store(&fixture.key, &fixture.facts, Some(&fixture.extraction), None)?);
        let entry = fixture.store.entry_path(Path::new("tests/pricing.test.ts"), FRAMING_TEST_SOURCE);
        let original = std::fs::read(&entry).map_err(|err| err.to_string())?;
        assert_eq!(original.first(), Some(&b'{'));
        assert_served_graph(fixture.store.load(&fixture.key), &fixture)?;
        assert_eq!(std::fs::read(&entry).map_err(|err| err.to_string())?, original);
        let corrupt = String::from_utf8(original.clone()).map_err(|err| err.to_string())?
            .replace("first π", "other π").into_bytes();
        assert_ne!(original, corrupt);
        write_fixture_entry(&fixture, &corrupt)?;
        for foreign in [
            TypeScriptFileFactKey { workspace_root_hash: "foreign".to_owned(), ..fixture.key.clone() },
            TypeScriptFileFactKey { alias_digest: (13, 17), ..fixture.key.clone() },
        ] {
            assert!(matches!(fixture.store.load(&foreign), CacheLoad::Miss));
        }
        assert!(matches!(fixture.store.load(&fixture.key), CacheLoad::CorruptIgnored { .. }));
        write_fixture_entry(&fixture, &original)?;
        assert_served_graph(fixture.store.load(&fixture.key), &fixture)?;
        Ok(())
    }

'''
block=''.join(parts)+extra
# Retain the already-proven real-store work-count witness verbatim. The
# historical test name is not an assertion about an on-disk frame prefix.
assert 'fn framing_warm_load_serves_facts_without_reserializing_the_envelope' in block
s=s.replace('mod tests {\n    use super::*;\n','mod tests {\n    use super::*;\n\n'+block,1)
p.write_text(s)
