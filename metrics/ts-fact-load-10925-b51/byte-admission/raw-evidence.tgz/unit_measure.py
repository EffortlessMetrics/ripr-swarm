from pathlib import Path
import subprocess,resource,time,json,os,signal,sys
label,filter_,threads=sys.argv[1:];out=Path('/workspace/ts-fact-byte-evidence');start=time.monotonic();timed_out=False
cmd=['/workspace/ts-cost-target/debug/deps/ripr-7d47b7129eb8ed1f',filter_,'--test-threads='+threads]
with (out/(label+'.log')).open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:status=p.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGKILL);status=p.wait()
r=resource.getrusage(resource.RUSAGE_CHILDREN)
(out/(label+'.resources.json')).write_text(json.dumps(dict(command=cmd,status=status,timed_out=timed_out,wall_seconds=time.monotonic()-start,user_seconds=r.ru_utime,system_seconds=r.ru_stime,peak_rss_kib=r.ru_maxrss),indent=2)+'\n')
raise SystemExit(status if status>=0 else 1)
