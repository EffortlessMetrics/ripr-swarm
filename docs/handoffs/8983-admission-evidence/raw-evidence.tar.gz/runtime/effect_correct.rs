use std::cell::RefCell;

pub struct Notifier {
    pub sent: RefCell<Vec<String>>,
}

impl Notifier {
    pub fn new() -> Self {
        Notifier { sent: RefCell::new(Vec::new()) }
    }
    pub fn send(&self, payload: &str) -> bool {
        self.sent.borrow_mut().push(payload.to_string());
        true
    }
}

pub fn process_order(notifier: &Notifier, order_id: &str) -> bool {
    notifier.send(order_id)
}

#[cfg(test)]
mod tests_assert_ne_direct {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
assert_ne!(notifier.sent.borrow().first().map(String::as_str), Some("static_msg"));
}
}
#[cfg(test)]
mod tests_assert_ne_block_return {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
{ return; }
assert_ne!(notifier.sent.borrow().first().map(String::as_str), Some("static_msg"));
}
}
#[cfg(test)]
mod tests_assert_ne_fn_uncalled {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
fn never_called(notifier: &Notifier) {
assert_ne!(notifier.sent.borrow().first().map(String::as_str), Some("static_msg"));
}
}
}
#[cfg(test)]
mod tests_debug_assert_eq_direct {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
debug_assert_eq!(notifier.sent.borrow().first().map(String::as_str), Some("order-42"));
}
}
#[cfg(test)]
mod tests_debug_assert_eq_block_return {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
{ return; }
debug_assert_eq!(notifier.sent.borrow().first().map(String::as_str), Some("order-42"));
}
}
#[cfg(test)]
mod tests_debug_assert_eq_fn_uncalled {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
fn never_called(notifier: &Notifier) {
debug_assert_eq!(notifier.sent.borrow().first().map(String::as_str), Some("order-42"));
}
}
}
#[cfg(test)]
mod tests_debug_assert_direct {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
debug_assert!(notifier.sent.borrow().first().map(String::as_str) == Some("order-42"));
}
}
#[cfg(test)]
mod tests_debug_assert_block_return {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
{ return; }
debug_assert!(notifier.sent.borrow().first().map(String::as_str) == Some("order-42"));
}
}
#[cfg(test)]
mod tests_debug_assert_fn_uncalled {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
fn never_called(notifier: &Notifier) {
debug_assert!(notifier.sent.borrow().first().map(String::as_str) == Some("order-42"));
}
}
}
#[cfg(test)]
mod tests_debug_assert_ne_direct {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
debug_assert_ne!(notifier.sent.borrow().first().map(String::as_str), Some("static_msg"));
}
}
#[cfg(test)]
mod tests_debug_assert_ne_block_return {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
{ return; }
debug_assert_ne!(notifier.sent.borrow().first().map(String::as_str), Some("static_msg"));
}
}
#[cfg(test)]
mod tests_debug_assert_ne_fn_uncalled {
use super::*;
#[test]
fn process_order_observed() {
let notifier = Notifier::new();
process_order(&notifier, "order-42");
fn never_called(notifier: &Notifier) {
debug_assert_ne!(notifier.sent.borrow().first().map(String::as_str), Some("static_msg"));
}
}
}
