pub fn compute_score(base: i32) -> i32 {
    base + 1
}

#[cfg(test)]
mod tests_assert_ne_direct {
use super::*;
#[test]
fn compute_score_observed() {

assert_ne!(compute_score(4), 5);
}
}
#[cfg(test)]
mod tests_assert_ne_block_return {
use super::*;
#[test]
fn compute_score_observed() {

{ return; }
assert_ne!(compute_score(4), 5);
}
}
#[cfg(test)]
mod tests_assert_ne_fn_uncalled {
use super::*;
#[test]
fn compute_score_observed() {

fn never_called() {
assert_ne!(compute_score(4), 5);
}
}
}
#[cfg(test)]
mod tests_debug_assert_eq_direct {
use super::*;
#[test]
fn compute_score_observed() {

debug_assert_eq!(compute_score(4), 8);
}
}
#[cfg(test)]
mod tests_debug_assert_eq_block_return {
use super::*;
#[test]
fn compute_score_observed() {

{ return; }
debug_assert_eq!(compute_score(4), 8);
}
}
#[cfg(test)]
mod tests_debug_assert_eq_fn_uncalled {
use super::*;
#[test]
fn compute_score_observed() {

fn never_called() {
debug_assert_eq!(compute_score(4), 8);
}
}
}
#[cfg(test)]
mod tests_debug_assert_direct {
use super::*;
#[test]
fn compute_score_observed() {

debug_assert!(compute_score(4) == 8);
}
}
#[cfg(test)]
mod tests_debug_assert_block_return {
use super::*;
#[test]
fn compute_score_observed() {

{ return; }
debug_assert!(compute_score(4) == 8);
}
}
#[cfg(test)]
mod tests_debug_assert_fn_uncalled {
use super::*;
#[test]
fn compute_score_observed() {

fn never_called() {
debug_assert!(compute_score(4) == 8);
}
}
}
#[cfg(test)]
mod tests_debug_assert_ne_direct {
use super::*;
#[test]
fn compute_score_observed() {

debug_assert_ne!(compute_score(4), 5);
}
}
#[cfg(test)]
mod tests_debug_assert_ne_block_return {
use super::*;
#[test]
fn compute_score_observed() {

{ return; }
debug_assert_ne!(compute_score(4), 5);
}
}
#[cfg(test)]
mod tests_debug_assert_ne_fn_uncalled {
use super::*;
#[test]
fn compute_score_observed() {

fn never_called() {
debug_assert_ne!(compute_score(4), 5);
}
}
}
