Bounded attribution proof handoff for the existing source/proof owner — no source-branch write or ownership change.

Subject: canonical `b4f04013c237dd034a5009dbfd46d45bef7e4733`, tree `7e492961111b702e54570142cd189f5fdada75b8`, PR base `97df16cb946c7f5af0b34760d5be69a879139ffd`; #9490 slice 3 / RIPR-SPEC-0265 rule 5. PR reread OPEN / Draft / unchanged. Read the current 12-file diff, issue decisions, all comments/reviews/threads and current check summary before this pass.

**Distinct evidence contribution:** a closure's result can be computed and then replaced, or a test can reach the changed owner but assert a same-name rival. These are different stimuli from merely returning an unapplied closure. Long `captured` / `argument` names intentionally challenge the already-owned lexical fallback, rather than relying on the short-name filter. Also retained an exact-looking assertion inside a closure that never runs and two observing controls. The arithmetic, identifier and long-name fallback defects are already tracked in [the existing review](https://github.com/EffortlessMetrics/ripr-swarm/pull/9890#pullrequestreview-5630552557) and [the active joined-repair continuation](https://github.com/EffortlessMetrics/ripr-swarm/pull/9890#issuecomment-6368283169); this is not a duplicate source-defect finding.

All eight original fixtures compile and run one test each successfully. Replace **only the top-level target owner's** `move |argument| captured + argument` with `move |argument| captured - argument`; leave the rival unchanged. The two observing mutants fail by assertion (native 101). All six nonobserving mutants still pass (native 0). At `(2)(3)` the target results are 5 and -1, so those six passes reflect missing observation rather than globally equivalent bodies. No setup, compile, or zero-test failure was counted as discrimination.

| Fixture | Original / mutant compile | Original / mutant test |
| --- | --- | --- |
| direct_result_observed | 0 / 0 | 0 / 101 |
| qualified_result_observed_despite_rival_import | 0 / 0 | 0 / 101 |
| applied_result_overwritten | 0 / 0 | 0 / 0 |
| applied_result_shadowed | 0 / 0 | 0 / 0 |
| returned_closure_replaced_before_invocation | 0 / 0 | 0 / 0 |
| qualified_rival_assertion_after_discarded_owner_result | 0 / 0 | 0 / 0 |
| imported_rival_assertion_after_discarded_owner_result | 0 / 0 | 0 / 0 |
| exact_assertion_inside_uninvoked_closure | 0 / 0 | 0 / 0 |

Linux x86_64, existing task-local `rustc 1.95.0 (59807616e 2026-04-14)`; `rustc --edition=2024 --test SOURCE -C debuginfo=0 -o EXE`, then `EXE --test-threads=1`. Sixteen native executions; eight tests per variant, none ignored. Original driver SHA256 `f2db4c58a3823fdfca56ef2f7ace7eac980ff6c6aebabf887798dbef52f90951`. Complete source/executable identities are in the folded receipt below.

**Analyzer boundary:** no `ripr` build or analyzer test was started. The pre-existing local CLI reports unrelated source `b06b6917...` and was not used as current evidence. The proposed eight API assertions below are **not executed**; their only completed checks are Rustfmt parse/format and `git apply --check --whitespace=error` exit 0 at canonical `b4f0401`. I do not claim a new false `exposed`, a repair pass, corpus success, or merge clearance. Source inspection: `let_bound_owner_call` rejects mutable or multiply bound values; `OwnerReturnPin::admits_candidate` applies identity checks to the asserted callee. These tests challenge an alternate confirmation route bypassing those refusals; they do not broaden alias support.

The isolated proposal `8a6e68ad7f0a563e7f8818bc03a3ca48f2a97db0` named by the active continuation was not retrievable through the repository contents API (404, no commit found). This is **missing proposal source**, not evidence of permission denial or service outage. I have not inspected, adopted, or qualified it. Existing canonical writer/source custody remains in place. The three blocking threads remain unresolved. Exact canonical Actions observations: Source of Truth 39982646174 success, ub-review 39982646305 success, CI 39982646217 skipped; these are not required Rust qualification.

**Next executable step:** the existing lead can append/adopt the bounded test module after accepting custody, then run `cargo test --locked -p ripr --test returned_closure_pin` against the actual joined-repair source/build it already owns. Record eight selected new tests, classification output on any failure, and the exact subject. Preserve the two observing controls; conservatively withhold the six unsupported/nonobserving paths. If a false promotion is observed, add the matching independent honesty fixture through the existing repair wave. Refresh affected source/spec/corpus proof and review before qualification; this handoff does not resolve any thread, request CI, change Draft, or authorize a second merge owner.

Portable test-only patch SHA256 `446baedb7f4fa24d9f6ae8464f21c7d64a7ed703890a90b272b3f170e1737d0d`. The patch is included in full so another environment need not access this VM. The runner is a path-parameterized successor of the executed driver; fixture generation/expected native outcomes are unchanged, but the parameterized successor was not re-executed here. It refuses an occupied output directory. Use an exact canonical checkout for this reproduction; reviewing a later repair is a separate subject.

<details><summary>Eight-test append patch</summary>

```diff
--- a/crates/ripr/tests/returned_closure_pin.rs
+++ b/crates/ripr/tests/returned_closure_pin.rs
@@ -242,3 +242,177 @@
     );
     Ok(())
 }
+
+// Attribution controls for RIPR-SPEC-0265 rule 5. Reach and a strong oracle
+// must observe the changed closure result, rather than a replaced value or
+// a same-name rival. Native +/- fixture pairs are retained separately.
+mod returned_closure_attribution {
+    use super::*;
+
+    fn attribution_finding(body: &str) -> Result<Finding, String> {
+        let lib = format!(
+            r#"pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {{
+    move |argument| captured + argument
+}}
+
+mod rival {{
+    pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {{
+        move |argument| captured + argument
+    }}
+}}
+
+#[cfg(test)]
+mod tests {{
+    use super::*;
+    #[test]
+    fn pinned() {{
+        {body}
+    }}
+}}
+"#
+        );
+        finding(
+            &lib,
+            2,
+            "    move |argument| captured - argument",
+            "    move |argument| captured + argument",
+            ProbeFamily::ReturnValue,
+        )
+    }
+
+    #[test]
+    fn direct_result_observed() -> Result<(), String> {
+        let finding = attribution_finding(r#"assert_eq!(make_adder(2)(3), 5);"#)?;
+        assert_eq!(
+            finding.class,
+            ExposureClass::Exposed,
+            "{:?} {:?}",
+            finding.class,
+            limit(&finding)
+        );
+        Ok(())
+    }
+
+    #[test]
+    fn qualified_result_observed_despite_rival_import() -> Result<(), String> {
+        let finding = attribution_finding(
+            r#"use crate::rival::make_adder;
+let _rival = make_adder(2);
+assert_eq!(crate::make_adder(2)(3), 5);"#,
+        )?;
+        assert_eq!(
+            finding.class,
+            ExposureClass::Exposed,
+            "{:?} {:?}",
+            finding.class,
+            limit(&finding)
+        );
+        Ok(())
+    }
+
+    #[test]
+    fn applied_result_overwritten() -> Result<(), String> {
+        let finding = attribution_finding(
+            r#"let mut captured = make_adder(2)(3);
+std::hint::black_box(captured);
+captured = 5;
+assert_eq!(captured, 5);"#,
+        )?;
+        assert_ne!(
+            finding.class,
+            ExposureClass::Exposed,
+            "{:?} {:?}",
+            finding.class,
+            limit(&finding)
+        );
+        Ok(())
+    }
+
+    #[test]
+    fn applied_result_shadowed() -> Result<(), String> {
+        let finding = attribution_finding(
+            r#"let captured = make_adder(2)(3);
+std::hint::black_box(captured);
+let captured = 5;
+assert_eq!(captured, 5);"#,
+        )?;
+        assert_ne!(
+            finding.class,
+            ExposureClass::Exposed,
+            "{:?} {:?}",
+            finding.class,
+            limit(&finding)
+        );
+        Ok(())
+    }
+
+    #[test]
+    fn returned_closure_replaced_before_invocation() -> Result<(), String> {
+        let finding = attribution_finding(
+            r#"let mut captured: Box<dyn Fn(i32) -> i32> = Box::new(make_adder(2));
+std::hint::black_box(&captured);
+captured = Box::new(|argument| argument + 2);
+assert_eq!(captured(3), 5);"#,
+        )?;
+        assert_ne!(
+            finding.class,
+            ExposureClass::Exposed,
+            "{:?} {:?}",
+            finding.class,
+            limit(&finding)
+        );
+        Ok(())
+    }
+
+    #[test]
+    fn qualified_rival_assertion_after_discarded_owner_result() -> Result<(), String> {
+        let finding = attribution_finding(
+            r#"let _ignored = crate::make_adder(2)(3);
+let captured = 5;
+assert_eq!(crate::rival::make_adder(2)(3), captured);"#,
+        )?;
+        assert_ne!(
+            finding.class,
+            ExposureClass::Exposed,
+            "{:?} {:?}",
+            finding.class,
+            limit(&finding)
+        );
+        Ok(())
+    }
+
+    #[test]
+    fn imported_rival_assertion_after_discarded_owner_result() -> Result<(), String> {
+        let finding = attribution_finding(
+            r#"use crate::rival::make_adder;
+let _ignored = crate::make_adder(2)(3);
+let captured = 5;
+assert_eq!(make_adder(2)(3), captured);"#,
+        )?;
+        assert_ne!(
+            finding.class,
+            ExposureClass::Exposed,
+            "{:?} {:?}",
+            finding.class,
+            limit(&finding)
+        );
+        Ok(())
+    }
+
+    #[test]
+    fn exact_assertion_inside_uninvoked_closure() -> Result<(), String> {
+        let finding = attribution_finding(
+            r#"let _deferred = || assert_eq!(make_adder(2)(3), 5);
+let captured = 5;
+assert_eq!(captured, 5);"#,
+        )?;
+        assert_ne!(
+            finding.class,
+            ExposureClass::Exposed,
+            "{:?} {:?}",
+            finding.class,
+            limit(&finding)
+        );
+        Ok(())
+    }
+}
```
</details>

<details><summary>Portable native reproduction and patch generator</summary>

Save as `run_native_portable.py` and run:
```sh
python3 run_native_portable.py --repo /ABS/EXACT-CANONICAL-CHECKOUT --output /ABS/NEW-OUTPUT-DIRECTORY --rustc /ABS/EXISTING/rustc
```

```python
#!/usr/bin/env python3
"""Native observability controls, separate from unexecuted analyzer assertions."""
import difflib
import hashlib
import json
import pathlib
import subprocess
import datetime
import argparse
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True, type=pathlib.Path)
parser.add_argument('--output', required=True, type=pathlib.Path)
parser.add_argument('--rustc', required=True, type=pathlib.Path)
args = parser.parse_args()
ROOT = args.output.resolve()
TREE = args.repo.resolve()
RUSTC = args.rustc.resolve()
HEAD = 'b4f04013c237dd034a5009dbfd46d45bef7e4733'
OLD = '    move |argument| captured - argument'
NEW = '    move |argument| captured + argument'
PREFIX = '''pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
    move |argument| captured + argument
}

mod rival {
    pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
        move |argument| captured + argument
    }
}
'''
CASES = [
    ('direct_result_observed', True, 'assert_eq!(make_adder(2)(3), 5);'),
    ('qualified_result_observed_despite_rival_import', True,
     'use crate::rival::make_adder;\nlet _rival = make_adder(2);\nassert_eq!(crate::make_adder(2)(3), 5);'),
    ('applied_result_overwritten', False,
     'let mut captured = make_adder(2)(3);\nstd::hint::black_box(captured);\ncaptured = 5;\nassert_eq!(captured, 5);'),
    ('applied_result_shadowed', False,
     'let captured = make_adder(2)(3);\nstd::hint::black_box(captured);\nlet captured = 5;\nassert_eq!(captured, 5);'),
    ('returned_closure_replaced_before_invocation', False,
     'let mut captured: Box<dyn Fn(i32) -> i32> = Box::new(make_adder(2));\nstd::hint::black_box(&captured);\ncaptured = Box::new(|argument| argument + 2);\nassert_eq!(captured(3), 5);'),
    ('qualified_rival_assertion_after_discarded_owner_result', False,
     'let _ignored = crate::make_adder(2)(3);\nlet captured = 5;\nassert_eq!(crate::rival::make_adder(2)(3), captured);'),
    ('imported_rival_assertion_after_discarded_owner_result', False,
     'use crate::rival::make_adder;\nlet _ignored = crate::make_adder(2)(3);\nlet captured = 5;\nassert_eq!(make_adder(2)(3), captured);'),
    ('exact_assertion_inside_uninvoked_closure', False,
     'let _deferred = || assert_eq!(make_adder(2)(3), 5);\nlet captured = 5;\nassert_eq!(captured, 5);'),
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(command, stem):
    result = subprocess.run([str(p) for p in command], text=True, capture_output=True, timeout=45)
    stem.with_suffix('.stdout').write_text(result.stdout)
    stem.with_suffix('.stderr').write_text(result.stderr)
    stem.with_suffix('.command.json').write_text(json.dumps([str(p) for p in command]) + '\n')
    stem.with_suffix('.exit').write_text(str(result.returncode) + '\n')
    return result

def source(body):
    return PREFIX + '\n#[cfg(test)]\nmod tests {\n    use super::*;\n    #[test]\n    fn pinned() {\n' + '\n'.join('        ' + line for line in body.splitlines()) + '\n    }\n}\n'

ROOT.mkdir(parents=True, exist_ok=False)
identity = subprocess.check_output(['git', '-C', str(TREE), 'rev-parse', 'HEAD'], text=True).strip()
assert identity == HEAD
receipt = {
    'repository': 'EffortlessMetrics/ripr-swarm', 'pr': 9890,
    'source_head': HEAD,
    'source_tree': subprocess.check_output(['git', '-C', str(TREE), 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
    'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'rustc': subprocess.check_output([str(RUSTC), '--version'], text=True).strip(),
    'scope': 'Eight attribution fixture pairs. No ripr compilation or execution; native witness evidence only.',
    'admission': {
        'review_worktree': str(TREE), 'git_common_dir': subprocess.check_output(['git', '-C', str(TREE), 'rev-parse', '--path-format=absolute', '--git-common-dir'], text=True).strip(),
        'proof_root': str(ROOT), 'owner': 'delegated PR9890 attribution reviewer',
        'cargo_target': 'none; existing root target and binaries not used or modified',
        'additional_peak_budget_bytes': 268435456,
        'available_before_native_bytes': shutil.disk_usage(ROOT).free,
        'retention': 'native sources, exact patch, commands, logs and executables retained for owner consumption',
    },
    'cases': [],
}
for name, observes, body in CASES:
    folder = ROOT / 'cases' / name
    folder.mkdir(parents=True, exist_ok=True)
    original = source(body)
    mutant = original.replace(NEW, OLD, 1)
    assert original != mutant and original.splitlines().count(NEW) == 1
    (folder / 'original.rs').write_text(original)
    (folder / 'mutant.rs').write_text(mutant)
    (folder / 'diff.patch').write_text('diff --git a/src/lib.rs b/src/lib.rs\n--- a/src/lib.rs\n+++ b/src/lib.rs\n@@ -2,1 +2,1 @@\n-' + OLD + '\n+' + NEW + '\n')
    case = {'name': name, 'expected_observable_difference': observes, 'runs': []}
    for variant, text in [('original', original), ('mutant', mutant)]:
        path = folder / (variant + '.rs')
        executable = folder / (variant + '-test')
        compiled = run([RUSTC, '--edition=2024', '--test', path, '-C', 'debuginfo=0', '-o', executable], folder / (variant + '-compile'))
        assert compiled.returncode == 0, (name, variant, compiled.stderr)
        native = run([executable, '--test-threads=1'], folder / (variant + '-run'))
        expected = 101 if observes and variant == 'mutant' else 0
        assert native.returncode == expected, (name, variant, native.returncode, native.stdout)
        assert ('1 failed' if expected else '1 passed') in native.stdout
        case['runs'].append({'variant': variant, 'compile_exit': compiled.returncode, 'test_exit': native.returncode, 'tests': 1, 'source_sha256': digest(path), 'binary_sha256': digest(executable)})
    receipt['cases'].append(case)

addition = '''
// Attribution controls for RIPR-SPEC-0265 rule 5. Reach and a strong oracle
// must observe the changed closure result, rather than a replaced value or
// a same-name rival. Native +/- fixture pairs are retained separately.
mod returned_closure_attribution {
    use super::*;

    fn attribution_finding(body: &str) -> Result<Finding, String> {
        let lib = format!(r#"''' + PREFIX.replace('{', '{{').replace('}', '}}') + '''
#[cfg(test)]
mod tests {{
    use super::*;
    #[test]
    fn pinned() {{
        {body}
    }}
}}
"#);
        finding(
            &lib,
            2,
            "''' + OLD + '''",
            "''' + NEW + '''",
            ProbeFamily::ReturnValue,
        )
    }
'''
for name, observes, body in CASES:
    assertion = 'assert_eq!' if observes else 'assert_ne!'
    addition += '\n    #[test]\n    fn ' + name + '() -> Result<(), String> {\n'
    addition += '        let finding = attribution_finding(r#"' + body + '"#)?;\n'
    addition += '        ' + assertion + '(finding.class, ExposureClass::Exposed, "{:?} {:?}", finding.class, limit(&finding));\n'
    addition += '        Ok(())\n    }\n'
addition += '}\n'
addition_path = ROOT / 'regression-additions.rs'
addition_path.write_text(addition)
rustfmt = RUSTC.with_name('rustfmt')
formatted = run([rustfmt, '--edition', '2024', addition_path], ROOT / 'rustfmt-additions')
assert formatted.returncode == 0, formatted.stderr
original_test = (TREE / 'crates/ripr/tests/returned_closure_pin.rs').read_text()
proposed_test = original_test + '\n' + addition_path.read_text()
(ROOT / 'returned_closure_pin.proposed.rs').write_text(proposed_test)
patch = ''.join(difflib.unified_diff(original_test.splitlines(keepends=True), proposed_test.splitlines(keepends=True), fromfile='a/crates/ripr/tests/returned_closure_pin.rs', tofile='b/crates/ripr/tests/returned_closure_pin.rs'))
(ROOT / 'attribution-tests.patch').write_text(patch)
receipt['patch_sha256'] = digest(ROOT / 'attribution-tests.patch')
receipt['analyzer_assertions'] = 'NOT_EXECUTED: leave exact analyzer build/test with existing source/proof owner; no claim of current-source pass or failure.'
(ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source': HEAD, 'pairs': len(receipt['cases']), 'native_executions': 2 * len(receipt['cases']), 'originals_passed': 8, 'observing_mutants_failed_assertion': 2, 'nonobserving_mutants_passed': 6, 'patch_sha256': receipt['patch_sha256'], 'analyzer_tests': 'not executed'}, indent=2))
```
</details>

<details><summary>Observed native receipt</summary>

```json
{
  "repository": "EffortlessMetrics/ripr-swarm",
  "pr": 9890,
  "source_head": "b4f04013c237dd034a5009dbfd46d45bef7e4733",
  "source_tree": "7e492961111b702e54570142cd189f5fdada75b8",
  "timestamp_utc": "2026-10-23T16:37:01.643408+00:00",
  "rustc": "rustc 1.95.0 (59807616e 2026-04-14)",
  "scope": "Eight attribution fixture pairs. No ripr compilation or execution; native witness evidence only.",
  "admission": {
    "review_worktree": "/workspace/review-9890-attribution",
    "git_common_dir": "/workspace/ripr-swarm/.git",
    "proof_root": "/workspace/proof-9890-attribution",
    "owner": "delegated PR9890 attribution reviewer",
    "cargo_target": "none; existing root target and binaries not used or modified",
    "additional_peak_budget_bytes": 268435456,
    "available_before_native_bytes": null,
    "retention": "native sources, exact patch, commands, logs and executables retained for owner consumption",
    "free_space_observation": "df -h before native: overlay 32G size, 189M used, 30G available (rounded; exact pre-run bytes not captured)."
  },
  "cases": [
    {
      "name": "direct_result_observed",
      "expected_observable_difference": true,
      "runs": [
        {
          "variant": "original",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "1cfb3379fc89998c6aecd6f0b33a74d7010b1f46b2a13238ee2a56dc9d734a6d",
          "binary_sha256": "6ec8c3b2385229334e99c6e7b1f6fcfcdcf507a0646a300f28da307647b068a0"
        },
        {
          "variant": "mutant",
          "compile_exit": 0,
          "test_exit": 101,
          "tests": 1,
          "source_sha256": "4069fd2cc1fa744bf0d196906800deeb8b8561ea2b60a9c89c9e937a3fc32b46",
          "binary_sha256": "1be04ef773314fdf797fb494c80dba138169b095f7fc9687f9f95d879f872131"
        }
      ]
    },
    {
      "name": "qualified_result_observed_despite_rival_import",
      "expected_observable_difference": true,
      "runs": [
        {
          "variant": "original",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "3da681fd7e7385912d837735f174cfdfa77baf76cde2e8de59932a2e81baf1a0",
          "binary_sha256": "4f8c017c6193ee6f5ebc84aa28df91592292b4cf89cbbddc34fae7cd74422791"
        },
        {
          "variant": "mutant",
          "compile_exit": 0,
          "test_exit": 101,
          "tests": 1,
          "source_sha256": "1254fd7fdf23f8fbb1cd5b4cabc49b1e40eb097ea1aab1f10af4b20f709bc8cf",
          "binary_sha256": "d5cfc2ed7b799265ab9dd49e6f4c6b3244d104d194d4f6418d0d9267b6b15e20"
        }
      ]
    },
    {
      "name": "applied_result_overwritten",
      "expected_observable_difference": false,
      "runs": [
        {
          "variant": "original",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "ee7d1fb11f59d80257d5dae02c37a8c0ecbc00ac2709319b04066ae9482a71ae",
          "binary_sha256": "d54a01a5fb9e359dc9da978f7946a64878d10bfee613e312f97fdfbe744569e9"
        },
        {
          "variant": "mutant",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "b15d13b732e634ce466cefdf9e625a37725cae280dea536bdea8bcc4091a54d2",
          "binary_sha256": "4b68bba75e98eef28cc11bd044501d73e4b4b1345283681a8ca272353d083d9b"
        }
      ]
    },
    {
      "name": "applied_result_shadowed",
      "expected_observable_difference": false,
      "runs": [
        {
          "variant": "original",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "7f7f8b520388c2c4faa552cc90b503610b57ad2119c944a2fd0c3dc866e95113",
          "binary_sha256": "46e9f3455ed40b76f44c84e6b14c39409f5a4b53de873b6a162755099ef51766"
        },
        {
          "variant": "mutant",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "9ead92acc65f8882353e3b9b192be17fa13d2f3d75f99b70fd20cb5edec9d340",
          "binary_sha256": "89c4a6cd3b8d756ddb7fd4d6f01ae557c0242c03226029d235e0d83a8f8f4de6"
        }
      ]
    },
    {
      "name": "returned_closure_replaced_before_invocation",
      "expected_observable_difference": false,
      "runs": [
        {
          "variant": "original",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "a15f905e229e445bc85f90590b9e916a0e6acf3411e10e91eecf6fb236e416cf",
          "binary_sha256": "a341b6c4e90befe81c5e4d245eaa89f84a4aca2b2857b29ad3bc713ab8d96130"
        },
        {
          "variant": "mutant",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "cd5eb3ae0d89e36c879a8a4e6ea91ed3375e41b48c5f3c7e1e3645b8186b4a4d",
          "binary_sha256": "11d8904a60df4ac05dd8601eef6469e184bbf9b74f8627c22b914b5e6dec1a32"
        }
      ]
    },
    {
      "name": "qualified_rival_assertion_after_discarded_owner_result",
      "expected_observable_difference": false,
      "runs": [
        {
          "variant": "original",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "838529678db4a649cd5d1d6d0c97380e5a0ad82a3c94234dac5b47652bf5cc59",
          "binary_sha256": "2637d7fbcaf12703c3f7c01854cb6331f8ba87faf71ab58409bc153356beed77"
        },
        {
          "variant": "mutant",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "29a73ed1701974ab8c22b52f4f818d4ca95d2e8fb3156056e8b3e5b9b36c99f5",
          "binary_sha256": "1febe5d88d458b50805925127ee0ccf10b74b32795ad04e9b14fb3e956a37824"
        }
      ]
    },
    {
      "name": "imported_rival_assertion_after_discarded_owner_result",
      "expected_observable_difference": false,
      "runs": [
        {
          "variant": "original",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "4133e665fd7ccedcd40e82d55a2c5c556e3364cf4c78c3ded0dc7670044dbd09",
          "binary_sha256": "d592057b749c422a6b0a7b163a0ddea0f6a9a33d1fdcc9e8773a10e158c8a1d5"
        },
        {
          "variant": "mutant",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "ea4d8e969b9b62a51c73f5b46e472bc03d58d6e5cca2337b8d38d5164ae662a8",
          "binary_sha256": "8bc60d1a10f245e453319bbe46a4025e9f00ab264d22535bfac1448579536cec"
        }
      ]
    },
    {
      "name": "exact_assertion_inside_uninvoked_closure",
      "expected_observable_difference": false,
      "runs": [
        {
          "variant": "original",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "7dded4687059cb0c03186765983f65d0855fbc491d07ef9c6c548ae6c40ef1a1",
          "binary_sha256": "2891354d232ebe758c840eab2a22a56ce439403a8ea278163a076ac0dabe826a"
        },
        {
          "variant": "mutant",
          "compile_exit": 0,
          "test_exit": 0,
          "tests": 1,
          "source_sha256": "43bdd0a86b4525b262ef03a5d5d17f9d35fc984d8446152260c5acbac32da749",
          "binary_sha256": "1ba16e01724b1927fd27f066a1fecf4a5b1d1b27f2a327454faaf49c3a7b4051"
        }
      ]
    }
  ],
  "patch_sha256": "446baedb7f4fa24d9f6ae8464f21c7d64a7ed703890a90b272b3f170e1737d0d",
  "analyzer_assertions": "NOT_EXECUTED: leave exact analyzer build/test with existing source/proof owner; no claim of current-source pass or failure.",
  "executed_driver_sha256": "f2db4c58a3823fdfca56ef2f7ace7eac980ff6c6aebabf887798dbef52f90951",
  "portable_driver_note": "Path-parameterized successor; not re-executed here. Native fixture generation and assertions unchanged. Use an absent output directory.",
  "resources_at_closeout": {
    "proof_bytes": 110244667,
    "free_bytes": 31727374336,
    "review_worktree": "will release after source capture; no builds or other consumers owned here",
    "preexisting_root_target": "untouched; ownership not inferred"
  }
}
```
</details>

Retained task-local raw evidence: `/workspace/proof-9890-attribution/` contains all 16 sources/executables, native commands/status/stdout/stderr, original executed driver, portable successor, exact append patch, canonical 12-file PR patch, copied source, GitHub snapshot and receipt. Those local locators are not represented as cross-machine transfer; full portable source/patch and observed result identities are above. Existing root checkout, toolchain and mutable target are untouched. Only this review-owned detached worktree is released after source capture; raw open-claim proof remains retained for consumption.

Disposition: fixture observability proof complete; **REVIEW_INCOMPLETE** for analyzer execution/adoption, with existing **REPAIR_REQUIRED** findings preserved.

