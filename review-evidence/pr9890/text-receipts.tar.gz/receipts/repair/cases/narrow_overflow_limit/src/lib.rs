pub fn make_adder(n: i8) -> impl Fn(i8) -> i8 {
    move |x| n + x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(120)(3), 123);
    }
}
