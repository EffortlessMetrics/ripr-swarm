pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n * x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let _unused = make_adder(5); let x = 5; assert_eq!(x, 5);
    }
}
