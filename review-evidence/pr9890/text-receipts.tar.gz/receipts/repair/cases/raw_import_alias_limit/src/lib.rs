mod aliases { pub type Int = i8; } use aliases::{Int as r#i32};
pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n + x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(20)(28), 48);
    }
}
