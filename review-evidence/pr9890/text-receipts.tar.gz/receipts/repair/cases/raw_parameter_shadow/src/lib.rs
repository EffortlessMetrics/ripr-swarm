pub fn make_adder(r#n: i32) -> impl Fn(i32) -> i32 {
    move |n| r#n + 2
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(3)(2), 4);
    }
}
