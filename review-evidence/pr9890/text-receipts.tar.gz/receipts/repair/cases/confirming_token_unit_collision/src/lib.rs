pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n * x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let n = 5; assert_eq!(make_adder(5)(1), n);
    }
}
