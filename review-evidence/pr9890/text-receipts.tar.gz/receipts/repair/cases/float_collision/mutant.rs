pub fn make_adder(n: f64) -> impl Fn(f64) -> f64 {
    move |x| n * x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(3.0)(1.5), 4.5);
    }
}
