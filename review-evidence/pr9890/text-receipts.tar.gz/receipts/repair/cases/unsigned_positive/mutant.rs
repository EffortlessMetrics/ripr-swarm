pub fn make_adder(n: u32) -> impl Fn(u32) -> u32 {
    move |x| n - x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(5)(3), 8);
    }
}
