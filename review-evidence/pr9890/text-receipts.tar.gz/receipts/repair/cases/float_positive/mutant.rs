pub fn make_adder(n: f64) -> impl Fn(f64) -> f64 {
    move |x| n - x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(2.0)(3.0), 5.0);
    }
}
