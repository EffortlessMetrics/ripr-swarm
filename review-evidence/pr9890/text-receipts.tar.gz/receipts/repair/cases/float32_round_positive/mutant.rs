pub fn make_adder(n: f32) -> impl Fn(f32) -> f32 {
    move |x| n - x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(16_777_216.0)(3.0), 16_777_220.0);
    }
}
