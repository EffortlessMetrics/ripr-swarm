type i32 = u8;
mod factory {
    pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n - x
    }
}
#[test]
fn pinned() { assert_eq!(factory::make_adder(2)(3), 5); }
