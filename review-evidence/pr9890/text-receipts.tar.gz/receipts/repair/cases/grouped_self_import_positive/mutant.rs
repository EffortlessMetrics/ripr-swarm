mod markers { pub struct Marker; } use self::{markers::Marker};
pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n - x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(2)(3), 5);
    }
}
