from pathlib import Path
p=Path('/workspace/proposal-9890/crates/ripr/src/analysis/classify/owner_pin/returned_closure/arithmetic.rs');s=p.read_text()
a=s.index('        let arguments = ["Fn(", "FnMut(", "FnOnce("]');b=s.index('        let kind =',a)
s=s[:a]+'''        let (selected_trait, arguments) = inputs.split_once('(')?;
        if !["Fn", "FnMut", "FnOnce"].contains(&selected_trait) { return None; }
        let arguments = arguments.strip_suffix(')')?;
'''+s[b:]
s=s.replace('            let protected = [kind.name, "Fn", "FnMut", "FnOnce"];','            let protected = [kind.name, selected_trait];')
a=s.index('                    ast::Item::Use(import) => {');b=s.index('                    ast::Item::ExternCrate',a)
s=s[:a]+'''                    ast::Item::Use(import) => {
                        if import_binds_protected(&import.use_tree()?, None, &protected, 0)? { return None; }
                    }
'''+s[b:]
s=s.replace('parameters.push(ident.name()?.text().to_string());','parameters.push(ident.name()?.text().trim_start_matches("r#").to_string());')
s=s.replace('let name = path.segment()?.name_ref()?.text().to_string();','let name = path.segment()?.name_ref()?.text().trim_start_matches("r#").to_string();')
s=s.replace('ident.text() == name','ident.text().trim_start_matches("r#") == name')
needle='#[derive(Clone, Copy, Debug)]\nstruct NumberKind'
helper='''// Import bindings are syntax identities: comments, raw identifiers and
// aliases cannot change the terminal name. `self` inherits its list prefix.
fn import_binds_protected(tree: &ast::UseTree, inherited: Option<&str>, protected: &[&str], depth: usize) -> Option<bool> {
    if depth > 16 { return None; }
    if tree.star_token().is_some() { return Some(true); }
    if let Some(rename) = tree.rename() {
        if rename.underscore_token().is_some() { return Some(false); }
        return Some(protected.contains(&rename.name()?.text().trim_start_matches("r#")));
    }
    let terminal = if let Some(path) = tree.path() {
        let segment = path.segment()?;
        let text = segment.syntax().text().to_string();
        if text == "self" { Some(inherited?.to_string()) }
        else { Some(segment.name_ref()?.text().trim_start_matches("r#").to_string()) }
    } else { inherited.map(str::to_string) };
    if let Some(list) = tree.use_tree_list() {
        for child in list.use_trees() {
            if import_binds_protected(&child, terminal.as_deref(), protected, depth + 1)? { return Some(true); }
        }
        return Some(false);
    }
    Some(protected.contains(&terminal?.as_str()))
}

'''
s=s.replace(needle,helper+needle)
Path('/workspace/proof-9890/repair/arithmetic-final.rs').write_text(s)
