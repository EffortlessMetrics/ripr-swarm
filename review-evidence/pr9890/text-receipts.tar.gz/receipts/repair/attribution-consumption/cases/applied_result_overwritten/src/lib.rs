pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
    move |argument| captured + argument
}

mod rival {
    pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
        move |argument| captured + argument
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let mut captured = make_adder(2)(3);
        std::hint::black_box(captured);
        captured = 5;
        assert_eq!(captured, 5);
    }
}
