pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
    move |argument| captured + argument
}

mod rival {
    pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
        move |argument| captured + argument
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        use crate::rival::make_adder;
        let _rival = make_adder(2);
        assert_eq!(crate::make_adder(2)(3), 5);
    }
}
