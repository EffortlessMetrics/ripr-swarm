pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
    move |argument| captured + argument
}

mod rival {
    pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
        move |argument| captured + argument
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let mut captured: Box<dyn Fn(i32) -> i32> = Box::new(make_adder(2));
        std::hint::black_box(&captured);
        captured = Box::new(|argument| argument + 2);
        assert_eq!(captured(3), 5);
    }
}
