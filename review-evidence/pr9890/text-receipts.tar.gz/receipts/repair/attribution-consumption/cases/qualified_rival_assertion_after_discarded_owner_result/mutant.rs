pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
    move |argument| captured - argument
}

mod rival {
    pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
        move |argument| captured + argument
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let _ignored = crate::make_adder(2)(3);
        let captured = 5;
        assert_eq!(crate::rival::make_adder(2)(3), captured);
    }
}
