pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
    move |argument| captured + argument
}

mod rival {
    pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
        move |argument| captured + argument
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        use crate::rival::make_adder;
        let _ignored = crate::make_adder(2)(3);
        let captured = 5;
        assert_eq!(make_adder(2)(3), captured);
    }
}
