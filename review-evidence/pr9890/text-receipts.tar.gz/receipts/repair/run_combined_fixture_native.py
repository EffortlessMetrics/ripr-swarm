import hashlib
import json
from pathlib import Path
import re
import subprocess

REPO = Path('/workspace/proposal-9890')
ROOT = Path('/workspace/proof-9890/repair/fixture-native-11')
RUSTC = Path('/workspace/.ripr-toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc')
FIXTURE = REPO / 'fixtures/returned_closure_arithmetic_masking'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def execute(command, stem):
    result = subprocess.run([str(v) for v in command], cwd=ROOT, capture_output=True, text=True, timeout=90)
    stem.with_suffix('.stdout').write_text(result.stdout)
    stem.with_suffix('.stderr').write_text(result.stderr)
    return {'command': [str(v) for v in command], 'cwd': str(ROOT), 'exit': result.returncode}

ROOT.mkdir(exist_ok=True)
source = (FIXTURE / 'input/src/lib.rs').read_text()
diff = (FIXTURE / 'diff.patch').read_text()
lines = source.splitlines(keepends=True)
mutant = list(lines)
targets = []
for match in re.finditer(r'@@ -\d+,1 \+(\d+),1 @@\n-([^\n]*)\n\+([^\n]*)\n', diff):
    line, before, after = int(match[1]), match[2], match[3]
    assert line not in targets and lines[line - 1] == after + '\n'
    targets.append(line)
    mutant[line - 1] = before + '\n'
assert len(targets) == 11
assert [i + 1 for i, (a, b) in enumerate(zip(lines, mutant)) if a != b] == targets
# The patch selects only target owners, preserving both same-name rivals.
rival_lines = [i for i, text in enumerate(lines) if text == '        move |argument| captured + argument\n']
assert len(rival_lines) == 2
assert all(lines[i] == mutant[i] for i in rival_lines)
(ROOT / 'original.rs').write_text(source)
(ROOT / 'mutant.rs').write_text(''.join(mutant))
(ROOT / 'diff.patch').write_text(diff)
receipt = {
    'source_head': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip(),
    'rustc': str(RUSTC),
    'rustc_version': subprocess.check_output([str(RUSTC), '-vV'], text=True).strip(),
    'fixture_source_sha256': digest(FIXTURE / 'input/src/lib.rs'),
    'diff_sha256': digest(FIXTURE / 'diff.patch'),
    'mutated_target_lines': targets,
    'scope': 'one original and one combined 11-target mutant, 11 native tests each; rival bodies unchanged',
    'variants': {},
}
for variant in ['original', 'mutant']:
    path = ROOT / (variant + '.rs')
    binary = ROOT / (variant + '-test')
    compiled = execute([RUSTC, '--edition=2024', '--test', path, '-C', 'debuginfo=0', '-o', binary], ROOT / (variant + '-compile'))
    assert compiled['exit'] == 0, variant
    run = execute([binary, '--test-threads=1'], ROOT / (variant + '-run'))
    output = (ROOT / (variant + '-run.stdout')).read_text()
    assert run['exit'] == 0 and '11 passed; 0 failed; 0 ignored' in output, variant
    receipt['variants'][variant] = {'source_sha256': digest(path), 'binary_sha256': digest(binary), 'compile': compiled, 'run': run}
(ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
