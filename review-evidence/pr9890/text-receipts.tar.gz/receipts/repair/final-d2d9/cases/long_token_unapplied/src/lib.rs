pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
    move |argument| captured * argument
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let _unused = make_adder(5); let argument = 5; assert_eq!(argument, 5);
    }
}
