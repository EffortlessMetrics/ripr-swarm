type i32 = u8;
pub fn make_adder(captured: i32) -> impl Fn(i32) -> i32 {
    move |argument| captured * argument
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let captured = 5; assert_eq!(make_adder(5)(1), captured);
    }
}
