# ripr goldens bless report

Status: pass

Fixture:
- `fixtures/returned_closure_arithmetic_masking`

Reason:
```text
RIPR-SPEC-0265: withhold body masks and lexical bypasses of returned-closure pins
```

Actual outputs:
- `target/ripr/fixtures/returned_closure_arithmetic_masking/check.json`
- `target/ripr/fixtures/returned_closure_arithmetic_masking/human.txt`

Updated:
- `fixtures/returned_closure_arithmetic_masking/expected/check.json`
- `fixtures/returned_closure_arithmetic_masking/expected/human.txt`
- `fixtures/returned_closure_arithmetic_masking/expected/CHANGELOG.md`
