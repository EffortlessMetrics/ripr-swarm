pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n + x
}
mod foreign { pub fn make_adder(_: i32) -> impl Fn(i32) -> i32 { |_| 5 } }
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let _unused = crate::make_adder(2); use crate::foreign::make_adder; assert_eq!(make_adder(2)(3), 5);
    }
}
