pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n - x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let add = make_adder(2); assert_eq!(add(3), 5);
    }
}
