pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n - x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let make_adder = |_| |_: i32| 5; let _unused = make_adder(9); assert_eq!(crate::make_adder(2)(3), 5);
    }
}
