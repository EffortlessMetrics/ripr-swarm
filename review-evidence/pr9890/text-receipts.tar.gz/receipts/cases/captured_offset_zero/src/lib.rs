const OFFSET: i32 = 3;
pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n + (x - OFFSET)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(2)(3), 2);
    }
}
