const OFFSET: i32 = 3;

fn before(n: i32) -> impl Fn(i32) -> i32 { move |x| n + (x - OFFSET) }
fn after(n: i32) -> impl Fn(i32) -> i32 { move |x| n - (x - OFFSET) }
#[test]
fn non_equivalent_at_other_input() { assert_eq!(before(2)(3), after(2)(3)); assert_ne!(before(2)(4), after(2)(4)); }
