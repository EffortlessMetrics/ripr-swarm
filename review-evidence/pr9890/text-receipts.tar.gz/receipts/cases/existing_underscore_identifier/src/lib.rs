pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n + x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let _2 = 0; assert_eq!(make_adder(_2)(3), 3);
    }
}
