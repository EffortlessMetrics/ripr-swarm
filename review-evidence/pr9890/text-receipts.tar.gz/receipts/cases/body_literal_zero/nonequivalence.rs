
fn before(n: i32) -> impl Fn(i32) -> i32 { move |x| n + (x - 3) }
fn after(n: i32) -> impl Fn(i32) -> i32 { move |x| n - (x - 3) }
#[test]
fn non_equivalent_at_other_input() { assert_eq!(before(2)(3), after(2)(3)); assert_ne!(before(2)(4), after(2)(4)); }
