pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| n + x
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        let _unused = make_adder(2); assert_eq!(2 + 3, 5);
    }
}
