pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| x - n
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pinned() {
        assert_eq!(make_adder(0)(7), 7);
    }
}
