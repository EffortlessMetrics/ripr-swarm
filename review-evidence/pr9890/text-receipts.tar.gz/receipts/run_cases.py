import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/proof-9890')
BINARY = Path('/workspace/proof-9890/bin/ripr-head')
RUSTC = Path('/workspace/.ripr-toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def execute(command, cwd, stem):
    result = subprocess.run([str(x) for x in command], cwd=cwd, capture_output=True, text=True, timeout=90)
    (stem.with_suffix('.stdout')).write_text(result.stdout)
    (stem.with_suffix('.stderr')).write_text(result.stderr)
    return {'command': [str(x) for x in command], 'cwd': str(cwd), 'exit': result.returncode}

def source(tail, body, prelude='', module=''):
    return f'''{prelude}pub fn make_adder(n: i32) -> impl Fn(i32) -> i32 {{
    {tail}
}}
{module}
#[cfg(test)]
mod tests {{
    use super::*;
    #[test]
    fn pinned() {{
        {body}
    }}
}}
'''

cases = [
    ('direct', 'move |x| n + x', 'move |x| n - x', 'assert_eq!(make_adder(2)(3), 5);', '', '', True),
    ('qualified_despite_rebinding', 'move |x| n + x', 'move |x| n - x',
     'let make_adder = |_| |_: i32| 5; let _unused = make_adder(9); assert_eq!(crate::make_adder(2)(3), 5);', '', '', True),
    ('unused', 'move |x| n + x', 'move |x| n - x',
     'let _unused = make_adder(2); assert_eq!(2 + 3, 5);', '', '', False),
    ('bound_and_applied', 'move |x| n + x', 'move |x| n - x',
     'let add = make_adder(2); assert_eq!(add(3), 5);', '', '', False),
    ('rebound_callee', 'move |x| n + x', 'move |x| n - x',
     'let _unused = make_adder(2); let make_adder = |_| |_: i32| 5; assert_eq!(make_adder(2)(3), 5);', '', '', False),
    ('nested_fn_twin', 'move |x| n + x', 'move |x| n - x',
     'let _unused = crate::make_adder(2); fn make_adder(_: i32) -> impl Fn(i32) -> i32 { |_| 5 } assert_eq!(make_adder(2)(3), 5);', '', '', False),
    ('foreign_qualified_twin', 'move |x| n + x', 'move |x| n - x',
     'let _unused = make_adder(2); assert_eq!(foreign::make_adder(2)(3), 5);', '',
     'mod foreign { pub fn make_adder(_: i32) -> impl Fn(i32) -> i32 { |_| 5 } }', False),
    ('foreign_imported_twin', 'move |x| n + x', 'move |x| n - x',
     'let _unused = crate::make_adder(2); use crate::foreign::make_adder; assert_eq!(make_adder(2)(3), 5);', '',
     'mod foreign { pub fn make_adder(_: i32) -> impl Fn(i32) -> i32 { |_| 5 } }', False),
    ('zero_capture', 'move |x| x + n', 'move |x| x - n',
     'assert_eq!(make_adder(0)(7), 7);', '', '', False),
    ('nonliteral_capture', 'move |x| n + x', 'move |x| n - x',
     'let n = 2; assert_eq!(make_adder(n)(3), 5);', '', '', False),
    ('captured_offset_zero', 'move |x| n + (x - OFFSET)', 'move |x| n - (x - OFFSET)',
     'assert_eq!(make_adder(2)(3), 2);', 'const OFFSET: i32 = 3;\n', '', False),
    ('captured_offset_identity', 'move |x| n * (x - OFFSET + 1)', 'move |x| n / (x - OFFSET + 1)',
     'assert_eq!(make_adder(2)(3), 2);', 'const OFFSET: i32 = 3;\n', '', False),
    ('body_literal_zero', 'move |x| n + (x - 3)', 'move |x| n - (x - 3)',
     'assert_eq!(make_adder(2)(3), 2);', '', '', False),
    ('constant_value_positive', 'move |x| n + x * TWO', 'move |x| n - x * TWO',
     'assert_eq!(make_adder(2)(3), 8);', 'const TWO: i32 = 2;\n', '', True),
    ('uppercase_callee', 'move |x| n + OFFSET(x)', 'move |x| n - OFFSET(x)',
     'assert_eq!(make_adder(2)(3), 2);', 'fn OFFSET(x: i32) -> i32 { x - 3 }\n', '', False),
    ('existing_unit_positive', 'move |x| n * x', 'move |x| n / x',
     'assert_eq!(make_adder(5)(1), 5);', '', '', False),
    ('existing_unit_negative', 'move |x| n * x', 'move |x| n / x',
     'assert_eq!(make_adder(5)(-1), -5);', '', '', False),
    ('existing_coincident_pair', 'move |x| n - x', 'move |x| n / x',
     'assert_eq!(make_adder(4)(2), 2);', '', '', False),
    ('existing_underscore_identifier', 'move |x| n + x', 'move |x| x - n',
     'let _2 = 0; assert_eq!(make_adder(_2)(3), 3);', '', '', False),
]

def main():
    if not BINARY.is_file():
        raise RuntimeError(f'actual selected binary absent: {BINARY}')
    identity = {'binary': str(BINARY), 'binary_sha256': digest(BINARY), 'rustc': str(RUSTC),
                'reviewed_head': 'e1843f20dddd05ef012829809fee0bbea54fd870',
                'merge_base': '6417e7cf98aa5fc266e05db9414cab0aa486db00',
                'integration_basis': '592aa7473c2af21c30dbf3ef414688a57a70937b'}
    results = []
    selected_cases = [c for c in cases if c[0] in sys.argv[1:]] if len(sys.argv) > 1 else cases
    results_path = ROOT / ('results-inline-findings.json' if len(sys.argv) > 1 else 'results.json')
    for name, tail, mutant_tail, body, prelude, module, expect_credit in selected_cases:
        case = ROOT / 'cases' / name
        (case / 'src').mkdir(parents=True, exist_ok=True)
        lib = source(tail, body, prelude, module)
        line = lib.splitlines().index('    ' + tail) + 1
        (case / 'Cargo.toml').write_text('[package]\nname="review-closure"\nversion="0.0.0"\nedition="2024"\n[workspace]\n')
        (case / 'src/lib.rs').write_text(lib)
        (case / 'mutant.rs').write_text(lib.replace('    ' + tail + '\n', '    ' + mutant_tail + '\n', 1))
        diff = f'''diff --git a/src/lib.rs b/src/lib.rs
--- a/src/lib.rs
+++ b/src/lib.rs
@@ -{line},1 +{line},1 @@
-    {mutant_tail}
+    {tail}
'''
        (case / 'diff.patch').write_text(diff)
        analysis = execute([BINARY, 'check', '--root', case, '--diff', case / 'diff.patch', '--mode', 'ready', '--format', 'json'], case, case / 'analysis')
        if analysis['exit'] != 0:
            raise RuntimeError(f'{name}: analysis failed, see {case}')
        data = json.loads((case / 'analysis.stdout').read_text())
        selected = [f for f in data['findings'] if f['probe']['line'] == line and f['probe']['family'] == 'return_value']
        if len(selected) != 1:
            raise RuntimeError(f'{name}: expected one return_value on {line}, got {len(selected)}')
        f = selected[0]
        runtimes = {}
        for variant, path in [('original', case / 'src/lib.rs'), ('mutant', case / 'mutant.rs')]:
            exe = case / (variant + '-test')
            compile_result = execute([RUSTC, '--edition=2024', '--test', path, '-o', exe], case, case / (variant + '-compile'))
            if compile_result['exit'] != 0:
                raise RuntimeError(f'{name}/{variant}: fixture compilation failed, see {case}')
            run = execute([exe, '--test-threads=1'], case, case / (variant + '-run'))
            runtimes[variant] = {'source_sha256': digest(path), 'binary_sha256': digest(exe), 'compile': compile_result, 'run': run}
        if name in ('captured_offset_zero', 'captured_offset_identity', 'body_literal_zero', 'uppercase_callee'):
            witness = case / 'nonequivalence.rs'
            witness.write_text(prelude + '\n' +
                f'fn before(n: i32) -> impl Fn(i32) -> i32 {{ {tail} }}\n' +
                f'fn after(n: i32) -> impl Fn(i32) -> i32 {{ {mutant_tail} }}\n' +
                '#[test]\nfn non_equivalent_at_other_input() { assert_eq!(before(2)(3), after(2)(3)); assert_ne!(before(2)(4), after(2)(4)); }\n')
            exe = case / 'nonequivalence-test'
            compiled = execute([RUSTC, '--edition=2024', '--test', witness, '-o', exe], case, case / 'nonequivalence-compile')
            if compiled['exit'] != 0:
                raise RuntimeError(f'{name}: nonequivalence compilation failed')
            run = execute([exe, '--test-threads=1'], case, case / 'nonequivalence-run')
            if run['exit'] != 0:
                raise RuntimeError(f'{name}: nonequivalence witness failed')
            runtimes['nonequivalence'] = {'source_sha256': digest(witness), 'binary_sha256': digest(exe), 'compile': compiled, 'run': run}
        row = {'case': name, 'line': line, 'class': f.get('classification', f.get('class')),
               'static_limit_kind': f.get('static_limit_kind'), 'expected_credit': expect_credit,
               'analysis': analysis, 'runtime': runtimes}
        results.append(row)
        results_path.write_text(json.dumps({'identity': identity, 'results': results}, indent=2))
        print(name, row['class'], 'expected-credit=' + str(expect_credit), 'runtime(original,mutant)=',
              runtimes['original']['run']['exit'], runtimes['mutant']['run']['exit'], flush=True)
    (ROOT / 'identity.json').write_text(json.dumps(identity, indent=2))

if __name__ == '__main__':
    main()
