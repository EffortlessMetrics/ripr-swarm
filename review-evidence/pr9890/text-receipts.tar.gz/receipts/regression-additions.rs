
// Review-only additions: expected red on the reviewed candidate; no source-branch edits.

#[test]
fn review_captured_offset_zero_must_withhold() -> Result<(), String> {
    let lib = include_str!("/workspace/proof-9890/cases/captured_offset_zero/src/lib.rs");
    let observed = finding(lib, 3, "    move |x| n - (x - OFFSET)", "    move |x| n + (x - OFFSET)", ProbeFamily::ReturnValue)?;
    assert_ne!(observed.class, ExposureClass::Exposed, "captured_offset_zero: {:?} {:?}", observed.class, limit(&observed));
    Ok(())
}

#[test]
fn review_captured_offset_identity_must_withhold() -> Result<(), String> {
    let lib = include_str!("/workspace/proof-9890/cases/captured_offset_identity/src/lib.rs");
    let observed = finding(lib, 3, "    move |x| n / (x - OFFSET + 1)", "    move |x| n * (x - OFFSET + 1)", ProbeFamily::ReturnValue)?;
    assert_ne!(observed.class, ExposureClass::Exposed, "captured_offset_identity: {:?} {:?}", observed.class, limit(&observed));
    Ok(())
}

#[test]
fn review_body_literal_zero_must_withhold() -> Result<(), String> {
    let lib = include_str!("/workspace/proof-9890/cases/body_literal_zero/src/lib.rs");
    let observed = finding(lib, 2, "    move |x| n - (x - 3)", "    move |x| n + (x - 3)", ProbeFamily::ReturnValue)?;
    assert_ne!(observed.class, ExposureClass::Exposed, "body_literal_zero: {:?} {:?}", observed.class, limit(&observed));
    Ok(())
}

#[test]
fn review_uppercase_callee_must_withhold() -> Result<(), String> {
    let lib = include_str!("/workspace/proof-9890/cases/uppercase_callee/src/lib.rs");
    let observed = finding(lib, 3, "    move |x| n - OFFSET(x)", "    move |x| n + OFFSET(x)", ProbeFamily::ReturnValue)?;
    assert_ne!(observed.class, ExposureClass::Exposed, "uppercase_callee: {:?} {:?}", observed.class, limit(&observed));
    Ok(())
}
