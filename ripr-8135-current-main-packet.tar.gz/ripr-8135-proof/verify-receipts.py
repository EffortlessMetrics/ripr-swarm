import json,hashlib,re
from pathlib import Path
root=Path(__file__).resolve().parent
pre=json.loads((root/'reports/precommit-v2.json').read_text());declared=pre['report_digest'];pre['report_digest']=''
computed='sha256:'+hashlib.sha256(json.dumps(pre,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
assert computed==declared
expected={'ledger':116,'selector':5,'structural-rust-only':3,'diagnostic-corrected':31}
for name,count in expected.items():
 assert json.loads((root/(name+'.json')).read_text())['exit']==0
 assert f'test result: ok. {count} passed; 0 failed; 0 ignored;' in (root/(name+'.log')).read_text()
for name in ['check-fast','precommit']:
 assert json.loads((root/(name+'.json')).read_text())['exit']==0
v=json.loads((root/'verification.json').read_text())
assert all('::'+name+' ... ok' in (root/'diagnostic-corrected.log').read_text() for name in v['diagnostic_required_subset'])
assert sorted(c['path'] for c in pre['change_set']['changes'])==v['selector_paths']
assert pre['head_sha']=='05e332b66af067a1a365f4d1f5af18e32fd925f2'
assert pre['merge_base_sha']=='758a7c082c1c140d1d818bb3d7e5be78643d3f22'
assert pre['status']=='pass' and pre['skipped']==[]
assert 'running 0 tests' in (root/'diagnostic.log').read_text()
print('verified: 116 ledger / 5 selector / 31 diagnostics (required subset11) / 3 structural; all exits0; 4 paths; precommit digest '+computed)
