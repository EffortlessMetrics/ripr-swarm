Qualification resource admission (2026-10-15 UTC)

Owner: bounded #8135 integration task. Source worktree /tmp/ripr-8135-integration; common Git store /workspace/ripr-swarm/.git (shared, preserved). Frozen proof /tmp/ripr-8135-proof. New mutable target /workspace/8135-qualification-target, jobs=2, dev/test debug=0, incremental=0. Local target/ only for repository-required temp/report output. Existing /workspace/ripr-swarm/target is not consumed or cleaned.

Observed initial capacity: /workspace 30 GiB free; /tmp 8.7 GiB free after checkout. Accepted task reserve: 6 GiB workspace, 2 GiB tmp. Conservative additional peak allowance: workspace 18 GiB compilation/download state; tmp 2 GiB source, logs, compressed packet plus independent restoration. No reclamation assumed. Current compiler RSS ~5.7 GiB within 17 GiB host RAM; only one cargo driver with at most 2 jobs.

Mandatory retained source identities: head7d246801183e22bcf78e6c2efd556e387e27b1e2, base758a7c082c1c140d1d818bb3d7e5be78643d3f22, composition05e332b66af067a1a365f4d1f5af18e32fd925f2/tree48bf287c742186117177822ae098a8bbe26fbfa9. Historical failed hosted receipt stays in prior immutable packet3b0c45ed55e70bab1ed5a0941ab592aa340ad5b1 and current remote-subject readback. This task does not reconstruct or delete the historical witness.

Retain raw command logs/exits, executable hashes and receipts through durable handoff. No destructive cleanup authorized. Terminal resource disposition will name any retained paths and consumers.
