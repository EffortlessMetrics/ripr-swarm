pub fn make_count(count: usize) -> usize {
    count + 1
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn snapshot_count() {
        let actual = make_count(2);
        insta::assert_json_snapshot!(actual);
    }
}
