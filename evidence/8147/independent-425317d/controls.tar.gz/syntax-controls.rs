use ra_ap_syntax::{ast,AstNode,SyntaxNode};
fn non_trivia_tokens(node: &SyntaxNode) -> Vec<ra_ap_syntax::SyntaxToken> {
    node.descendants_with_tokens()
        .filter_map(|element| element.into_token())
        .filter(|token| !token.kind().is_trivia())
        .collect()
}
#[derive(Default)]
struct MacroBodyBindings {
    /// A word the expansion may apply to any name: `macro_use`,
    /// `no_implicit_prelude`, or a glob `use` whose root is not this crate.
    any: Option<String>,
    /// Trusted names the body defines (`macro_rules! assert_eq`, `macro
    /// assert_eq`) or imports (`use x::assert_eq;`, `use x::y as assert_eq;`).
    names: Vec<String>,
    /// The body carries `macro_export`, so what it defines leaves the crate.
    exports: bool,
    /// The body defines or imports a name its caller passes in (`macro_rules!
    /// $name`). A call of an untrusted macro records the names in its
    /// arguments, but a call whose own name is trusted is never read, so a
    /// local `vec!` like this may bind any name. The text is the binding.
    binds_fragment: Option<String>,
}

/// The binding items in a `macro_rules!` or `macro` body. A body is a token
/// tree, so the items it emits never parse into the `MacroRules`, `Use` or
/// `Attr` nodes the scan reads; this reads them from the tokens instead.
/// Only binding positions count, so a test-generating macro whose body
/// calls `assert_eq!` and holds `use super::*;` binds nothing. `None` when
/// the node is not a macro definition.
fn macro_body_bindings(
    definition: &SyntaxNode,
    trusted: &dyn Fn(&str) -> bool,
) -> Option<MacroBodyBindings> {
    use ra_ap_syntax::SyntaxKind::{BANG, COLON, COLON2, COMMA, DOLLAR, R_CURLY, SEMICOLON, STAR};
    if !ast::MacroRules::can_cast(definition.kind()) && !ast::MacroDef::can_cast(definition.kind())
    {
        return None;
    }
    let tokens: Vec<_> = definition
        .children()
        .filter(|child| child.kind() == ra_ap_syntax::SyntaxKind::TOKEN_TREE)
        .flat_map(|tree| non_trivia_tokens(&tree))
        .collect();
    let word = |index: usize| {
        tokens
            .get(index)
            .map(|token| token.text().trim_start_matches("r#"))
    };
    let kind = |index: usize| tokens.get(index).map(|token| token.kind());
    let mut names: Vec<String> = Vec::new();
    let mut exports = false;
    let mut binds_fragment = None;
    let mut add = |name: &str| {
        if trusted(name) && !names.iter().any(|known| known == name) {
            names.push(name.to_string());
        }
    };
    for (index, token) in tokens.iter().enumerate() {
        match token.text().trim_start_matches("r#") {
            "macro_use" | "no_implicit_prelude" => {
                return Some(MacroBodyBindings {
                    any: Some(token.text().to_string()),
                    ..MacroBodyBindings::default()
                });
            }
            "macro_export" => exports = true,
            "macro_rules" if kind(index + 1) == Some(BANG) => {
                if kind(index + 2) == Some(DOLLAR) {
                    binds_fragment =
                        Some(format!("macro_rules! ${}", word(index + 3).unwrap_or("")));
                }
                if let Some(name) = word(index + 2) {
                    add(name);
                }
            }
            "macro" => {
                if kind(index + 1) == Some(DOLLAR) {
                    binds_fragment = Some(format!("macro ${}", word(index + 2).unwrap_or("")));
                }
                if let Some(name) = word(index + 1) {
                    add(name);
                }
            }
            "use" => {
                let end = (index + 1..tokens.len())
                    .find(|&at| kind(at) == Some(SEMICOLON))
                    .unwrap_or(tokens.len());
                let mut start = index + 1;
                while matches!(kind(start), Some(COLON | COLON2)) {
                    start += 1;
                }
                // `$crate` is this crate; any other fragment is unknown.
                let root = if kind(start) == Some(DOLLAR) {
                    word(start + 1).filter(|word| *word == "crate")
                } else {
                    word(start).filter(|word| matches!(*word, "crate" | "self" | "super"))
                };
                for at in start..end {
                    if kind(at) == Some(STAR) && root.is_none() {
                        let path: String = tokens
                            .get(index + 1..end)
                            .unwrap_or_default()
                            .iter()
                            .map(|token| token.text())
                            .collect();
                        return Some(MacroBodyBindings {
                            any: Some(format!("use {path}")),
                            ..MacroBodyBindings::default()
                        });
                    }
                    // A fragment past the root may name what is imported.
                    if at > start && kind(at) == Some(DOLLAR) {
                        binds_fragment = Some(format!("use ${}", word(at + 1).unwrap_or("")));
                    }
                    let Some(name) = word(at) else { continue };
                    // What a `use` binds ends its tree: a last segment or a
                    // rename target (`as name`), so a renamed-away segment
                    // (`assert_eq as check`) binds nothing.
                    let last = at + 1 >= end || matches!(kind(at + 1), Some(COMMA | R_CURLY));
                    if last {
                        add(name);
                    }
                }
            }
            _ => {}
        }
    }
    Some(MacroBodyBindings {
        any: None,
        names,
        exports,
        binds_fragment,
    })
}


fn read(s:&str)->MacroBodyBindings {
 let p=ast::SourceFile::parse(s,ra_ap_syntax::Edition::CURRENT);
 assert!(p.errors().is_empty(),"parser fixture: {:?}",p.errors());
 let n=p.tree().syntax().descendants().find(|n|ast::MacroRules::can_cast(n.kind()));
 match n.and_then(|n|macro_body_bindings(&n,&|v| v=="assert_eq")) {Some(b)=>b,None=>panic!("fixture has no macro")}
}
#[test] fn direct_leaf_must_record_caller_selected_binding(){
 let b=read("macro_rules! vec { ($n:path) => { use $n; }; }");
 assert!(b.binds_fragment.is_some(),"missing direct leaf");
}
#[test] fn effective_path_leaf_is_recorded(){
 let b=read("macro_rules! vec { ($n:ident) => { use provider::$n; }; }");
 assert!(b.binds_fragment.is_some());
}
#[test] fn direct_alias_away_does_not_bind_caller_name(){
 let b=read("macro_rules! vec { ($n:path) => { use $n as check; }; }");
 assert!(b.binds_fragment.is_none());assert!(b.names.is_empty());
}
#[test] fn matcher_only_must_not_bind(){
 let b=read("macro_rules! m { (use provider::assert_eq;) => {}; }");
 assert!(b.names.is_empty(),"matcher treated as emitted: {:?}",b.names);
 assert!(b.any.is_none());
}
#[test] fn emitted_named_binding_is_recorded(){
 let b=read("macro_rules! m { () => { use provider::assert_eq; }; }");
 assert_eq!(b.names,vec!["assert_eq".to_string()]);
}
#[test] fn private_glob_has_no_export(){
 let b=read("macro_rules! m { () => { use provider::*; }; }");
 assert!(b.any.is_some());assert!(!b.exports);
}
