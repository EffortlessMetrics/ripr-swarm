from pathlib import Path
import json,hashlib,tarfile,datetime,subprocess,os
r=Path(__file__).resolve().parent
dest=Path('/workspace/review8147-publication/evidence/8147/independent-425317d')
dest.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C','/workspace/review8147',*args],text=True).strip()
files=[]
for p in r.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(r)
    if rel.parts[0] in ['native','provider','fixtures']:
        if p.suffix=='.rs' or p.name in ['Cargo.toml','change.diff']:files.append(p)
    elif len(rel.parts)==1 and (p.suffix in ['.py','.json','.log','.stdout','.stderr'] or p.name=='syntax-controls.rs'):
        files.append(p)
files.sort()
inventory=[]
with tarfile.open(dest/'controls.tar.gz','w:gz') as t:
    for p in files:
        t.add(p,arcname=str(p.relative_to(r)),recursive=False)
        inventory.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode & 0o777),'sha256':sha(p.read_bytes())})
with tarfile.open(dest/'controls.tar.gz','r:gz') as t:
    members=t.getmembers()
    assert len(members)==len(inventory)
    for m,row in zip(members,inventory):
        assert m.name==row['path'] and m.size==row['bytes'] and oct(m.mode)==row['mode']
        assert sha(t.extractfile(m).read())==row['sha256']
(dest/'archive-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
receipt={'as_of_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'EffortlessMetrics/ripr-swarm','pr':8147,'reviewed_head':git('rev-parse','HEAD'),'reviewed_tree':git('rev-parse','HEAD^{tree}'),'parent':git('rev-parse','HEAD^'),'observed_pr_base':'116598e5207372cdca620a8931600dcb8890b514','source_status':git('status','--porcelain'),'source_blobs':{p:git('rev-parse','HEAD:'+p)for p in ['Cargo.lock','crates/ripr/src/analysis/syntax/owner_pin.rs','crates/ripr/src/analysis/classify/owner_pin.rs']},'platform':'Linux x86_64-unknown-linux-gnu','rustc':'1.95.0 59807616e1fa2540724bfbac14d7976d7e4a3860','features':'default','profiles':'dev/test debug=0','cli_build_exit':0,'unit_exit':0,'unit_counts':{'pass':6,'fail':0,'ignored':0,'filtered':11041},'matrix_exit':0,'native_test_runs':22,'syntax_component_exit':101,'syntax_counts':{'pass':4,'intentional_assertion_fail':2},'candidate_source_changes':False,'archive_members':len(inventory),'archive_sha256':sha((dest/'controls.tar.gz').read_bytes()),'local_paths':{'worktree':'/workspace/review8147','common_git_directory':git('rev-parse','--git-common-dir'),'cargo_target':'/workspace/review8147-target','raw_and_native_witnesses':str(r),'frozen_analyzer':str(r/'witness/ripr'),'inherited_checkout':'/workspace/ripr-swarm'},'storage':{'observed_free_before_build':'30 GiB','conservative_peak_additional_budget':'8 GiB','task_floor':'10 GiB free; no host reserve configured/overridden','preserved':'inherited checkout/target; review worktrees and all witnesses; no cleanup'},'witnesses':[],'limits':['No full protection/required-check inventory: connector workflow reads first-page-only','No direct-leaf false-exposed demonstrated: generated test gives no_static_path','No exact-base runtime comparison/current-main composition/Windows/release proof','No candidate source push or state transition']}
for p in [r/'witness/ripr',r/'syntax-controls']+sorted((r/'native').glob('*/*')):
    if p.is_file():receipt['witnesses'].append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(dest/'README.md').write_bytes((r/'README.md').read_bytes())
for name in ['results.json','ci.json']:(dest/name).write_bytes((r/name).read_bytes())
names=sorted(p for p in dest.iterdir() if p.is_file())
(dest/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n'for p in names))
print(json.dumps({'files':len(names)+1,'members':len(inventory),'archive_bytes':(dest/'controls.tar.gz').stat().st_size,'source_head':receipt['reviewed_head']}))
