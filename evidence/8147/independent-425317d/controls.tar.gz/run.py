import pathlib, subprocess, json, os, hashlib, difflib
ROOT=pathlib.Path(__file__).resolve().parent
ENV=dict(os.environ, PATH='/workspace/.cargo/bin:'+os.environ['PATH'], RUSTUP_HOME='/workspace/.rustup', CARGO_HOME='/workspace/.cargo')
RUSTC='/workspace/.cargo/bin/rustc'
BIN=os.environ.get('RIPR_REVIEW_BIN','/workspace/review8147-target/debug/ripr')
def run(args, stem, cwd=None):
    p=subprocess.run(args,cwd=cwd,env=ENV,capture_output=True,timeout=120)
    (ROOT/(stem+'.stdout')).write_bytes(p.stdout)
    (ROOT/(stem+'.stderr')).write_bytes(p.stderr)
    return p.returncode
def write(p,s):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
provider=ROOT/'provider'
write(provider/'Cargo.toml','[package]\nname="provider"\nversion="0.1.0"\nedition="2021"\n[workspace]\n')
write(provider/'src/lib.rs','#[macro_export]\nmacro_rules! assert_eq { ($a:expr,$b:expr) => {{ let _ = (&$a,&$b); }}; }\n')
assert run([RUSTC,'--edition=2021','--crate-name','provider','--crate-type','rlib',str(provider/'src/lib.rs'),'-o',str(ROOT/'libprovider.rlib')],'provider')==0
cases={
 'plain':('',None),
 'matcher_only':('macro_rules! m { (use provider::assert_eq;) => {}; }\n',None),
 'emitted_named':('macro_rules! m { () => { use provider::assert_eq; }; }\nm!();\n',None),
 'direct_leaf_path':('macro_rules! vec { ($n:path) => { use $n; }; }\nvec!(provider::assert_eq);\n',None),
 'path_leaf':('macro_rules! vec { ($n:ident) => { use provider::$n; }; }\nvec!(assert_eq);\n',None),
 'direct_alias_away':('macro_rules! vec { ($n:path) => { use $n as check; }; }\nvec!(provider::assert_eq);\n',None),
 'private_glob_other_crate':('', 'macro_rules! m { () => { use provider::*; }; }\nm!();\n'),
 'private_named_other_crate':('', 'macro_rules! m { () => { use provider::assert_eq; }; }\nm!();\n'),
 'direct_glob_other_crate':('', 'use provider::*;\n'),
 'exported_glob_other_crate':('', '#[macro_export]\nmacro_rules! m { () => { use provider::*; }; }\n'),
 'private_glob_same_crate':('macro_rules! m { () => { use std::io::*; }; }\nm!();\n',None),
}
records=[]
for name,(prefix,bench) in cases.items():
    path=ROOT/'fixtures'/name
    for old in path.glob('*.rs'):
        dest=ROOT/'superseded-native'/name/old.name
        dest.parent.mkdir(parents=True,exist_ok=True)
        old.rename(dest)
    manifest='[package]\nname="demo"\nversion="0.1.0"\nedition="2021"\n[workspace]\n[dependencies]\nprovider={path="../../provider"}\n'
    # Each fixture lives two levels below ROOT; provider is ROOT/provider.
    manifest=manifest.replace('../../provider','../../provider')
    write(path/'Cargo.toml',manifest)
    test='#[test] fn weighs() { assert_eq!(weight(4), 12); }'
    if name in ['emitted_named','direct_leaf_path','path_leaf','direct_alias_away']:
        prefix=prefix.replace('; }; }','; '+test+' }; }')
        source=prefix+'pub fn weight(x: i32) -> i32 { x * 3 }\n'
    else:
        source=prefix+'pub fn weight(x: i32) -> i32 { x * 3 }\n'+test+'\n'
    write(path/'src/lib.rs',source)
    if bench is not None:write(path/'benches/other.rs',bench+'fn main() {}\n')
    before=source.replace('x * 3','x * 2')
    diff=''.join(difflib.unified_diff(before.splitlines(True),source.splitlines(True),fromfile='a/src/lib.rs',tofile='b/src/lib.rs'))
    write(path/'change.diff',diff)
    native={}
    for variant,s in [('correct',source),('wrong',before)]:
        f=ROOT/'native'/name/(variant+'.rs');write(f,s)
        exe=f.with_suffix('')
        rc=run([RUSTC,'--edition=2021','--test',str(f),'--extern','provider='+str(ROOT/'libprovider.rlib'),'-o',str(exe)],name+'-'+variant+'-compile')
        assert rc==0,(name,variant,'setup compile',rc)
        rc=run([str(exe),'--nocapture'],name+'-'+variant+'-run')
        out=(ROOT/(name+'-'+variant+'-run.stdout')).read_text()
        assert 'running 1 test' in out,(name,'empty native subject')
        native[variant]=rc
    if bench is not None:
        assert run([RUSTC,'--edition=2021',str(path/'benches/other.rs'),'--extern','provider='+str(ROOT/'libprovider.rlib'),'-o',str(path/'bench-native')],name+'-bench-compile')==0
    rc=run([BIN,'check','--root',str(path),'--diff',str(path/'change.diff'),'--mode','ready','--format','json'],name+'-static')
    assert rc==0,(name,'analyzer',rc)
    report=json.loads((ROOT/(name+'-static.stdout')).read_text())
    rows=report['findings']
    assert rows,(name,'empty static subjects')
    records.append(dict(case=name,native=native,findings=rows))
    print(name,native,[(r['probe']['family'],r['classification']) for r in rows],flush=True)
(ROOT/'results.json').write_text(json.dumps(records,indent=2)+'\n')
