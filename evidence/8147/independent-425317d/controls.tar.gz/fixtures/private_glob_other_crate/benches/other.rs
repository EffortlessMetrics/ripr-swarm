macro_rules! m { () => { use provider::*; }; }
m!();
fn main() {}
