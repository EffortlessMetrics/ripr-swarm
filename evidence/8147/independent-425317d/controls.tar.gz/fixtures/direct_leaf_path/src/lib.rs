macro_rules! vec { ($n:path) => { use $n; #[test] fn weighs() { assert_eq!(weight(4), 12); } }; }
vec!(provider::assert_eq);
pub fn weight(x: i32) -> i32 { x * 3 }
