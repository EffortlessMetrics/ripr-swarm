macro_rules! m { (use provider::assert_eq;) => {}; }
pub fn weight(x: i32) -> i32 { x * 3 }
#[test] fn weighs() { assert_eq!(weight(4), 12); }
