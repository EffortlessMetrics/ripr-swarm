macro_rules! m { () => { use provider::assert_eq; }; }
m!();
fn main() {}
