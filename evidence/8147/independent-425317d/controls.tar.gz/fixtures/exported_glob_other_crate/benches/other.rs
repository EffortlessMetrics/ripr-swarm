#[macro_export]
macro_rules! m { () => { use provider::*; }; }
fn main() {}
