macro_rules! vec { ($n:ident) => { use provider::$n; #[test] fn weighs() { assert_eq!(weight(4), 12); } }; }
vec!(assert_eq);
pub fn weight(x: i32) -> i32 { x * 2 }
