macro_rules! m { () => { use std::io::*; }; }
m!();
pub fn weight(x: i32) -> i32 { x * 2 }
#[test] fn weighs() { assert_eq!(weight(4), 12); }
