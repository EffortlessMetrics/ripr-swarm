import pathlib,json,lzma,tarfile,collections,hashlib,statistics,subprocess,os
h=pathlib.Path('/workspace/repair8004');e=h/'evidence';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/ripr-swarm',text=True).strip()
def load(p):
 p=pathlib.Path(p)
 return json.loads(p.read_bytes() if p.exists() else lzma.open(str(p)+'.xz','rb').read())
def differences(a,b,p=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):return [v for k in sorted(a.keys()|b.keys()) for v in differences(a.get(k),b.get(k),p+'/'+k)]
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):return [v for i,(x,y) in enumerate(zip(a,b)) for v in differences(x,y,p+'/'+str(i))]
 return [dict(path=p,before=a,after=b)]
root_fields={'/metadata/root','/root','/canonical_next_action/subject/root','/canonical_next_action/stop/detail_route','/canonical_next_action/alternatives/0/route'}
def comparison(a,b,newroot):
 a.pop('artifact',None);b.pop('artifact',None);root=a.get('root',a.get('metadata',{}).get('root'));ds=differences(a,b);bad=[]
 for d in ds:
  allowed=(d['path']=='/source_subject/corpus/cache_schema_version' and d['before']=='1.78' and d['after']=='1.79') or (d['path'] in root_fields and isinstance(root,str) and isinstance(d['before'],str) and d['after']==d['before'].replace(root,str(newroot)))
  if not allowed:bad.append(d)
 return dict(complete_report_differences=ds,semantic_projection_equal=not bad,unaccepted=bad)
cli=[]
for i in range(63):
 for fmt in ['repo-exposure-json','repo-exposure-summary-json','json']:
  rel=pathlib.Path(f'{i:02}')/fmt;lane='cli' if i<59 else ('extra-cli' if i==59 else 'operand-cli');old=h/'review-raw'/lane/rel;new=h/'replay-final/cli'/rel
  assert (old/'src/lib.rs').read_bytes()==(new/'src/lib.rs').read_bytes()
  cli.append(dict(case=i,format=fmt,prior_packet_path=str(old.relative_to(h/'review-raw')),**comparison(load(old/'output.json'),load(new/'output.json'),new)))
assert all(x['semantic_projection_equal'] for x in cli)
(e/'cli-submitted-exact-a5-comparison.json').write_text(json.dumps(dict(head=head,reports=len(cli),rows=cli,failures=[]),indent=2))
oldhome=h/'prior-performance/evidence/8004/performance-a5';selected={}
for line in (oldhome/'measurements.tsv').read_text().splitlines():
 f=line.split('\t')
 if f[0]=='main' and f[4]=='candidate' and f[5]=='cold' and f[7]=='0':selected.setdefault((f[1],f[2]),f"raw/main-{f[1]}-{f[2]}-{f[3]}-candidate-cold.json")
lookup={v:k for k,v in selected.items()};bench=[]
with tarfile.open(oldhome/'raw-measurements.tar.xz','r|xz') as t:
 for member in t:
  if member.name not in lookup:continue
  workload,mode=lookup[member.name];a=json.load(t.extractfile(member));b=load(e/f'raw/main-{workload}-{mode}-0-candidate-cold.json');bench.append(dict(workload=workload,mode=mode,prior_sample=member.name,**comparison(a,b,h/'workloads'/workload)))
assert len(bench)==len(selected);assert all(x['semantic_projection_equal'] for x in bench)
missing=[dict(workload=w.name,mode=m,reason='prior a5 cold timeout/interruption; no completed output comparison') for w in sorted((h/'workloads').iterdir()) for m in ['full','compact'] if (w.name,m) not in selected]
(e/'benchmark-exact-a5-semantic-comparison.json').write_text(json.dumps(dict(head=head,compared_complete_prior_reports=len(bench),rows=bench,prior_censored=missing,failures=[]),indent=2))
resources=load(e/'resource-receipts.json');groups=collections.defaultdict(list)
for row in resources:
 assert len(row['receipts'])==1
 r=row['receipts'][0];assert r['cpu']['state']=='observed' and r['peak_resident_bytes']['state']=='observed';groups[(row['workload'],row['mode'],row['path'],row['variant'])].append((r['cpu']['user_ms']+r['cpu']['system_ms'],r['peak_resident_bytes']['value']))
summary=[dict(workload=k[0],mode=k[1],path=k[2],variant=k[3],n=len(v),cpu_ms_median=statistics.median(x[0] for x in v),cpu_ms_range=[min(x[0] for x in v),max(x[0] for x in v)],peak_rss_bytes_median=statistics.median(x[1] for x in v),peak_rss_bytes_range=[min(x[1] for x in v),max(x[1] for x in v)]) for k,v in sorted(groups.items())]
(e/'resource-summary.json').write_text(json.dumps(summary,indent=2))
controls=load(e/'output-controls.json');assert controls['samples_checked']==384 and not controls['within_variant_failures'] and not controls['process_failures'] and not controls['incomplete_groups'];assert all(x.get('full_compact_inventory_and_grip_parity',True) for x in controls['outputs'])
print(json.dumps(dict(head=head,cli_reports=len(cli),prior_benchmark_reports=len(bench),prior_censored=missing,processes=controls['main_process_count'],semantic_failures=0,resource_samples=len(resources)),indent=2))
