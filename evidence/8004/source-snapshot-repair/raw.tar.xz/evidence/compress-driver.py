import pathlib,sys,json,hashlib,lzma,os,stat,shutil
home=pathlib.Path('/workspace/repair8004');workload=sys.argv[1];manifest_path=home/'evidence/compressed-storage-manifest.json';rows=json.loads(manifest_path.read_text()) if manifest_path.exists() else []
raw=list((home/'evidence/raw').glob('main-'+workload+'-*'))
cache=[p for d in (home/'caches').glob('main-'+workload+'-*') for p in d.rglob('*') if p.is_file()]
files=sorted(raw+cache)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
for p in files:
 if p.name.endswith('.xz'):continue
 info=p.lstat();assert stat.S_ISREG(info.st_mode);dest=p.with_name(p.name+'.xz');assert not dest.exists();v=os.statvfs('/workspace');assert v.f_bavail*v.f_frsize>=8*1024**3+2*info.st_size+4*1024**2
 before=sha(p)
 with p.open('rb') as src,lzma.open(dest,'wb',preset=6) as out:shutil.copyfileobj(src,out,1024*1024)
 stage=home/'restore-verification'/'sample';assert not stage.exists()
 with lzma.open(dest,'rb') as src,stage.open('xb') as out:shutil.copyfileobj(src,out,1024*1024)
 shutil.copystat(p,stage);assert sha(stage)==before;assert stat.S_IMODE(stage.stat().st_mode)==stat.S_IMODE(info.st_mode);assert stage.stat().st_mtime_ns==info.st_mtime_ns
 rows.append(dict(path=str(p.relative_to(home)),xz_path=str(dest.relative_to(home)),raw_bytes=info.st_size,raw_sha256=before,xz_bytes=dest.stat().st_size,xz_sha256=sha(dest),mode=stat.S_IMODE(info.st_mode),mtime_ns=info.st_mtime_ns,full_restore_verified=True,workload=workload))
 manifest_path.write_text(json.dumps(rows,indent=2));p.unlink();stage.unlink()
print(json.dumps(dict(workload=workload,files=len(files),free_gib=os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize/1024**3)))
