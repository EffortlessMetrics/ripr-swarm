#[test]
fn owner_lexical_facts_are_shared_across_syntax_owners() {
    let index = index(&[(LIB, "fn helper() {}\n#[test] fn subject() { helper(); }\n")]);
    let first = OwnerPinSyntax::default()
        .file_scopes(&index, Path::new(LIB))
        .expect("scope table");
    let second = OwnerPinSyntax::default()
        .file_scopes(&index, Path::new(LIB))
        .expect("scope table");
    assert!(
        std::ptr::eq(&*first, &*second),
        "a source snapshot must share lexical facts across owners"
    );
    let cloned = index.clone();
    let other_index = OwnerPinSyntax::default()
        .file_scopes(&cloned, Path::new(LIB))
        .expect("scope table");
    assert!(!std::ptr::eq(&*first, &*other_index));
}
