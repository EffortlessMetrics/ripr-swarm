import pathlib,json,subprocess,hashlib,difflib,sys,os
E=pathlib.Path('/workspace/repair8004/replay-final'); E.mkdir(parents=True,exist_ok=True); mode=sys.argv[1]
cases=json.loads(pathlib.Path('/workspace/repair8004/review-raw/stimuli.json').read_text())
(E/'stimuli.json').write_text(json.dumps(cases,indent=2))
results=[]; violations=[]
for i,c in list(enumerate(cases))[int(os.getenv('REVIEW_START','0')):int(os.getenv('REVIEW_END',str(len(cases))))]:
 d=E/mode/f'{i:02}'; d.mkdir(parents=True,exist_ok=True); source=c['source']; digest=hashlib.sha256(source.encode()).hexdigest(); row=dict(index=i,path=c['path'],source_sha256=digest)
 if mode.startswith('native'):
  for variant,s in [('original',source),('mutant',source.replace('Self::Object(value) => Some(*value)','Self::Object(value) => None'))]:
   assert source.count('Self::Object(value) => Some(*value)')==1
   f=d/(variant+'.rs'); f.write_text(s); b=d/variant
   argv=['/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc','--edition=2024','--test',str(f),'-o',str(b)]
   run=subprocess.run(argv,capture_output=True,text=True); (d/(variant+'.compile.log')).write_text(run.stdout+run.stderr)
   assert run.returncode==0,(i,variant,run.stderr)
   run=subprocess.run([str(b)],capture_output=True,text=True); (d/(variant+'.run.log')).write_text(run.stdout+run.stderr)
   expected=101 if variant=='mutant' and c['native_reaches'] else 0
   assert 'running 1 test' in run.stdout,(i,run.stdout)
   row[variant]=dict(argv=argv,exit=run.returncode,expected=expected,sha256=hashlib.sha256(b.read_bytes()).hexdigest())
   if run.returncode!=expected: violations.append([i,variant,run.returncode,expected])
 else:
  binary=sys.argv[2]; row['reports']=[]; full=None
  for fmt in ['repo-exposure-json','repo-exposure-summary-json','json']:
   p=d/fmt;(p/'src').mkdir(parents=True,exist_ok=True); (p/'src/lib.rs').write_text(source); (p/'Cargo.toml').write_text('[package]\nname="independent-control"\nversion="0.0.0"\nedition="2024"\n[workspace]\n')
   patch='diff --git a/src/lib.rs b/src/lib.rs\n'+''.join(difflib.unified_diff(source.replace('Self::Object(value) => Some(*value),','Self::Object(value) => None,').splitlines(True),source.splitlines(True),fromfile='a/src/lib.rs',tofile='b/src/lib.rs'))
   (p/'diff.patch').write_text(patch); argv=[binary,'check','--root',str(p),'--mode','ready','--format',fmt]
   if fmt=='json': argv+=['--diff',str(p/'diff.patch')]
   run=subprocess.run(argv,capture_output=True,text=True);(p/'output.json').write_text(run.stdout);(p/'stderr.log').write_text(run.stderr);assert run.returncode==0,(i,fmt,run.stderr)
   data=json.loads(run.stdout); report=dict(argv=argv,exit=run.returncode)
   if fmt=='repo-exposure-json':
    assert data['run_status']=='complete'; full=data; seams=[s for s in data['seams'] if s['owner']=='src/lib.rs::impl JsonValue::as_object'];assert len(seams)==4,(i,len(seams)); rel=[]
    for s in seams:
     rs=s['related_tests']; assert len(rs)==1 and rs[0]['name']==c['name'],(i,rs); v=rs[0]['relation_reason'];rel.append(v)
     if c['relation'] is not None and v!=c['relation'] or c['relation'] is None and v in ['helper_owner_call','direct_owner_call']:violations.append([i,fmt,v,c['relation']])
    report['relations']=rel;report['metrics']=data['metrics']
   elif fmt=='repo-exposure-summary-json':
    m=data['metrics']; assert m['raw_seams']==full['metrics']['seams_total'];assert all(full['metrics'][k]==v for k,v in m['grip_class'].items()),i;report['metrics']=m
   else:
    assert len(data['findings'])==2,(i,len(data['findings']));rel=[]
    for f in data['findings']:
     assert f['related_tests'] and all(t['name']==c['name'] for t in f['related_tests']);rel.extend(t['relation_reason'] for t in f['related_tests'])
    if c['relation'] is None and any(r in ['direct_owner_call','helper_owner_call'] for r in rel):violations.append([i,fmt,rel,None])
    if c['relation']=='direct_owner_call' and any(r!='direct_owner_call' for r in rel):violations.append([i,fmt,rel,c['relation']])
    report['relations']=rel
   row['reports'].append(report)
 results.append(row);(E/mode/'results.json').write_text(json.dumps(results,indent=2));(E/mode/'violations.json').write_text(json.dumps(violations,indent=2));print(i,c['path'],flush=True)
print(json.dumps(dict(cases=len(cases),violations=violations)));assert not violations
