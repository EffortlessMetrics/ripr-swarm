# ripr golden drift report

Status: warn

This report summarizes expected-output drift for reviewer inspection. It never blesses goldens.

## Provenance

- binary: `/workspace/ripr-swarm/target/debug/ripr`
- ripr version: `ripr 0.11.0 (757da24c898e9daf34e11caba9330209fa55bfbc)`
- revision: `757da24c898e9daf34e11caba9330209fa55bfbc`

## Summary

- drift entries: 11
- fixture errors: 0

## Drift

### `inherent_receiver_async_function` `human.txt`

- expected: `fixtures/inherent_receiver_async_function/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_async_function/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_async_operand` `human.txt`

- expected: `fixtures/inherent_receiver_async_operand/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_async_operand/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_async_operand_helper` `human.txt`

- expected: `fixtures/inherent_receiver_async_operand_helper/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_async_operand_helper/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_dormant_body` `human.txt`

- expected: `fixtures/inherent_receiver_dormant_body/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_dormant_body/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_foreign_helper` `human.txt`

- expected: `fixtures/inherent_receiver_foreign_helper/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_foreign_helper/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_free_helper_identity` `human.txt`

- expected: `fixtures/inherent_receiver_free_helper_identity/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_free_helper_identity/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_helper_scope_shadow` `human.txt`

- expected: `fixtures/inherent_receiver_helper_scope_shadow/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_helper_scope_shadow/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_local_wrapper` `human.txt`

- expected: `fixtures/inherent_receiver_local_wrapper/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_local_wrapper/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_macro_discard` `human.txt`

- expected: `fixtures/inherent_receiver_macro_discard/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_macro_discard/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_module_type_shadow` `human.txt`

- expected: `fixtures/inherent_receiver_module_type_shadow/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_module_type_shadow/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_operand_item_shadow` `human.txt`

- expected: `fixtures/inherent_receiver_operand_item_shadow/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_operand_item_shadow/human.txt`
- changed lines: 1
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

## Fixture / Golden Violations

## Violations

```text
human.txt drift for fixture `inherent_receiver_async_function`
  expected: fixtures/inherent_receiver_async_function/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_async_function/human.txt
  diff:    line 33 expected `    - fixtures/inherent_receiver_async_function/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_async_operand`
  expected: fixtures/inherent_receiver_async_operand/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_async_operand/human.txt
  diff:    line 36 expected `    - fixtures/inherent_receiver_async_operand/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_async_operand_helper`
  expected: fixtures/inherent_receiver_async_operand_helper/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_async_operand_helper/human.txt
  diff:    line 33 expected `    - fixtures/inherent_receiver_async_operand_helper/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_dormant_body`
  expected: fixtures/inherent_receiver_dormant_body/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_dormant_body/human.txt
  diff:    line 36 expected `    - fixtures/inherent_receiver_dormant_body/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_foreign_helper`
  expected: fixtures/inherent_receiver_foreign_helper/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_foreign_helper/human.txt
  diff:    line 33 expected `    - fixtures/inherent_receiver_foreign_helper/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_free_helper_identity`
  expected: fixtures/inherent_receiver_free_helper_identity/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_free_helper_identity/human.txt
  diff:    line 33 expected `    - fixtures/inherent_receiver_free_helper_identity/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_helper_scope_shadow`
  expected: fixtures/inherent_receiver_helper_scope_shadow/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_helper_scope_shadow/human.txt
  diff:    line 33 expected `    - fixtures/inherent_receiver_helper_scope_shadow/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_local_wrapper`
  expected: fixtures/inherent_receiver_local_wrapper/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_local_wrapper/human.txt
  diff:    line 36 expected `    - fixtures/inherent_receiver_local_wrapper/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_macro_discard`
  expected: fixtures/inherent_receiver_macro_discard/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_macro_discard/human.txt
  diff:    line 36 expected `    - fixtures/inherent_receiver_macro_discard/input/src/lib.rs:6 (reachable_unrevealed)` vs actual `    - ./src/lib.rs:6 (reachable_unrevealed)`
```

```text
human.txt drift for fixture `inherent_receiver_module_type_shadow`
  expected: fixtures/inherent_receiver_module_type_shadow/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_module_type_shadow/human.txt
  diff:    line 36 expected `    - fixtures/inherent_receiver_module_type_shadow/input/src/lib.rs:6 (weakly_exposed)` vs actual `    - ./src/lib.rs:6 (weakly_exposed)`
```

```text
human.txt drift for fixture `inherent_receiver_operand_item_shadow`
  expected: fixtures/inherent_receiver_operand_item_shadow/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_operand_item_shadow/human.txt
  diff:    line 36 expected `    - fixtures/inherent_receiver_operand_item_shadow/input/src/lib.rs:11 (weakly_exposed)` vs actual `    - ./src/lib.rs:11 (weakly_exposed)`
```

