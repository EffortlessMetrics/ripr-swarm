import pathlib,json,sys,collections
E=pathlib.Path('/workspace/review8004-evidence');other=sys.argv[1];out=[]
def diff(a,b,path=''):
 if type(a)!=type(b):return [(path,a,b)]
 if isinstance(a,dict):
  r=[]
  for k in a.keys()|b.keys():
   if path=='' and k=='artifact':continue
   if k not in a or k not in b:r.append((path+'/'+k,a.get(k),b.get(k)))
   else:r+=diff(a[k],b[k],path+'/'+k)
  return r
 if isinstance(a,list):
  if len(a)!=len(b):return [(path+'/length',len(a),len(b))]
  return [d for i,(x,y) in enumerate(zip(a,b)) for d in diff(x,y,path+'/'+str(i))]
 return [] if a==b else [(path,a,b)]
for i in range(63):
 for fmt in ['repo-exposure-json','repo-exposure-summary-json','json']:
  a=json.loads((E/f'replay/candidate/{i:02}/{fmt}/output.json').read_text());b=json.loads((E/f'replay/{other}/{i:02}/{fmt}/output.json').read_text());d=diff(a,b)
  if d:out.append({'case':i,'format':fmt,'differences':d})
p=E/f'cli-{other}-differences.json';p.write_text(json.dumps(out,indent=2));print({'reports':189,'different':len(out),'difference_paths':collections.Counter(x[0] for row in out for x in row['differences'])});print(out[:1])
