from pathlib import Path
import os,subprocess,json,time,hashlib,csv,collections
E=Path('/workspace/review8004-evidence');H=Path('/workspace/review8004-run');P=E/'profile';P.mkdir(exist_ok=True);rows=[]
for w in ['fixture-mix-16','sync-16-single','sync-16-split','sync-64-split','sync-64-single']:
 for mode,fmt in [('full','repo-exposure-json'),('compact','repo-exposure-summary-json')]:
  id=w+'-'+mode;env=os.environ.copy();env.update(REVIEW_PROFILE_OUT=str(P/(id+'.tsv')),RIPR_CACHE_DIR=str(H/'profile-caches'/id),RAYON_NUM_THREADS='4',RIPR_REPO_EXPOSURE_LATENCY_TRACE='1');argv=['timeout','180s',str(E/'bin/profile'),'check','--root',str(H/'workloads'/w),'--format',fmt];start=time.monotonic()
  with (P/(id+'.json')).open('w') as out,(P/(id+'.stderr')).open('w') as err:r=subprocess.run(argv,env=env,stdout=out,stderr=err)
  row={'workload':w,'mode':mode,'argv':argv,'wall_s':time.monotonic()-start,'exit':r.returncode};rows.append(row);(E/'profile-runs.json').write_text(json.dumps(rows,indent=2));print(id,row['wall_s'],r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
  report=json.loads((P/(id+'.json')).read_text());report.pop('artifact',None);ref=H/'evidence/raw'/f'independent-{w}-{mode}-0-candidate-cold.json';base=json.loads(ref.read_text());base.pop('artifact',None);assert report==base,(id,'instrumented output differs');row['complete_output_equal_after_artifact_removal']=True
  (E/'profile-runs.json').write_text(json.dumps(rows,indent=2))
summary=[]
for row in rows:
 id=row['workload']+'-'+row['mode'];sites=collections.defaultdict(lambda:dict(calls=0,inclusive_ns=0,input_bytes=0,unique_inputs=0,repeated_calls=0))
 for x in csv.DictReader((P/(id+'.tsv')).open(),delimiter='\t'):
  key=(x['kind'],x['file'],x['line']);s=sites[key];n=int(x['calls']);s['calls']+=n;s['inclusive_ns']+=int(x['inclusive_ns']);s['input_bytes']+=int(x['input_bytes'])*n;s['unique_inputs']+=1;s['repeated_calls']+=max(0,n-1)
 rec={'workload':row['workload'],'mode':row['mode'],'wall_s':row['wall_s'],'sites':[dict(kind=k[0],file=k[1],line=int(k[2]),**v,inclusive_s=v['inclusive_ns']/1e9) for k,v in sorted(sites.items(),key=lambda x:x[1]['inclusive_ns'],reverse=True)]};summary.append(rec)
(E/'profile-summary.json').write_text(json.dumps(summary,indent=2));print('all10 profile reports match unmodified candidate')
