from pathlib import Path
import json,statistics,collections,hashlib
E=Path('/workspace/review8004-evidence');H=Path('/workspace/review8004-run');rows=[r.split('\t') for r in (H/'evidence/measurements.tsv').read_text().splitlines()];groups=collections.defaultdict(list);norm={};bad=[];hashes=[];reports={}
for r in rows:
 label,w,mode,round_,variant,cache,seconds,status,bytes_,ns=r
 f=H/'evidence/raw'/('-'.join(r[:6])+'.json');raw=f.read_bytes();d=json.loads(raw);d.pop('artifact',None);key=(w,mode,variant)
 expected=98 if w=='fixture-mix-16' else (112 if '16' in w else 448)
 assert int(status)==0 and len(raw)==int(bytes_),r
 if mode=='full':assert d['run_status']=='complete' and d['metrics']['seams_total']==expected,(w,mode,d['metrics'])
 else:assert d['metrics']['raw_seams']==expected,(w,mode,d['metrics'])
 groups[(w,mode,variant,cache)].append((int(round_),float(seconds)))
 if key in norm and norm[key]!=d:bad.append(r[:6])
 else:norm[key]=d
 hashes.append({'path':str(f.relative_to(H)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()});reports[(w,mode,variant,round_,cache)]=d
summary=[]
for (w,mode,v,cache),samples in sorted(groups.items()):
 vals=[x[1] for x in samples];med=statistics.median(vals);summary.append({'workload':w,'mode':mode,'variant':v,'cache':cache,'n':len(vals),'median_s':med,'MAD_s':statistics.median([abs(x-med) for x in vals]),'min_s':min(vals),'max_s':max(vals),'samples_s':vals})
paired=[]
for (w,mode,v,cache),samples in sorted(groups.items()):
 if v!='candidate' or (w,mode,'base',cache) not in groups:continue
 b=dict(groups[(w,mode,'base',cache)]);ratios=[s/b[i] for i,s in samples];paired.append({'workload':w,'mode':mode,'cache':cache,'repair_over_a5_ratios':ratios,'median_ratio':statistics.median(ratios)})
def diff(a,b,path=''):
 if type(a)!=type(b):return [(path,a,b)]
 if isinstance(a,dict):
  return [d for k in a.keys()|b.keys() for d in (diff(a[k],b[k],path+'/'+k) if k in a and k in b else [(path+'/'+k,a.get(k),b.get(k))])]
 if isinstance(a,list):
  if len(a)!=len(b):return [(path+'/length',len(a),len(b))]
  return [d for i,(x,y) in enumerate(zip(a,b)) for d in diff(x,y,path+'/'+str(i))]
 return [] if a==b else [(path,a,b)]
cross=[];metricbad=[]
for (w,mode,v),d in norm.items():
 if v=='candidate' and (w,mode,'base') in norm:
  ds=diff(norm[(w,mode,'base')],d)
  if ds:cross.append({'workload':w,'mode':mode,'differences':ds})
 if mode=='full':
  c=norm[(w,'compact',v)]['metrics'];m=d['metrics']
  if c['raw_seams']!=m['seams_total'] or any(m[k]!=n for k,n in c['grip_class'].items()):metricbad.append([w,v])
out={'processes':len(rows),'nonzero_exits':[r for r in rows if r[7]!='0'],'groups':summary,'paired':paired,'within_variant_mismatches':bad,'full_compact_metric_mismatches':metricbad,'cross_variant_differences':cross,'denominator':'three descriptive repetitions; no general no-regression or qualification claim'};(E/'fresh-performance.json').write_text(json.dumps(out,indent=2));(E/'fresh-output-manifest.json').write_text(json.dumps(hashes,indent=2));print(json.dumps(out,indent=2))
