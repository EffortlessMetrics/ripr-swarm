from pathlib import Path
root=Path('/workspace/review8004-profile/crates/ripr/src')
(root/'review_profile.rs').write_text('''use std::{collections::BTreeMap, sync::{Mutex,OnceLock}, time::Instant, hash::{Hash,Hasher}, panic::Location};
type Key = (&'static str, &'static str, u32, usize, u64);
static DATA: OnceLock<Mutex<BTreeMap<Key,(u64,u128)>>> = OnceLock::new();
pub struct Guard { key: Key, start: Instant }
impl Guard {
 #[track_caller]
 pub fn new(kind: &'static str, input: &str) -> Self {
  let l=Location::caller();let mut h=std::collections::hash_map::DefaultHasher::new();input.hash(&mut h);
  Self{key:(kind,l.file(),l.line(),input.len(),h.finish()),start:Instant::now()}
 }
}
impl Drop for Guard { fn drop(&mut self) { let ns=self.start.elapsed().as_nanos(); if let Ok(mut data)=DATA.get_or_init(Mutex::default).lock() { let row=data.entry(self.key).or_default();row.0+=1;row.1+=ns; } } }
pub fn dump() { if let Some(path)=std::env::var_os("REVIEW_PROFILE_OUT") { if let Some(data)=DATA.get() { if let Ok(data)=data.lock() {let mut s=String::from("kind\\tfile\\tline\\tinput_bytes\\tinput_hash\\tcalls\\tinclusive_ns\\n");for ((kind,file,line,len,hash),(count,ns)) in data.iter(){s.push_str(&format!("{kind}\\t{file}\\t{line}\\t{len}\\t{hash}\\t{count}\\t{ns}\\n"));}let _=std::fs::write(path,s); } } } }
''')
p=root/'lib.rs';p.write_text(p.read_text()+'\n#[doc(hidden)]\npub mod review_profile;\n')
p=root/'main.rs';p.write_text(p.read_text().replace('    run_startup(startup::run);','    run_startup(startup::run);\n    ripr::review_profile::dump();'))
p=root/'analysis/syntax/nesting.rs';s=p.read_text()
for fn in ['parse_clean_source_file','parse_source_file']:
 old=f'pub(crate) fn {fn}(text: &str)'
 s=s.replace(old,'#[track_caller]\n'+old)
 sig=f'pub(crate) fn {fn}(text: &str) -> '
 start=s.index('{',s.index(sig))+1
 s=s[:start]+f'\n    let _profile = crate::review_profile::Guard::new("{fn}", text);'+s[start:]
p.write_text(s)
p=root/'analysis/syntax/source_snapshot.rs';s=p.read_text();s=s.replace('let compute = || {\n            let tree', 'let compute = || {\n            let _profile = crate::review_profile::Guard::new("declaration_miss", "");\n            let tree');s=s.replace('let compute = || {\n            name_scopes', 'let compute = || {\n            let _profile = crate::review_profile::Guard::new("name_scopes_miss", "");\n            name_scopes');needle='        let base = |text: String|';s=s.replace(needle,'        let _profile = crate::review_profile::Guard::new("nesting_miss", "");\n'+needle);p.write_text(s)
