from pathlib import Path
import json,tarfile,hashlib,io,decimal,stat
E=Path('/workspace/review8004-evidence');H=Path('/workspace/review8004-run');D=Path('/workspace/review8004-publication');D.mkdir(exist_ok=True)
files={}
allowed={'.json','.jsonl','.log','.tsv','.md','.patch','.py','.rs','.sh','.txt','.stderr','.toml','.lock'}
for p in sorted(E.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(E)
 if rel.parts[0] in ['bin','packet'] or rel.parts[0].startswith('cli-cache-') or rel.parts[:2]==('replay','cli'):continue
 if p.suffix not in allowed:continue
 files['review/'+str(rel)]=p
for folder in ['evidence','caches','profile-caches']:
 for p in sorted((H/folder).rglob('*')):
  if p.is_file():files['timing/'+str(p.relative_to(H))]=p
for w in ['fixture-mix-16','sync-16-single','sync-16-split','sync-64-single','sync-64-split']:
 for p in sorted((H/'workloads'/w).rglob('*')):
  if p.is_file():files['inputs/'+str(p.relative_to(H))]=p
files['inputs/immutable-stimuli.json']=E/'packet/evidence/immutable-stimuli.json';files['drivers/bench.rs']=E/'packet/evidence/bench.rs'
manifest=[]
with tarfile.open(D/'raw.tar.xz','w:xz',format=tarfile.PAX_FORMAT) as t:
 for name,p in sorted(files.items()):
  b=p.read_bytes();s=p.stat();ns=s.st_mtime_ns;info=tarfile.TarInfo(name);info.size=len(b);info.mode=stat.S_IMODE(s.st_mode);info.mtime=ns/1e9;info.pax_headers={'mtime':f'{ns//1000000000}.{ns%1000000000:09d}'};t.addfile(info,io.BytesIO(b));manifest.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':info.mode,'mtime_ns':ns})
expected={r['path']:r for r in manifest};seen=[]
with tarfile.open(D/'raw.tar.xz') as t:
 for m in t:
  assert m.isfile();b=t.extractfile(m).read();e=expected[m.name];assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'] and m.mode==e['mode'];assert int(decimal.Decimal(m.pax_headers['mtime'])*1000000000)==e['mtime_ns'];seen.append(m.name)
assert set(seen)==set(expected)
out={'archive_sha256':hashlib.sha256((D/'raw.tar.xz').read_bytes()).hexdigest(),'archive_bytes':(D/'raw.tar.xz').stat().st_size,'member_files':len(manifest),'member_bytes':sum(x['bytes'] for x in manifest),'all_complete_reads_bytes_modes_mtime_match':True,'members':manifest};(D/'MANIFEST.json').write_text(json.dumps(out,indent=2));print({k:v for k,v in out.items() if k!='members'})
