import json,pathlib,subprocess,os,hashlib
E=pathlib.Path('/workspace/review8004-evidence'); cs=json.loads((E/'packet/evidence/immutable-stimuli.json').read_text());root=E/'invalidation/input';(root/'src').mkdir(parents=True,exist_ok=True);(root/'Cargo.toml').write_text('[package]\nname="invalidation-control"\nversion="0.0.0"\nedition="2024"\n[workspace]\n');rows=[]
for step,case in enumerate([61,60,61]):
 source=cs[case]['source'];(root/'src/lib.rs').write_text(source)
 for fmt in ['repo-exposure-json','repo-exposure-summary-json']:
  for cache in ['reused','fresh']:
   env=os.environ.copy();env['RIPR_CACHE_DIR']=str(E/'invalidation'/('shared-cache' if cache=='reused' else f'fresh-{step}-{fmt}'));env['RAYON_NUM_THREADS']='4';argv=[str(E/'bin/candidate'),'check','--root',str(root),'--format',fmt];r=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=120);p=E/'invalidation'/f'{step}-{fmt}-{cache}.json';p.write_text(r.stdout);p.with_suffix('.stderr').write_text(r.stderr);assert r.returncode==0,(step,fmt,cache,r.stderr);d=json.loads(r.stdout)
   if fmt=='repo-exposure-json':
    seams=[s for s in d['seams'] if s['owner']=='src/lib.rs::impl JsonValue::as_object'];assert len(seams)==4;relations=[x['relation_reason'] for s in seams for x in s['related_tests']];assert ('helper_owner_call' in relations)==(case==61),(step,relations)
   else:relations=[]
   projection={k:v for k,v in d.items() if k!='artifact'}
   if cache=='reused':saved=projection
   else:assert projection==saved,(step,fmt,'fresh-vs-reused complete report mismatch')
   rows.append({'step':step,'case':case,'format':fmt,'cache':cache,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'exit':r.returncode,'relations':relations})
(E/'invalidation/results.json').write_text(json.dumps(rows,indent=2));print('12 reports pass; sync→async→sync replacement matches fresh complete reports')
