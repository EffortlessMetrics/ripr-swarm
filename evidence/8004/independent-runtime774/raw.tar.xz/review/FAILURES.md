# Setup and retained limitations

The selected executor successfully started; the predecessor container_service_failed is historical, not a runtime result here.

- Initial archive command named a not-yet-created working directory. exec-server returned No such file/directory before any command ran. Created the owned directory from the existing repo and reran materialization.
- Initial rustc probe used default /home/agent/.rustup, which is read-only. Explicit installed /workspace Cargo/Rustup homes and PATH fixed setup before compilation. No credentials or permissions changed.
- A post-extraction repo-relative rg query was issued from the packet directory and missed .agents/skills. Repository guidance had been read at exact revision through the connected GitHub tools and then source was inspected in the owned checkout.
- Original archive bytes/sizes/modes all pass; timestamp precision differs from manifest by−226..225ns for5,149 members. Kept this limitation instead of claiming exact timestamp preservation.
- All actual builds,884 units,14 integrations,63 originals/63 mutants,176 workload tests,189 candidate/189 baseline/189 composition CLI reports,12 invalidation reports,96 timing processes and10 profile runs complete with their expected outcomes. No runtime or measurement outcome is silently retried, censored or backfilled.
- Raw timings and profiles are separate. Profiling spans are inclusive and do not establish exclusive attribution of the entire residual. n=3 cannot establish general no-regression. The substantial sync64 single-file cost is unresolved.

Prior failures/censoring/storage history remain retained in packet525d1e7d and are not replaced. No full-workspace, Windows or hosted-checkout qualification is claimed.
