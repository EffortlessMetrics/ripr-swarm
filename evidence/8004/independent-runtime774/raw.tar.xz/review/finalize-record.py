from pathlib import Path
import json,datetime,hashlib
E=Path('/workspace/review8004-evidence');D=Path('/workspace/review8004-publication');D.mkdir(exist_ok=True)
load=lambda f:json.loads((E/f).read_text());perf=load('fresh-performance.json');prof=load('profile-summary.json');cp=next(r for r in prof if r['workload']=='sync-64-single' and r['mode']=='compact');fp=next(r for r in prof if r['workload']=='sync-64-single' and r['mode']=='full')
firstmiss={r['kind']:r['inclusive_s'] for r in cp['sites'] if r['kind'] in ['declaration_miss','nesting_miss','name_scopes_miss']}
assert perf['processes']==96 and not perf['nonzero_exits'] and not perf['within_variant_mismatches'] and not perf['full_compact_metric_mismatches'];assert len(load('profile-runs.json'))==10 and all(r['complete_output_equal_after_artifact_removal'] for r in load('profile-runs.json'))
for r in perf['cross_variant_differences']:assert r['differences']==[['/source_subject/corpus/cache_schema_version','1.78','1.79']]
receipt={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'EffortlessMetrics/ripr-swarm','pr':8004,'reviewed_head':'77474e347bbdd8ef2101b7f9865e65f094df44c1','source_tree':'6aafd27b5ee2971dcfa052bfc911bae74b69a4d8','integrated_basis':'f2ba9522267e88dfb03e3006e83129dfd2a8bb72','disposition':'REVIEW_INCOMPLETE / MATERIAL_RECOVERY_CONFIRMED / RESIDUAL_COST_VERIFIED; keep Draft; no new correctness defect identified in this bounded runtime supplement','candidate_binary':load('candidate-binary.json'),'baseline_binary':load('a5-binary.json'),'source_units':load('unit-results.json'),'source_integrations':load('integration-results.json'),'native_controls':{'originals_pass':63,'owner_mutants_fail':28,'owner_mutants_survive':35,'expected_contract_violations':0,'native_positive_but_high_attribution_withheld':4},'source_CLI':{'stimuli':63,'reports':189,'contract_violations':0,'a5_complete_report_parity':'126 equal after artifact-only removal;63 full reports differ only1.78→1.79 cache schema','cache_invalidation_reports':12,'cache_invalidation':'same path sync→async→sync reused cache equals fresh complete reports after artifact-only removal'},'workload_native':load('workload-native-results.json'),'performance':perf,'profile':{'experiment':load('profile-binary.json'),'runs':load('profile-runs.json'),'sync64_single_compact':cp,'sync64_single_full':fp,'compact_source_snapshot_first_misses_inclusive_s':firstmiss,'duration_warning':'Inclusive accumulated wall durations; nested parser/query scopes overlap and full mode is concurrent. Do not sum categories or equate totals with exclusive CPU/wall attribution. Fingerprints count input contents, not caller identities.','unit_struct_workspace_scan_calls_in_all_profiles':sum(s['calls'] for r in prof for s in r['sites'] if s['kind']=='unit_struct_workspace_scan')},'composition':load('composition-receipt.json'),'github_observed':load('github-observed-state.json'),'honesty_corpus_tree_identical_to_a5':'3d4cba61b83bc67620a14c3dc7a516c148801986','original_packet':{'commit':'525d1e7d489710bb4cabb5b7a1cf2047eaf993ad','verification':load('archive-verification.json'),'recomputed':load('retained-packet-recomputed.json'),'output_controls':load('retained-output-controls.json')},'threads_at_observation':{'total':13,'resolved':1,'unresolved':12,'changed_by_this_review':0},'next_repair':'Reuse complete-source snapshot parse/line/scope facts and optionally fully keyed shadow answers in owner_pin::test_module_shadows_item first; then share immutable caller and assertion-operand syntax. Preserve complete source/caller/owner/type-or-trait identity, owner-module exemptions, lexical anchors and every conservative refusal. Re-run same matrix/timings/profile before any clearance. No implementation made.','non_claims':['exclusive attribution of entire residual cost','general no-regression from n3','new a5 sync64 scaling ratio','base98 equivalence','full-workspace runtime','Windows','hosted required-check or actual-job-checkout qualification','moving latest-main qualification','Ready or merge clearance'],'authorization_preserved':['no candidate source push','no Ready/merge/thread resolution','no release/deploy/spending','no credential/security changes','no destructive cleanup','no bot contact','no issue8005 read/retry']}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2));(E/'receipt.json').write_text(json.dumps(receipt,indent=2))
med=lambda w,m,v:next((r['median_s'] for r in perf['groups'] if r['workload']==w and r['mode']==m and r['variant']==v and r['cache']=='cold'),None)
rows=[]
for w in ['fixture-mix-16','sync-16-single','sync-16-split','sync-64-single','sync-64-split']:
 for m in ['full','compact']:
  b=med(w,m,'base');c=med(w,m,'candidate');rows.append(f'| {w} | {m} | {b:.3f} | {c:.3f} |' if b is not None else f'| {w} | {m} | not run | {c:.3f} |')
readme='''# Independent runtime supplement — Draft #8004

**MATERIAL_RECOVERY_CONFIRMED / RESIDUAL_COST_VERIFIED / REVIEW_INCOMPLETE. Keep Draft.**

Source head `77474e347bbdd8ef2101b7f9865e65f094df44c1`, tree `6aafd27b5ee2971dcfa052bfc911bae74b69a4d8`; integrated basis `f2ba9522267e88dfb03e3006e83129dfd2a8bb72`. This completes the bounded runtime supplement to [the source-only review](https://github.com/EffortlessMetrics/ripr-swarm/pull/8004#pullrequestreview-5541396381). It does not provide full merge qualification. No new correctness defect was identified in these controls.

## Observed source-runtime evidence

- Pinned Rust1.95.0, locked/default-feature unchanged release profile (LTO, one codegen unit, stripped), Linux, four-CPU quota/five-CPU affinity,16GiB memory, Rayon4. Both independently built executables exactly reproduce packet digests: candidate `14f33ad70bc5faa922663d8136eeda8ac386db6106bf09cce1b85ab266091e78`; a5 `0aa3bb1e350f866e538f3e195763660b7c4740d1227b38bef2d0369f843be7a4`.
- **884 distinct units and14 public-path integrations pass at literal final head.** This refreshes the predecessor-only observations, including all four source-snapshot sharing/identity/ambiguity/replacement/clone/removal tests.
- **63 originals pass;28 native owner mutants fail and35 survive**, exactly matching retained native truth. The35 native negatives receive no high direct/helper attribution. Four native-positive unsupported shapes intentionally continue withholding it; no accuracy labels were changed.
- **189 candidate CLI reports pass** across full/fresh-compact/diff.189 a5 reports agree in every field after artifact removal, except the expected full cache-schema1.78→1.79 provenance transition.12 additional same-path sync→async→sync reused/fresh-cache reports agree completely after artifact removal.
- Selected workload native controls:176 actual tests pass. The concatenated split module bodies equal the corresponding single-file bytes for both16 and64; derived sync16-split uses retained modules0..15. Manifests retain this correspondence.
- Honesty corpus remains the identical a5 Git subtree `3d4cba61b83bc67620a14c3dc7a516c148801986`. This is preservation, not fresh general accuracy qualification.

## Fresh bounded release repeats

Three alternating AB/BA pairs for fixture/sync16 single/split; three repaired-only repeats for sync64 single/split. Both full/compact and immediate cold/warm partners: **96 successful processes**, zero timeouts, complete nonempty expected inventories, no within-variant output drift or full/compact metric mismatch. All paired output differences are only the declared full cache-schema transition. No build, native setup or profiling overlaps timing. Each process has a120-second bound. Cold is analyzer-cache-cold, not OS-cache-cold. n=3 is descriptive; warm/no-regression/general qualification is not inferred. Individual times, ratios, MAD/ranges, resource/phase traces and raw reports are retained.

| Workload | Mode | a5 cold median s | Repair cold median s |
|---|---|---:|---:|
'''+ '\n'.join(rows)+'''

Sync64 compact single-file range is81.909–85.050s, median84.703s; split median2.968s. The prior87.728s observation is independently confirmed as a substantial remaining cost, not erased by the recovery.

## Measured residual and next repair

An isolated seven-file instrumentation experiment at tree `9cda8cee2a9137935f6c4571feec4b7b41a243c7`, patch SHA256 `d12f0c9e2adc3d317147f1de60311b2528619a593eeb590517b5a843643b1a81`, uses the same release profile. Its binary is `da42c086c614eea0ef5e2159874b68a3cc002ac53de7b0bae16ffb70b812b685`. All10 cold profile reports equal the unmodified candidate after artifact-only removal. Diagnostic processes have a180-second bound and are separate from benchmark samples.

In sync64 single-file compact (instrumented wall88.261s):

| Candidate site | Calls | Distinct input contents | Inclusive parse duration |
|---|---:|---:|---:|
| `owner_pin.rs:9912`, `test_module_shadows_item` complete-source parse |12,288|1|39.153s|
| `related_tests.rs:3126`, executable caller body |1,292,640|4|11.505s|
| `related_tests.rs:3271`, synthetic assertion operand |516,160|2|3.533s|

The complete-source shadow parse is the largest measured parse site in fixture and sync16/64 single-file profiles. SourceSnapshot declaration/nesting/name-scope first-miss durations are small by comparison; the existing UnitStructFacts workspace-collector counter is zero on these workloads. The new evidence therefore prioritizes `test_module_shadows_item`, beyond the previous caller/operand-only source hypothesis.

**Next bounded repair:** route that shadow authority through the existing exact-source snapshot parse, line index and reusable scope/declaration facts; memoize shadow answers only with complete source/test identity, type-versus-trait/base and owner-scope identity. Preserve owner-module exemptions, aliases/raw identifiers, same-line ambiguity, malformed-source refusal and fallback behavior. Then reuse immutable caller/operand parses with original lexical anchors and owner-dependent resolution. Retain and re-run every async/scope/native/CLI control and the same timing/profile workloads. No such repair was implemented here.

Durations are accumulated inclusive wall spans. Nested parser/query spans overlap, and full mode runs concurrently; totals are not exclusive CPU attribution and must not be summed into wall percentages. Fingerprints group byte contents, not lexical caller identities. Remaining uninstrumented work is not attributed to one query.

## Separate current-main composition

Frozen observed main `20022bbfeb0d29882f97f51dc5f83ead26919dd4` +candidate77474e347 produces clean local tree `20c28e245b806ada153fe49c1c78eab205d421c3`, local two-parent commit `f8553783808d8ffb6db288e8427a301bafe23411`. Its dev/debug0 binary independently passes189 CLI reports. Compared on identical paths with the source release reports,126 are equal after artifact removal and63 full reports differ only in cache-schema1.79→1.80. Literal source unit/integration and performance results above are not relabeled composition runs.

Separately observed GitHub merge object `2be47f8c5e12c17efc2b996d50c7f627f7ee9322` has parents6239039f80a71d6a2dd12b551118fd48e3b6a551/77474e347 and tree `3e82855ea311d9f4eb9925a91c5a090419ac13bc`. It is a different, unexecuted subject; no hosted job checkout is established. PR metadata's base SHA and the main ref are preserved separately in the receipt.

## Recovery and limits

Recovered [packet525d1e7d](https://github.com/EffortlessMetrics/ripr-swarm/tree/525d1e7d489710bb4cabb5b7a1cf2047eaf993ad/evidence/8004/source-snapshot-repair): all five checksums and all5,464 archive member bytes/sizes/modes/inventory pass independently. Archive timestamps retain rounding differences versus the manifest (5,149 members,−226..225ns); no exact-nanosecond claim is made for that archive. Independently decoded all384 retained reports, recomputed published medians and confirmed40 within-variant groups/full-compact metric controls. Prior failures, censored samples and storage history remain in the original packet; none are rewritten as new passes.

All13 returned review threads were read; one already resolved,12 unresolved, none changed here. The residual performance concern remains. Hosted required-check/actual-checkout, native Windows, full-workspace runtime, base98 equivalence and new a5 sync64 scaling ratios remain outside this proof. Keep Draft; no Ready/merge clearance.

Candidate/root source stays untouched; only isolated reviewer instrumentation differs. No candidate source push, Ready, merge, thread resolution, release/deploy, spending, credential/security change, destructive cleanup, bot contact or issue8005 read/retry. All local witnesses remain retained.

## Replay and artifacts

`receipt.json` is the compact typed receipt; `MANIFEST.json` binds every member of `raw.tar.xz`; `SHA256SUMS` binds the public packet. The raw archive includes exact selected inputs, original bench.rs, instrumentation patch, command drivers, compiler/native/unit/integration logs, all CLI/benchmark/profile outputs, statistics and relevant cache states. Executables are retained in the selected executor with hashes/recipes; executable bytes are not distributed by this packet.

The raw `review/PERFORMANCE-PROTOCOL.md` and scripts record actual commands. Recover original packet525d1e7d, create review-owned exact-head/a5 checkouts, use Rust1.95.0 and the unchanged profile; adapt workspace prefixes. Run `cargo fetch --locked --manifest-path fixtures/owner_return_pin_fallible_literal/input/Cargo.toml` in the same Cargo home before owner-pin tests. Build the retained Rust bench.rs driver, use the verified input bytes, and run the stored three-round commands without overlapping builds. Apply the diagnostic patch only in a separate exact-head checkout; its complete tree/hash and output-parity rules are retained. Original selected-executor absolute paths are evidence locations, not assumed shared filesystem transfers.
'''
(D/'README.md').write_text(readme);(E/'README.md').write_text(readme)
(E/'FAILURES.md').write_text('''# Setup and retained limitations

The selected executor successfully started; the predecessor container_service_failed is historical, not a runtime result here.

- Initial archive command named a not-yet-created working directory. exec-server returned No such file/directory before any command ran. Created the owned directory from the existing repo and reran materialization.
- Initial rustc probe used default /home/agent/.rustup, which is read-only. Explicit installed /workspace Cargo/Rustup homes and PATH fixed setup before compilation. No credentials or permissions changed.
- A post-extraction repo-relative rg query was issued from the packet directory and missed .agents/skills. Repository guidance had been read at exact revision through the connected GitHub tools and then source was inspected in the owned checkout.
- Original archive bytes/sizes/modes all pass; timestamp precision differs from manifest by−226..225ns for5,149 members. Kept this limitation instead of claiming exact timestamp preservation.
- All actual builds,884 units,14 integrations,63 originals/63 mutants,176 workload tests,189 candidate/189 baseline/189 composition CLI reports,12 invalidation reports,96 timing processes and10 profile runs complete with their expected outcomes. No runtime or measurement outcome is silently retried, censored or backfilled.
- Raw timings and profiles are separate. Profiling spans are inclusive and do not establish exclusive attribution of the entire residual. n=3 cannot establish general no-regression. The substantial sync64 single-file cost is unresolved.

Prior failures/censoring/storage history remain retained in packet525d1e7d and are not replaced. No full-workspace, Windows or hosted-checkout qualification is claimed.
''')
print('final receipt/README prepared; all asserted runtime controls pass')
