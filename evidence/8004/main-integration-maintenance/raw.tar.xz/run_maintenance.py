import subprocess,os,json,time,pathlib
out=pathlib.Path('/workspace/integration8004/maintenance-evidence'); root='/workspace/integration8004/maintenance'
env=os.environ.copy();env.update(CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_TARGET_DIR='/workspace/integration8004/target',CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='4',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',PATH='/workspace/.cargo/bin:'+env['PATH'])
commands=[['cargo','test','--locked','-p','ripr','--lib','inherent'],['cargo','test','--locked','-p','ripr','--lib','source_snapshot'],['cargo','test','--locked','-p','ripr','--lib','module_shadow_snapshot'],['cargo','test','--locked','-p','ripr','--test','private_inherent_receiver'],['cargo','test','--locked','-p','ripr','--test','cli_help_hierarchy'],['cargo','test','--locked','-p','ripr','--test','returned_element_field_pin'],['cargo','check','--locked','-p','xtask']]
receipts=[]
for i,cmd in enumerate(commands):
 start=time.time(); log=out/f'corrected-{i}.log'
 with log.open('w') as f:
  p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 row=dict(command=cmd,start_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),elapsed_seconds=time.time()-start,exit=p.returncode,log=log.name)
 receipts.append(row);(out/'corrected-checks.json').write_text(json.dumps(receipts,indent=2));print(json.dumps(row),flush=True)
 if p.returncode: break
