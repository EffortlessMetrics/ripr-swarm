from pathlib import Path
import json,hashlib,subprocess,shutil,sys
H=Path('/workspace/review8004');kind=sys.argv[1];sha={'candidate':'8e0444b1a62ead18584d40b18278c6e8716dc56c','base':'77474e347bbdd8ef2101b7f9865e65f094df44c1'}[kind];root=H/('source' if kind=='candidate' else 'base')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha and not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
rs=[json.loads(l) for l in (H/'logs'/('build-release' if kind=='candidate' else 'build-base')).with_suffix('.jsonl').read_text().splitlines()];assert rs[-1]=={'reason':'build-finished','success':True}
a=[r for r in rs if r.get('reason')=='compiler-artifact' and r['target']['kind']==['bin'] and r['target']['name']=='ripr'];assert len(a)==1;a=a[0];dst=H/'bin'/kind;shutil.copy2(a['executable'],dst);v=subprocess.check_output([str(dst),'--version'],text=True).strip();assert sha in v
stamp=[dict(r['env']) for r in rs if r.get('reason')=='build-script-executed' and r.get('package_id')==a['package_id']];assert any(r.get('RIPR_BUILD_COMMIT')==sha and r.get('RIPR_BUILD_COMMIT_DIRTY')=='false' for r in stamp)
e=json.loads((H/'packet/receipt.json').read_text())['binaries']['candidate' if kind=='candidate' else 'baseline']['sha256'];digest=hashlib.sha256(dst.read_bytes()).hexdigest()
o={'source':sha,'version':v,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'artifact':a,'bytes':dst.stat().st_size,'sha256':digest,'retained_digest':e,'matches_retained_digest':digest==e,'compiler_stamp':stamp};(H/'logs'/(kind+'-binary.json')).write_text(json.dumps(o,indent=2));print({k:v for k,v in o.items() if k not in ['artifact','compiler_stamp']})
