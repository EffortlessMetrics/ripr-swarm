from pathlib import Path
import json,subprocess,hashlib,shutil,sys
H=Path('/workspace/review8004');kind=sys.argv[1];log='libtest-build' if kind=='candidate' else 'removal-build';rs=[json.loads(l) for l in (H/'logs'/(log+'.jsonl')).read_text().splitlines()];assert rs[-1]=={'reason':'build-finished','success':True}
art=[r for r in rs if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']];assert len(art)==1;art=art[0];b=H/'bin'/('units-'+kind);shutil.copy2(art['executable'],b);rows=[];subjects=set();failures=[]
filters=['source_snapshot','analysis::classify::owner_pin::','analysis::classify::call_identity::','analysis::syntax::name_scope::','analysis::classify::related_tests::','analysis::test_grip_evidence::'] if kind=='candidate' else ['source_snapshot','module_shadow_snapshot']
for f in filters:
 a=[str(b),f,'--test-threads=2'];r=subprocess.run(a,capture_output=True,text=True,timeout=300);text=r.stdout+r.stderr;(H/'logs'/('unit-'+kind+'-'+f.replace(':','_')+'.log')).write_text(text)
 for l in r.stdout.splitlines():
  if l.startswith('test ') and l.endswith(' ... ok'):subjects.add(l[5:-7])
  if l.startswith('test ') and l.endswith(' ... FAILED'):failures.append(l)
 if kind=='candidate':assert r.returncode==0,(f,text)
 else:assert r.returncode==101 and '1 failed' in text,(f,text)
 rows.append({'filter':f,'argv':a,'exit':r.returncode,'summary':[l for l in r.stdout.splitlines() if l.startswith('test result:')]});print(rows[-1],flush=True)
if kind=='candidate':assert len(subjects)==888,len(subjects)
else:
 assert len(subjects)==6 and len(failures)==2,(len(subjects),failures)
 assert any('fragment_parses_share_only_exact_bytes_and_clones_start_empty' in f for f in failures) and any('module_shadow_snapshot_shares_facts_and_complete_answers' in f for f in failures)
 assert 'identical shadow queries must compute once' in (H/'logs/unit-removal-module_shadow_snapshot.log').read_text()
 assert 'assertion failed: std::ptr::eq' in (H/'logs/unit-removal-source_snapshot.log').read_text()
o={'artifact':art,'binary':str(b),'sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'distinct_passed':len(subjects),'passed_subjects':sorted(subjects),'failed_subjects':failures,'results':rows};(H/'logs'/('unit-'+kind+'-results.json')).write_text(json.dumps(o,indent=2))
