from pathlib import Path
import json,tarfile,hashlib,io,os
H=Path('/workspace/review8004');O=H/'publication/evidence/8004/independent-shadow8e';O.mkdir(parents=True,exist_ok=True)
files=[]
for p in sorted((H/'logs').rglob('*')):
 if p.is_file() and p.name not in ['publication-verification.json','publication-verification-final.json']:files.append(p)
for name in ['protocol.md','source-review.md','native.py','workload-native.py','audit-packet.py','freeze.py','replay-cli.py','compare-fresh.py','invalidate.py','bench.py','bench-continue.py','run-libtests.py','run-integrations.py','package.py','summarize.py','profile-audit.py']:
 p=H/name
 if p.is_file():files.append(p)
for dirname in ['native','replay-new','invalidation','bench','anchor-control','anchor-native']:
 for p in sorted((H/dirname).rglob('*')):
  if p.is_file() and (p.suffix in ['.json','.log','.stderr','.rs','.toml','.patch']):files.append(p)
# Immutable inputs copied from verified packet, without generated caches/binaries.
for p in sorted((H/'raw/workloads').rglob('*')):
 if p.is_file():files.append(p)
files.append(H/'raw/replay/stimuli.json')
assert len(files)==len(set(files))
m=[]
with tarfile.open(O/'raw.tar.xz','w:xz',preset=6) as tf:
 for p in sorted(files):
  raw=p.read_bytes();rel=str(p.relative_to(H));mode=p.stat().st_mode&0o777;info=tarfile.TarInfo(rel);info.size=len(raw);info.mode=mode;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tf.addfile(info,io.BytesIO(raw));m.append({'path':rel,'bytes':len(raw),'mode':mode,'sha256':hashlib.sha256(raw).hexdigest()})
(O/'MANIFEST.json').write_text(json.dumps({'members':m,'timestamp_policy':'archive timestamps/uid/gid normalized to zero;no original nanosecond claim','excluded':'compiler/native executable bytes and mutable target/cache directories;exact compiler-artifact hashes/build logs retained'},indent=2)+'\n')
for line in (O/'SHA256SUMS').read_text().splitlines() if (O/'SHA256SUMS').exists() else []:pass
names=['README.md','receipt.json','MANIFEST.json','raw.tar.xz'];assert all((O/n).is_file() for n in names)
(O/'SHA256SUMS').write_text(''.join(hashlib.sha256((O/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in names))
# Full restore verification into an admitted separate path before publication.
V=H/'publication-verification-final';V.mkdir(exist_ok=False);expected={x['path']:x for x in m};seen=set()
with tarfile.open(O/'raw.tar.xz','r:xz') as tf:
 for t in tf:
  assert t.isfile() and t.name in expected and t.name not in seen;raw=tf.extractfile(t).read();e=expected[t.name];assert t.mode==e['mode'] and len(raw)==e['bytes'] and hashlib.sha256(raw).hexdigest()==e['sha256'];p=V/t.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(t.mode);assert p.read_bytes()==raw and p.stat().st_mode&0o777==t.mode;seen.add(t.name)
assert seen==set(expected);print(json.dumps({'files':len(m),'bytes':sum(x['bytes'] for x in m),'compressed_bytes':(O/'raw.tar.xz').stat().st_size,'all_member_bytes_sizes_modes_restored':True}))
