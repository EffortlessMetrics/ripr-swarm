from pathlib import Path
import json,csv,collections,hashlib
H=Path('/workspace/review8004');R=H/'raw';rows=[]
for p in sorted((R/'profile-results').glob('*.json')):
 name=p.stem;mode='full' if name.endswith('-full') else 'compact';w=name.rsplit('-',1)[0];a=json.loads(p.read_bytes());b=json.loads((R/f'evidence/raw/repair8e-{w}-{mode}-0-candidate-cold.json').read_bytes());a.pop('artifact',None);b.pop('artifact',None);assert a==b
 t=p.with_suffix('.tsv');rs=list(csv.DictReader(t.open(),delimiter='\t'));g=collections.defaultdict(lambda:[0,0])
 for r in rs:g[r['kind']][0]+=int(r['calls']);g[r['kind']][1]+=int(r['inclusive_ns'])
 rows.append({'workload':w,'mode':mode,'parity':True,'tsv_sha256':hashlib.sha256(t.read_bytes()).hexdigest(),'rows':len(rs),'by_kind':dict(g)})
assert len(rows)==10
s=next(r for r in rows if (r['workload'],r['mode'])==('sync-64-single','compact'))['by_kind'];assert s['shadow_scope_build'][0]==1 and s['fragment_query'][0]==1808800 and s['fragment_miss'][0]==6 and s['shadow_answer_miss'][0]==12288 and s['executable_query'][0]==1292640
(H/'logs/profile-audit.json').write_text(json.dumps({'reports':rows,'limits':'retained author-run instrumentation only;counts recomputed;inclusive spans overlap;fingerprints are not semantic query identities;not a fresh profile run'},indent=2));print(s)
