from pathlib import Path
import json,subprocess,os,time,statistics as S,hashlib
H=Path('/workspace/review8004');D=H/'bench';rows=json.loads((H/'logs/repeats.json').read_text());assert len(rows)==56
projections={}
for r in rows:
 if r['phase']=='cold':
  id=f"{r['workload']}-{r['mode']}-{r['round']}-{r['variant']}-{r['phase']}";d=json.loads((D/(id+'.json')).read_bytes());d.pop('artifact',None);projections[r['workload'],r['mode']]=d
id='sync-64-single-compact-0-base-cold';assert (D/(id+'.json')).exists()
rows.append({'workload':'sync-64-single','mode':'compact','round':0,'variant':'base','phase':'cold','elapsed_s':None,'deadline_s':120,'outcome':'timed_out','exit':None,'sha256':hashlib.sha256((D/(id+'.json')).read_bytes()).hexdigest(),'bytes':(D/(id+'.json')).stat().st_size,'resource':None,'limit':'Original driver stopped on TimeoutExpired;exact terminal elapsed and native exit were not captured. Nominal deadline120s retained;no complete report is claimed.'})
skips=[{'workload':'sync-64-single','mode':'compact','round':0,'variant':'base','phase':'warm','reason':'cold partner timed out;dependent warm not admitted'}]
env=os.environ.copy();env['RAYON_NUM_THREADS']='4';env['RIPR_REPO_EXPOSURE_LATENCY_TRACE']='1'
for w,modes in [('sync-64-single',[('compact','repo-exposure-summary-json')]),('sync-64-split',[('full','repo-exposure-json'),('compact','repo-exposure-summary-json')])]:
 for mode,fmt in modes:
  for i in range(2):
   for variant in (['base','candidate'] if i%2==0 else ['candidate','base']):
    if w=='sync-64-single' and i==0 and variant=='base':continue
    cache=H/f'bench-caches/{w}-{mode}-{i}-{variant}';assert not cache.exists();env['RIPR_CACHE_DIR']=str(cache)
    for phase in ['cold','warm']:
     id=f'{w}-{mode}-{i}-{variant}-{phase}';assert not (D/(id+'.json')).exists();a=[str(H/'bin'/variant),'check','--root',str(H/'raw/workloads'/w),'--format',fmt];timed_out=False
     with (D/(id+'.json')).open('wb') as out,(D/(id+'.stderr')).open('wb') as err:
      start=time.monotonic_ns()
      try:r=subprocess.run(a,stdout=out,stderr=err,env=env,timeout=120);exit=r.returncode
      except subprocess.TimeoutExpired:timed_out=True;exit=None
      elapsed=(time.monotonic_ns()-start)/1e9
     raw=(D/(id+'.json')).read_bytes();stderr=(D/(id+'.stderr')).read_bytes();row={'workload':w,'mode':mode,'round':i,'variant':variant,'phase':phase,'elapsed_s':elapsed,'exit':exit,'outcome':'timed_out' if timed_out else 'successful','deadline_s':120,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'resource':None}
     if timed_out:
      rows.append(row);skips.append({'workload':w,'mode':mode,'round':i,'variant':variant,'phase':'warm','reason':'cold partner timed out;dependent warm not admitted'});assert phase=='cold';(H/'logs/repeats.json').write_text(json.dumps(rows,indent=2));(H/'logs/repeats-skipped.json').write_text(json.dumps(skips,indent=2));print(id,'censored at120s',elapsed,flush=True);break
     assert exit==0,(id,exit,stderr);d=json.loads(raw);d.pop('artifact',None);assert (d['metrics']['seams_total'] if mode=='full' else d['metrics']['raw_seams'])==448
     if mode=='full':assert d['run_status']=='complete'
     k=(w,mode)
     if k in projections:assert d==projections[k],id
     else:projections[k]=d
     resources=[json.loads(l.split(' ',1)[1]) for l in stderr.decode().splitlines() if l.startswith('ripr_resource_cost_receipt ')];assert len(resources)==1;row['resource']=resources[0];rows.append(row);(H/'logs/repeats.json').write_text(json.dumps(rows,indent=2));(H/'logs/repeats-skipped.json').write_text(json.dumps(skips,indent=2));print(id,elapsed,flush=True)
 for mode in ['full','compact']:pass
 f=projections[w,'full']['metrics'];c=projections[w,'compact']['metrics'];assert c['raw_seams']==f['seams_total'] and all(f[k]==v for k,v in c['grip_class'].items())
summary=[]
for w,mode in projections:
 a=[r for r in rows if r['workload']==w and r['mode']==mode and r['phase']=='cold'];b={r['round']:r['elapsed_s'] for r in a if r['variant']=='base' and r['exit']==0};c={r['round']:r['elapsed_s'] for r in a if r['variant']=='candidate' and r['exit']==0};timeouts=[r for r in a if r.get('outcome')=='timed_out']
 summary.append({'workload':w,'mode':mode,'n_planned':2,'base_samples':[b[i] for i in sorted(b)],'candidate_samples':[c[i] for i in sorted(c)],'base_timeouts':len(timeouts),'base_median':S.median(b.values()) if len(b)==2 else None,'candidate_median':S.median(c.values()) if len(c)==2 else None,'median_paired_ratio':S.median(c[i]/b[i] for i in range(2)) if len(b)==len(c)==2 else None,'censoring':'predecessor compact samples censored at120;no uncensored median/paired ratio claimed' if timeouts else None})
(H/'logs/repeats-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'attempts':len(rows),'successes':sum(r['exit']==0 for r in rows),'timeouts':sum(r.get('outcome')=='timed_out' for r in rows),'dependent_warm_not_run':len(skips),'successful_complete_report_controls':'pass'}),flush=True)
