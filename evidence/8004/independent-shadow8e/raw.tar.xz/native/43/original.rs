#[derive(Clone, Copy)]
pub(crate) enum JsonValue { Object(u32), Null }
impl JsonValue {
    pub(crate) fn as_object(&self) -> Option<u32> {
        match self {
            Self::Object(value) => Some(*value),
            _ => None,
        }
    }
}
async fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }
#[cfg(test)] mod tests { use super::*;
#[test] fn subject() { use std::future::Future; let mut future = std::pin::pin!(read_as_object()); let mut context = std::task::Context::from_waker(std::task::Waker::noop()); assert_eq!(future.as_mut().poll(&mut context), std::task::Poll::Ready(Some(7))); }
}
