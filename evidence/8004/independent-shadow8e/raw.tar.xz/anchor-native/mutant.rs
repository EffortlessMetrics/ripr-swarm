#[derive(Clone, Copy)]
pub enum JsonValue { Object(u32), Null }
impl JsonValue {
    pub fn as_object(&self) -> Option<u32> {
        match self { Self::Object(value) => None, _ => None }
    }
}
#[cfg(test)] mod positive {
    use super::*;
    #[test] fn subject() { assert_eq!(JsonValue::Object(7).as_object(), Some(7)); }
}
#[cfg(test)] mod negative {
    use super::*;
    macro_rules! assert_eq { ($($t:tt)*) => { () }; }
    #[test] fn subject() { assert_eq!(JsonValue::Object(7).as_object(), Some(7)); }
}
