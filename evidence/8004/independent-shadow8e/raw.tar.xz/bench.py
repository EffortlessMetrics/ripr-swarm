from pathlib import Path
import json,subprocess,os,time,statistics as S,hashlib
H=Path('/workspace/review8004');D=H/'bench';D.mkdir(exist_ok=True);rows=[];projections={};env=os.environ.copy();env['RAYON_NUM_THREADS']='4';env['RIPR_REPO_EXPOSURE_LATENCY_TRACE']='1'
for w in ['fixture-mix-16','sync-16-single','sync-16-split','sync-64-single','sync-64-split']:
 for mode,fmt in [('full','repo-exposure-json'),('compact','repo-exposure-summary-json')]:
  for i in range(2):
   for variant in (['base','candidate'] if i%2==0 else ['candidate','base']):
    cache=H/f'bench-caches/{w}-{mode}-{i}-{variant}';assert not cache.exists();env['RIPR_CACHE_DIR']=str(cache)
    for phase in ['cold','warm']:
     id=f'{w}-{mode}-{i}-{variant}-{phase}';a=[str(H/'bin'/variant),'check','--root',str(H/'raw/workloads'/w),'--format',fmt];
     with (D/(id+'.json')).open('wb') as out,(D/(id+'.stderr')).open('wb') as err:
      start=time.monotonic_ns();r=subprocess.run(a,stdout=out,stderr=err,env=env,timeout=120);elapsed=(time.monotonic_ns()-start)/1e9
     r.stdout=(D/(id+'.json')).read_bytes();r.stderr=(D/(id+'.stderr')).read_bytes()
     (D/(id+'.json')).write_bytes(r.stdout);(D/(id+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(id,r.returncode,r.stderr)
     d=json.loads(r.stdout);d.pop('artifact',None);n=98 if w=='fixture-mix-16' else 112 if '16' in w else 448
     assert (d['metrics']['seams_total'] if mode=='full' else d['metrics']['raw_seams'])==n
     if mode=='full':assert d['run_status']=='complete'
     k=(w,mode)
     if k in projections:assert d==projections[k],id
     else:projections[k]=d
     resources=[json.loads(l.split(' ',1)[1]) for l in r.stderr.decode().splitlines() if l.startswith('ripr_resource_cost_receipt ')];assert len(resources)==1
     rows.append({'workload':w,'mode':mode,'round':i,'variant':variant,'phase':phase,'elapsed_s':elapsed,'exit':r.returncode,'sha256':hashlib.sha256(r.stdout).hexdigest(),'bytes':len(r.stdout),'resource':resources[0]});(H/'logs/repeats.json').write_text(json.dumps(rows,indent=2));print(id,elapsed,flush=True)
 for mode in ['full','compact']:
  pass
 f=projections[w,'full']['metrics'];c=projections[w,'compact']['metrics'];assert c['raw_seams']==f['seams_total'] and all(f[k]==v for k,v in c['grip_class'].items())
summary=[]
for w,mode in projections:
 a=[r for r in rows if r['workload']==w and r['mode']==mode and r['phase']=='cold'];b={r['round']:r['elapsed_s'] for r in a if r['variant']=='base'};c={r['round']:r['elapsed_s'] for r in a if r['variant']=='candidate'}
 summary.append({'workload':w,'mode':mode,'n':2,'base_samples':[b[i] for i in range(2)],'candidate_samples':[c[i] for i in range(2)],'base_median':S.median(b.values()),'candidate_median':S.median(c.values()),'median_paired_ratio':S.median(c[i]/b[i] for i in range(2))})
(H/'logs/repeats-summary.json').write_text(json.dumps(summary,indent=2));assert len(rows)==80;print('PASS:80 processes,complete-report equality and metric controls',flush=True)
