from pathlib import Path
import json,subprocess,hashlib
H=Path('/workspace/review8004');rs=[json.loads(l) for l in (H/'logs/integration-build.jsonl').read_text().splitlines()];assert rs[-1]=={'reason':'build-finished','success':True};arts=[r for r in rs if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']];assert len(arts)==2;rows=[]
for a in arts:
 b=a['executable'];r=subprocess.run([b,'--test-threads=2'],capture_output=True,text=True,timeout=300);text=r.stdout+r.stderr;(H/'logs'/('integration-'+a['target']['name']+'.log')).write_text(text);assert r.returncode==0
 rows.append({'artifact':a,'binary':b,'sha256':hashlib.sha256(Path(b).read_bytes()).hexdigest(),'exit':r.returncode,'summary':[l for l in r.stdout.splitlines() if l.startswith('test result:')]});print(rows[-1]['summary'],flush=True)
assert any('5 passed' in s for row in rows for s in row['summary']) and any('9 passed' in s for row in rows for s in row['summary']);(H/'logs/integration-results.json').write_text(json.dumps(rows,indent=2))
