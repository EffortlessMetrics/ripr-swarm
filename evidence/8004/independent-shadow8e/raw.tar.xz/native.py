import json, pathlib,subprocess,hashlib,datetime
H=pathlib.Path('/workspace/review8004'); cases=json.loads((H/'raw/replay/stimuli.json').read_text()); out=H/'native';out.mkdir(exist_ok=True); rows=[]
for i,c in enumerate(cases):
 d=out/f'{i:02}';d.mkdir(exist_ok=True);s=c['source'];assert s.count('Self::Object(value) => Some(*value)')==1
 row={'index':i,'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'case':c['path'],'results':{}}
 for v,text in [('original',s),('mutant',s.replace('Self::Object(value) => Some(*value)','Self::Object(value) => None'))]:
  p=d/(v+'.rs');p.write_text(text);b=d/v
  a=['/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc','--edition=2024','--test',str(p),'-o',str(b)]
  r=subprocess.run(a,capture_output=True,text=True,timeout=60);(d/(v+'.compile.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,(i,v,r.stderr)
  r=subprocess.run([str(b)],capture_output=True,text=True,timeout=30);(d/(v+'.run.log')).write_text(r.stdout+r.stderr);expected=101 if v=='mutant' and c['native_reaches'] else 0
  assert 'running 1 test' in r.stdout and r.returncode==expected,(i,v,r.stdout,r.stderr)
  row['results'][v]={'exit':r.returncode,'expected':expected,'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest()}
 rows.append(row);(H/'logs/native-results.json').write_text(json.dumps(rows,indent=2));print(i,c['path'],flush=True)
print('PASS:63 originals;28 mutant failures;35 mutant survivors',flush=True)
