from pathlib import Path
import json,hashlib,sys
H=Path('/workspace/review8004');variant=sys.argv[1]
def norm(v,old):
 if isinstance(v,str):return v.replace(old,'$ROOT')
 if isinstance(v,dict):return {k:norm(x,old) for k,x in v.items()}
 if isinstance(v,list):return [norm(x,old) for x in v]
 return v
rows=[]
for i in range(63):
 for fmt in ['repo-exposure-json','repo-exposure-summary-json','json']:
  a=H/f'replay-new/{variant}/{i:02}/{fmt}/output.json';b=H/f'raw/replay/cli/{i:02}/{fmt}/output.json';da=json.loads(a.read_bytes());db=json.loads(b.read_bytes());da.pop('artifact',None);db.pop('artifact',None)
  assert norm(da,str(H/f'replay-new/{variant}'))==norm(db,'/workspace/shadow8004/replay/cli'),(i,fmt)
  rows.append({'case':i,'format':fmt,'fresh_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'retained_sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
(H/f'logs/{variant}-complete-equality.json').write_text(json.dumps(rows,indent=2));print('PASS:189 complete report comparisons;top-level artifact removal and exact replay-root rebase only')
