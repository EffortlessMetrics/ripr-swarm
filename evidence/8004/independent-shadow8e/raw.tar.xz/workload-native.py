from pathlib import Path
import subprocess,json,hashlib,re
H=Path('/workspace/review8004'); rows=[]
for w in sorted((H/'raw/workloads').iterdir()):
 b=H/'bin'/('native-'+w.name);argv=['/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc','--edition=2024','--test',str(w/'src/lib.rs'),'-o',str(b)]
 r=subprocess.run(argv,capture_output=True,text=True,timeout=60);(H/'logs'/('workload-'+w.name+'.compile')).write_text(r.stdout+r.stderr);assert r.returncode==0
 r=subprocess.run([str(b)],capture_output=True,text=True,timeout=60);(H/'logs'/('workload-'+w.name+'.run')).write_text(r.stdout+r.stderr);count=int(re.search(r'running (\d+) tests',r.stdout)[1]);expected=64 if '64' in w.name else 16;assert r.returncode==0 and count==expected
 rows.append({'workload':w.name,'tests':count,'exit':r.returncode,'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
for n in [16,64]:
 a=(H/f'raw/workloads/sync-{n}-single/src/lib.rs').read_bytes();b=b''.join((H/f'raw/workloads/sync-{n}-split/src/file_{i}.rs').read_bytes() for i in range(n));assert a==b
print(rows);assert sum(r['tests'] for r in rows)==176;(H/'logs/workload-native.json').write_text(json.dumps(rows,indent=2))
