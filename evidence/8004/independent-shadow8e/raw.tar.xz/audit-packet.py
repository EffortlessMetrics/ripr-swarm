from pathlib import Path
import json,hashlib,statistics as S,collections
H=Path('/workspace/review8004');R=H/'raw';rows=[l.split('\t') for l in (R/'evidence/measurements.tsv').read_text().splitlines()];assert len(rows)==120
G=collections.defaultdict(list);D={};costs={}
for r in rows:
 label,w,m,i,v,c,t,ex,n,ns=r;id='-'.join(r[:6]);p=R/'evidence/raw'/(id+'.json');raw=p.read_bytes();assert ex=='0' and len(raw)==int(n)
 d=json.loads(raw);d.pop('artifact',None);D[id]=d;G[w,m,v,c].append((int(i),float(t)))
 assert (d['metrics']['seams_total'] if m=='full' else d['metrics']['raw_seams'])==(98 if w=='fixture-mix-16' else 112 if '16' in w else 448)
 if m=='full':assert d['run_status']=='complete'
 co=[json.loads(s.split(' ',1)[1]) for s in p.with_suffix('.stderr').read_text().splitlines() if s.startswith('ripr_resource_cost_receipt ')];assert len(co)==1;co=co[0];assert co['cpu']['state']==co['peak_resident_bytes']['state']=='observed';costs[id]=((co['cpu']['user_ms']+co['cpu']['system_ms'])/1000,co['peak_resident_bytes']['value'],co)
perf=json.loads((R/'logs/performance.json').read_text());assert len(perf['groups'])==len(G)==40 and all(sorted(i for i,_ in v)==[0,1,2] for v in G.values())
for g in perf['groups']:
 k=tuple(g[x] for x in ['workload','mode','variant','cache']);a=[t for _,t in G[k]];med=S.median(a)
 assert (g['n'],g['median_s'],g['MAD_s'],g['min_s'],g['max_s'],g['samples_s'])==(3,med,S.median(abs(t-med) for t in a),min(a),max(a),a)
for g in perf['paired']:
 w,m,c=[g[k] for k in ['workload','mode','cache']];b=dict(G[w,m,'base',c]);a=[t/b[i] for i,t in G[w,m,'candidate',c]];assert a==g['repair_over_774_ratios'] and S.median(a)==g['median_ratio']
res=json.loads((R/'logs/resources.json').read_text());assert len(res['processes'])==120
for p in res['processes']:assert costs[p['id']]==(p['cpu_s'],p['peak_resident_bytes'],p['receipt'])
for w in sorted({r[1] for r in rows}):
 for m in ['full','compact']:
  a=[D[f'repair8e-{w}-{m}-{i}-{v}-{c}'] for i in range(3) for v in ['base','candidate'] for c in ['cold','warm']];assert all(d==a[0] for d in a)
 f=D[f'repair8e-{w}-full-0-base-cold']['metrics'];c=D[f'repair8e-{w}-compact-0-base-cold']['metrics'];assert c['raw_seams']==f['seams_total'] and all(f[k]==v for k,v in c['grip_class'].items())
for e in json.loads((R/'logs/benchmark-output-manifest.json').read_text()):
 b=(R/e['path']).read_bytes();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
# Complete retained baseline/candidate reports, with only declared path/artifact normalization.
def norm(d,root):
 if isinstance(d,dict):return {k:norm(v,root) for k,v in d.items()}
 if isinstance(d,list):return [norm(v,root) for v in d]
 if isinstance(d,str):return d.replace(root,'$REPLAY')
 return d
for i in range(63):
 for fmt in ['repo-exposure-json','repo-exposure-summary-json','json']:
  a=json.loads((R/f'replay/cli/{i:02}/{fmt}/output.json').read_text());b=json.loads((R/f'replay/cli-base/{i:02}/{fmt}/output.json').read_text());a.pop('artifact',None);b.pop('artifact',None);assert norm(a,'/workspace/shadow8004/replay/cli')==norm(b,'/workspace/shadow8004/replay/cli-base'),(i,fmt)
summary={'packet_members':8985,'retained_processes':120,'retained_stat_groups':40,'retained_paired_groups':20,'retained_complete_baseline_candidate_comparisons':189,'full_compact_inventory_and_metrics':'pass','raw_resource_records':120,'normalization':'top-level artifact and exact replay-root rebase only','performance':perf}
(H/'logs/independent-packet-audit.json').write_text(json.dumps(summary,indent=2));print({k:v for k,v in summary.items() if k!='performance'})
