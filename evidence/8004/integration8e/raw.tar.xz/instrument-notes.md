# Setup/instrument limits retained

- Selected environment startup delayed local work until ready. No local execution was claimed during startup.
- Initial inventory looked for candidate-only files in inherited b772 checkout; absent there, then inspected isolated exact composition.
- Initial subject collector assumed candidate-added source_snapshot.rs existed on main; it failed and was corrected to record absent blobs as null. No check outcome resulted.
- Initial sequential test driver mistakenly includes nonexistent integration target private_target_attribution. It was not reached because the initial run stopped earlier on fixture setup. Removed before the supported continuation; no result is claimed for that target.
- No broad performance benchmarks, source edits, security/dependency repair, Ready, merge, thread resolution, bot contact or issue8005 access.
- A read-only gh GraphQL inventory request to api.github.com/graphql returned `Post "https://api.github.com/graphql": Forbidden` with exit 1. No retry, credential or route change for that request. The already-successful supported GitHub connector returned 13 complete thread objects with their comments; it exposes no pagination metadata. Do not label the failed CLI request a complete inventory or infer a global repository denial/quota cause.

- Initial inherent-filter run: 19 pass/5 setup failures, exit101. Repository .cargo/config.toml forces TMP/TEMP/TMPDIR to checkout-relative target, but a dedicated external CARGO_TARGET_DIR left that directory absent. All five failures report missing fixture directory before assertions. Created the task checkout target directory (no source edit) and reran the unchanged test set.
