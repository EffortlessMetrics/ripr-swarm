from pathlib import Path
import subprocess,json,hashlib,datetime
H=Path('/workspace/profile8004');repo='/workspace/ripr-swarm';old='8e0444b1a62ead18584d40b18278c6e8716dc56c';new='36dbb87430ef858aa143b5fc3205b376b0caee11'
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
def source(ref,p):return subprocess.check_output(['git','show',ref+':'+p],cwd=repo,text=True)
paths=['crates/ripr/src/analysis/'+p for p in ['classify/related_tests.rs','test_grip_evidence/related_tests/context.rs','classify/call_identity.rs','syntax/source_snapshot.rs','syntax/owner_pin.rs']]
blobs=[dict(path=p,old=git('rev-parse',old+':'+p),new=git('rev-parse',new+':'+p)) for p in paths];assert all(x['old']==x['new'] for x in blobs)
p='crates/ripr/src/analysis/classify/owner_pin.rs';a=source(old,p);b=source(new,p)
def func(s,name):
 start=s.index('fn '+name+'(');ls=s.rfind('\n',0,start)+1;spaces=s[ls:ls+len(s[ls:])-len(s[ls:].lstrip(' '))];opening=s.index('{',start);end=s.index('\n'+spaces+'}',opening)+len(spaces)+2;return s[ls:end],s[:ls].count('\n')+1
functions=[]
for name in ['targeted_source_provenance_is_admitted','targeted_macro_binding_is_unambiguous','trusted_macro_ambiguities','same_file_free_helper_call_reaches_owner','test_module_shadows_item','file_scopes']:
 x,ol=func(a,name);y,nl=func(b,name);assert x==y,name;functions.append(dict(name=name,old_line=ol,current_line=nl,body_bytes_equal=True,sha256=hashlib.sha256(x.encode()).hexdigest()))
r=dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),profiled_source=old,profiled_tree=git('rev-parse',old+'^{tree}'),live_head=new,live_tree=git('rev-parse',new+'^{tree}'),live_parents=git('show','-s','--format=%P',new).split(),live_basis='d08c77d144c016078364fcc1fcf2fa593d21cefc',pr_open_draft=True,unchanged_path_blobs=blobs,unchanged_owner_functions=functions,owner_pin_delta='196 additive lines: new fields and iteration/element-field support; measured function bodies unchanged',other_material_delta='main integration includes Cargo/dependencies, classifier and cache schema1.79->1.80/compact0.85->0.86 changes',inference='measured target and request-multiplication producer survive source inspection; all executed numbers remain frozen8e only, not new-head runtime/latency or cache qualification',candidate_ref_owned_by='Rook; external owner moved8e to36db during this task; no candidate write by profiling lane')
(H/'logs/source-currentness.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
