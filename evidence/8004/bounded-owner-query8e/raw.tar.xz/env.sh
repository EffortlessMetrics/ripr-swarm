export CARGO_HOME=/workspace/.cargo
export RUSTUP_HOME=/workspace/.rustup
export PATH=/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH
export CARGO_TARGET_DIR=/workspace/profile8004/target
export CARGO_BUILD_JOBS=2
export RAYON_NUM_THREADS=4
