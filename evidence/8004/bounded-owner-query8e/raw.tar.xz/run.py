from pathlib import Path
import os,subprocess,json,time,csv,hashlib
H=Path('/workspace/profile8004');O=H/'outputs';O.mkdir(exist_ok=True);rows=[]
def norm(x,root):
 if isinstance(x,dict):return {k:norm(v,root) for k,v in x.items()}
 if isinstance(x,list):return [norm(v,root) for v in x]
 if isinstance(x,str):return x.replace(str(root),'$ROOT')
 return x
def run(w,variant,phase='cold',pairs=False,anchor=False):
 ident=f'{w}-{variant}-{phase}'+('-pairs' if pairs else '')
 root=H/'retained/anchor-control' if anchor else H/'author/workloads'/w
 cache=H/'caches'/(f'{w}-{variant}'+('-pairs' if pairs else ''))
 if phase=='cold':assert not cache.exists(),cache
 env=os.environ.copy();env.update(RIPR_CACHE_DIR=str(cache),RAYON_NUM_THREADS='4',RIPR_REPO_EXPOSURE_LATENCY_TRACE='1',OWNER_PROFILE_OUT=str(O/(ident+'.tsv')))
 if pairs:env['OWNER_PROFILE_PAIRS']='1'
 argv=[str(H/'bin'/variant),'check','--root',str(root),'--format','repo-exposure-json' if anchor else 'repo-exposure-summary-json']
 start=time.monotonic_ns()
 with (O/(ident+'.json')).open('wb') as out,(O/(ident+'.stderr')).open('wb') as err:
  p=subprocess.run(argv,env=env,stdout=out,stderr=err,timeout=120)
 elapsed=(time.monotonic_ns()-start)/1e9
 row=dict(id=ident,argv=argv,exit=p.returncode,wall_s=elapsed,phase=phase,instrumented=variant=='profile',pairs=pairs);rows.append(row);(O/'runs.json').write_text(json.dumps(rows,indent=2));assert p.returncode==0,row
 d=json.loads((O/(ident+'.json')).read_text());d.pop('artifact',None)
 ref=H/'retained/logs/anchor-full.json' if anchor else H/f'author/evidence/raw/repair8e-{w}-compact-0-candidate-cold.json'
 r=json.loads(ref.read_text());r.pop('artifact',None)
 old='/workspace/review8004/anchor-control' if anchor else '/workspace/shadow8004/workloads/'+w
 assert norm(d,root)==norm(r,old),(ident,'complete output mismatch')
 row['complete_retained_output_equal']=True
 if not anchor:assert d['metrics']['raw_seams']==(448 if '64' in w else 112)
 if variant=='profile':
  row['spans']=list(csv.DictReader((O/(ident+'.tsv')).open(),delimiter='\t'))
  if pairs:
   lines=(O/(ident+'.pairs')).read_text().splitlines();counts=[int(l.split('\t',1)[0]) for l in lines]
   row['pair_summary']={'exact_requests':len(counts),'total_queries':sum(counts),'singletons':sum(n==1 for n in counts),'max_reuse':max(counts),'queries_after_first':sum(n-1 for n in counts)}
 (O/'runs.json').write_text(json.dumps(rows,indent=2));print(ident,round(elapsed,3),row.get('pair_summary',''),flush=True)
for w in ['sync-16-single','sync-16-split','sync-64-single','sync-64-split']:
 run(w,'clean');run(w,'profile');
 if '64' in w:run(w,'profile','warm')
# Cardinality pass only sync64 single; does not supply timing claims.
run('sync-64-single','profile',pairs=True)
run('anchor','clean',anchor=True);run('anchor','profile',anchor=True)
print('PASS: 13 bounded processes, retained complete parity; no full matrix',flush=True)
