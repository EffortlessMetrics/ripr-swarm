from pathlib import Path
import subprocess,json,hashlib,shutil,sys
H=Path('/workspace/profile8004');v=sys.argv[1];source=H/'source';a=[json.loads(l) for l in (H/f'logs/build-{v}.jsonl').read_text().splitlines() if l.startswith('{')];assert a[-1]=={'reason':'build-finished','success':True};art=[r for r in a if r.get('reason')=='compiler-artifact' and r['target']['name']=='ripr' and r.get('executable')];assert len(art)==1
p=Path(art[0]['executable']);dest=H/'bin'/v;assert not dest.exists();shutil.copy2(p,dest)
def git(*args):return subprocess.check_output(['git',*args],cwd=source,text=True).strip()
assert not git('status','--porcelain')
version=subprocess.check_output([str(dest),'--version'],text=True).strip();sha=hashlib.sha256(dest.read_bytes()).hexdigest();rows=[r for r in a if r.get('reason')=='build-script-executed' and 'ripr#' in r['package_id']];stamp=[dict(r['env']) for r in rows];assert any(d.get('RIPR_BUILD_COMMIT')==git('rev-parse','HEAD') and d.get('RIPR_BUILD_COMMIT_DIRTY')=='false' for d in stamp),(stamp,version)
(H/f'logs/binary-{v}.json').write_text(json.dumps(dict(source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),version=version,sha256=sha,bytes=dest.stat().st_size,artifact=art[0],stamp=stamp),indent=2));print(v,sha,version)
