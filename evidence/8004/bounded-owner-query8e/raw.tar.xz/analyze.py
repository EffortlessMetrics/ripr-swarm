from pathlib import Path
import json,csv,collections,hashlib
H=Path('/workspace/profile8004');O=H/'outputs';rows=json.loads((O/'runs.json').read_text());assert len(rows)==13 and all(r['exit']==0 and r['complete_retained_output_equal'] for r in rows)
for r in rows:
 if r['instrumented']:
  d={x['kind']:dict(calls=int(x['calls']),inclusive_s=int(x['inclusive_ns'])/1e9) for x in r['spans']};r['aggregate']=d
  if r['phase']=='warm':assert not d,(r['id'],d)
for n in [16,64]:
 for kind in ['single','split']:
  r=next(r for r in rows if r['id']==f'sync-{n}-{kind}-profile-cold');d=r['aggregate'];assert d['executable_query']['calls']==d['helper_query']['calls']+d['inherent_query']['calls'];print(r['id'],{k:d.get(k) for k in ['executable_query','helper_query','inherent_query','same_file_helper_binding','macro_binding','owner_assertions_build','shadow_miss','shadow_mask','fragment_miss','outer_ast_visits']})
card=next(r for r in rows if r['pairs']);groups=collections.defaultdict(list)
for line in (O/(card['id']+'.pairs')).read_text().splitlines():
 count,key=line.split('\t',1);groups[key[0]].append(int(count))
card['pair_groups']={k:dict(unique=len(v),total=sum(v),repeat_queries=sum(n-1 for n in v),max_reuse=max(v)) for k,v in groups.items()};print('CARDINALITY',card['pair_groups'])
# Explicitly challenge the full lexical output, in addition to complete parity.
for variant in ['clean','profile']:
 d=json.loads((O/f'anchor-{variant}-cold.json').read_text());positive=sum(row['line']==10 and row['relation_reason']=='direct_owner_call' and row['relation_confidence']=='high' for seam in d['seams'] for row in seam['related_tests'])
 negative=sum(row['line']==15 and row['relation_reason'] in ['direct_owner_call','helper_owner_call'] for seam in d['seams'] for row in seam['related_tests'])
 assert len(d['seams'])==4 and positive==4 and negative==0
 print('ANCHOR',variant,'4positive direct/high,0negative direct/helper')
(H/'logs/analysis.json').write_text(json.dumps(dict(runs=rows,pair_groups=card['pair_groups'],limits=['n=1 profiling samples, instrument overhead; no speedup claim','inclusive nested spans overlap; not wall percentages','fixed immutable per-process index, pair identity is not cross-source cache-key proof']),indent=2))
