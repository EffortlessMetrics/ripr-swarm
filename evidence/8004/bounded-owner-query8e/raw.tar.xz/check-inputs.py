from pathlib import Path
import json,hashlib,subprocess
H=Path('/workspace/profile8004');rows=[]
for n in [16,64]:
 single=H/f'author/workloads/sync-{n}-single/src/lib.rs';split=H/f'author/workloads/sync-{n}-split/src';parts=[split/f'file_{i}.rs' for i in range(n)]
 assert b''.join(p.read_bytes() for p in parts)==single.read_bytes()
 rows.append(dict(units=n,ordered_split_bytes_equal_single=True,total_bytes=single.stat().st_size,single_sha256=hashlib.sha256(single.read_bytes()).hexdigest(),split_members=[dict(path=str(p.relative_to(H)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in parts]))
(H/'logs/input-controls.json').write_text(json.dumps(rows,indent=2));print('PASS: ordered split module bytes identical to single for16/64')
