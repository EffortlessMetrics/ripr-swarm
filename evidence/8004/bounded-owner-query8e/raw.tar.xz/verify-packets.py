from pathlib import Path
import subprocess,json,hashlib,stat
H=Path('/workspace/profile8004');repo='/workspace/ripr-swarm'
summary=[]
for ref,remote,local in [('f975e98e2eecc4126c1aaca9846e934975e2266c','independent-shadow8e','retained'),('31c295d2f05eb3cb89e4b5cd8191d33f86267df8','shadow-syntax-repair','author')]:
 p=H/local;pub=H/(local+'-public');pub.mkdir(exist_ok=True)
 files=['MANIFEST.json','README.md','SHA256SUMS','receipt.json']+(['PROTOCOL.md'] if local=='author' else [])
 for name in files:(pub/name).write_bytes(subprocess.check_output(['git','show',f'{ref}:evidence/8004/{remote}/{name}'],cwd=repo))
 (pub/'raw.tar.xz').write_bytes((H/('author.raw.tar.xz' if local=='author' else 'independent.raw.tar.xz')).read_bytes())
 for line in (pub/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split();assert hashlib.sha256((pub/name).read_bytes()).hexdigest()==digest,name
 m=json.loads((pub/'MANIFEST.json').read_text());members=m['members'];print(local,members[0])
 expected=set()
 for x in members:
  path=x['path'];f=p/path;b=f.read_bytes();expected.add(path)
  assert hashlib.sha256(b).hexdigest()==x['sha256'],path
  size=x.get('bytes',x.get('size'));assert len(b)==size,(path,size)
  mode=x.get('mode');assert mode is None or stat.S_IMODE(f.stat().st_mode)==(mode if isinstance(mode,int) else int(mode,8)),(path,mode)
 actual={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()};assert actual==expected,(len(actual),len(expected))
 summary.append({'ref':ref,'packet':remote,'members':len(members),'checksums':'all pass','member_bytes_sizes_modes_inventory':'pass'})
(H/'logs/packet-verification.json').write_text(json.dumps(summary,indent=2))
