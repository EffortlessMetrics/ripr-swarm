from pathlib import Path
R=Path('/workspace/profile8004/source/crates/ripr/src')
(R/'owner_profile.rs').write_text('''use std::{collections::BTreeMap, sync::{Mutex,OnceLock},time::Instant};
type Times=BTreeMap<&'static str,(u64,u128)>;
static TIMES:OnceLock<Mutex<Times>>=OnceLock::new();
static PAIRS:OnceLock<Mutex<BTreeMap<String,u64>>>=OnceLock::new();
pub struct Span(&'static str,Instant);
impl Span { pub fn new(kind:&'static str)->Self {Self(kind,Instant::now())} }
impl Drop for Span {fn drop(&mut self){let ns=self.1.elapsed().as_nanos();let mut d=TIMES.get_or_init(Mutex::default).lock().unwrap();let x=d.entry(self.0).or_default();x.0+=1;x.1+=ns;}}
pub fn count(kind:&'static str,n:u64){let mut d=TIMES.get_or_init(Mutex::default).lock().unwrap();d.entry(kind).or_default().0+=n;}
pub fn pair(key:String){if std::env::var_os("OWNER_PROFILE_PAIRS").is_some(){*PAIRS.get_or_init(Mutex::default).lock().unwrap().entry(key).or_default()+=1;}}
pub fn dump(){if let Some(path)=std::env::var_os("OWNER_PROFILE_OUT"){let mut out=String::from("kind\\tcalls\\tinclusive_ns\\n");if let Some(d)=TIMES.get(){for (k,(n,ns)) in d.lock().unwrap().iter(){out.push_str(&format!("{k}\\t{n}\\t{ns}\\n"));}}std::fs::write(&path,out).unwrap();if let Some(d)=PAIRS.get(){let out=d.lock().unwrap().iter().map(|(k,n)|format!("{n}\\t{k}\\n")).collect::<String>();std::fs::write(std::path::Path::new(&path).with_extension("pairs"),out).unwrap();}}}
''')
p=R/'lib.rs';p.write_text(p.read_text()+'\n#[doc(hidden)]\npub mod owner_profile;\n')
p=R/'main.rs';s=p.read_text();a='    run_startup(startup::run);';assert s.count(a)==1;p.write_text(s.replace(a,a+'\n    ripr::owner_profile::dump();'))
def entry(path,fn,kind):
 p=R/path;s=p.read_text();start=s.index('fn '+fn+'(');pos=s.index('{',start)+1;s=s[:pos]+f'\n    let _owner_profile = crate::owner_profile::Span::new("{kind}");'+s[pos:];p.write_text(s)
for fn,kind in [('inherent_receiver_call_resolves','inherent_query'),('free_helper_call_resolves','helper_query'),('executable_call_resolves','executable_query'),('assertion_arguments_resolve','operand_query'),('scoped_receiver_names_type','receiver_scope')]:entry('analysis/classify/related_tests.rs',fn,kind)
for fn,kind in [('test_module_shadows_item','shadow_query'),('same_file_free_helper_call_reaches_owner','same_file_helper_binding'),('targeted_macro_binding_is_unambiguous','macro_binding'),('trusted_macro_ambiguities','macro_ambiguities'),('targeted_source_provenance_is_admitted','source_provenance')]:entry('analysis/classify/owner_pin.rs',fn,kind)
entry('analysis/syntax/owner_pin.rs','owner_pin_assertions','owner_assertions_build')
entry('analysis/syntax/source_snapshot.rs','parse_fragment','fragment_query')
p=R/'analysis/syntax/source_snapshot.rs';s=p.read_text();a='                let parse = parse_clean_source_file(text);';assert s.count(a)==1;s=s.replace(a,'                let _miss = crate::owner_profile::Span::new("fragment_miss");\n'+a);p.write_text(s)
p=R/'analysis/classify/owner_pin.rs';s=p.read_text();a='    snapshot.shadow_answer(key, || {';assert s.count(a)==1;s=s.replace(a,a+'\n        let _miss = crate::owner_profile::Span::new("shadow_miss");');a='        let masked = mask_comments_and_strings(source);';pos=s.index(a,s.index('fn test_module_shadows_item'));s=s[:pos]+s[pos:].replace(a,'        let masked = { let _span=crate::owner_profile::Span::new("shadow_mask"); mask_comments_and_strings(source) };',1);p.write_text(s)
p=R/'analysis/classify/related_tests.rs';s=p.read_text()
# Separate true owner query and helper query, binding each to complete caller/target request.
for fn,arg in [('inherent_receiver_call_resolves','format!("I|{:?}|{}|{}|{}|{:?}|{}|{}",test.file,test.name,test.start_line,test.end_line,test.body,method,impl_type)'),('free_helper_call_resolves','format!("H|{:?}|{}|{}|{}|{:?}|{:?}|{}|{}|{}|{}",caller.file,caller.name,caller.start_line,caller.end_line,caller.body,helper.file,helper.id,helper.name,helper.start_line,helper.end_line)')]:
 start=s.index('fn '+fn+'(');pos=s.index('{',start)+1;s=s[:pos]+'\n    if std::env::var_os("OWNER_PROFILE_PAIRS").is_some() { crate::owner_profile::pair('+arg+'); }'+s[pos:]
# Count visits locally, flush once per query to avoid a mutex on every AST node.
a='    let executable = |node: &SyntaxNode| node_executes_in(node, function.syntax());';assert s.count(a)==1
s=s.replace(a,'''    struct Visits(std::cell::Cell<u64>);
    impl Drop for Visits { fn drop(&mut self) {crate::owner_profile::count("outer_ast_visits",self.0.get());} }
    let visits=Visits(std::cell::Cell::new(0));
    let executable = |node: &SyntaxNode| { visits.0.set(visits.0.get()+1); node_executes_in(node, function.syntax()) };''')
# Count successful name matches before lexical helper authority.
a='        let prefix = path.qualifier().map(|path| {';start=s.index('fn free_helper_call_resolves(');pos=s.index(a,start);s=s[:pos]+'        crate::owner_profile::count("helper_name_match",1);\n'+s[pos:]
p.write_text(s)
