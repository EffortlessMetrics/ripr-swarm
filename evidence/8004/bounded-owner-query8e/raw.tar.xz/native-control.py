from pathlib import Path
import subprocess,json,hashlib
H=Path('/workspace/profile8004');rows=[]
rustc='/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc'
for v in ['original','mutant']:
 src=H/'retained/anchor-native'/(v+'.rs');binary=H/'bin'/('anchor-'+v)
 a=[rustc,'--edition=2024','--test',str(src),'-o',str(binary)];p=subprocess.run(a,capture_output=True);(H/'logs'/('native-'+v+'-compile.stderr')).write_bytes(p.stderr);assert p.returncode==0
 for test in ['positive::subject','negative::subject']:
  a=[str(binary),'--exact',test,'--nocapture'];p=subprocess.run(a,capture_output=True,timeout=10);(H/'logs'/('native-'+v+'-'+test+'.log')).write_bytes(p.stdout+p.stderr)
  expected=101 if (v,test)==('mutant','positive::subject') else 0;assert p.returncode==expected;assert b"running 1 test" in p.stdout
  rows.append(dict(argv=a,exit=p.returncode,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),one_named_test=True))
(H/'logs/native-controls.json').write_text(json.dumps(rows,indent=2));print('PASS: native lexical twins, positive mutant killed, shadowed twin survives')
