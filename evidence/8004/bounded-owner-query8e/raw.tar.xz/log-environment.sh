#!/bin/bash
set -eu
source /workspace/profile8004/env.sh
printf 'PATH=%s\n' "$PATH"
command -v rustc cargo cc
rustc -Vv
cargo -V
uname -a
cat /sys/fs/cgroup/cpu.max /sys/fs/cgroup/memory.max
df -B1 /workspace
printf 'int main(void){return 0;}\n' > /workspace/profile8004/link.c
cc /workspace/profile8004/link.c -o /workspace/profile8004/link
/workspace/profile8004/link
