from pathlib import Path
import json,hashlib,tarfile,shutil,stat,datetime,subprocess
H=Path('/workspace/profile8004');P=H/'packet';P.mkdir(exist_ok=True);staging=H/'packet-raw-v2';assert not staging.exists();staging.mkdir()
files=[*H.glob('*.py'),H/'env.sh',H/'log-environment.sh',H/'ADMISSION.md',H/'PROTOCOL.md',H/'instrumentation.patch']
for d in ['logs','outputs']:files.extend(p for p in (H/d).rglob('*') if p.is_file())
# Keep only claim-essential restored inputs, not the old matrix or caches.
for n in [16,64]:
 for layout in ['single','split']:
  root=H/f'author/workloads/sync-{n}-{layout}';files.extend(p for p in root.rglob('*') if p.is_file() and (p.name in ['Cargo.toml','Cargo.lock'] or p.suffix=='.rs'))
for root in [H/'retained/anchor-control',H/'retained/anchor-native']:
 files.extend(p for p in root.rglob('*') if p.is_file() and (p.name in ['Cargo.toml','Cargo.lock'] or p.suffix=='.rs'))
for p in files:
 target=staging/p.relative_to(H);target.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,target)
members=[]
for p in sorted(staging.rglob('*')):
 if p.is_file():members.append(dict(path=str(p.relative_to(staging)),bytes=p.stat().st_size,mode=stat.S_IMODE(p.stat().st_mode),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(P/'MANIFEST.json').write_text(json.dumps(dict(members=members,timestamp_policy='archive mtime/uid/gid normalized; no fine timestamp claim',excluded=['compiler executables and mutable Cargo/cache trees; exact product executable metadata retained','old matrix reports, already pinned by original packets']),indent=2)+'\n')
with tarfile.open(P/'raw.tar.xz','w:xz',preset=6) as t:
 for m in members:
  f=staging/m['path'];i=t.gettarinfo(str(f),arcname=m['path']);i.mtime=0;i.uid=i.gid=0;i.uname=i.gname='';
  with f.open('rb') as r:t.addfile(i,r)
for name in ['README.md','PROTOCOL.md','receipt.json']:shutil.copy2(H/name,P/name)
(P/'SHA256SUMS').write_text(''.join(hashlib.sha256((P/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in ['MANIFEST.json','README.md','PROTOCOL.md','receipt.json','raw.tar.xz']))
print('packet',len(members),'members',sum(x['bytes'] for x in members),'raw bytes', (P/'raw.tar.xz').stat().st_size,'compressed')
