from pathlib import Path
import os,subprocess,json,hashlib,tarfile,stat
H=Path('/workspace/profile8004');P=H/'packet';repo='/workspace/ripr-swarm';prefix='evidence/8004/bounded-owner-query8e';parent='f975e98e2eecc4126c1aaca9846e934975e2266c';branch='evidence/8004/bounded-owner-query8e-20261016'
env=os.environ.copy();env['GIT_INDEX_FILE']=str(H/'publication.index')
def git(*args,input=None,env_=None,cwd=repo):return subprocess.check_output(['git',*args],input=input,cwd=cwd,env=env_,text=True).strip()
assert not git('ls-remote','origin','refs/heads/'+branch)
assert git('ls-remote','origin','refs/heads/rook/7415-private-target-attribution').split()[0]=='36dbb87430ef858aa143b5fc3205b376b0caee11'
git('read-tree',parent,env_=env)
for p in sorted(P.iterdir()):
 if p.is_file():
  blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo','100644',blob,prefix+'/'+p.name,env_=env)
tree=git('write-tree',env_=env);commit=git('commit-tree',tree,'-p',parent,input='evidence: bounded exact8e owner-query profile and next target\n')
delta=git('diff-tree','--no-commit-id','--name-only','-r',commit).splitlines();assert len(delta)==6 and all(p.startswith(prefix+'/') for p in delta),delta
(H/'logs/publication-prepush.json').write_text(json.dumps(dict(commit=commit,tree=tree,parent=parent,branch=branch,paths=delta),indent=2))
# Single authorized evidence-only publication, no submitted-candidate ref update.
p=subprocess.run(['git','push','origin',commit+':refs/heads/'+branch],cwd=repo,capture_output=True,text=True);(H/'logs/publication-push.txt').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
consumer=H/'readback.git';git('init','--bare',str(consumer));git('fetch','--depth=1','https://github.com/EffortlessMetrics/ripr-swarm.git','refs/heads/'+branch,cwd=consumer);assert git('rev-parse','FETCH_HEAD',cwd=consumer)==commit
R=H/'readback';R.mkdir();digests=[]
for p in sorted(P.iterdir()):
 b=subprocess.check_output(['git','show',commit+':'+prefix+'/'+p.name],cwd=consumer);assert b==p.read_bytes();(R/p.name).write_bytes(b);digests.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
for line in (R/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split();assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
restored=H/'readback-restored';restored.mkdir()
with tarfile.open(R/'raw.tar.xz','r:xz') as t:t.extractall(restored,filter='data')
m=json.loads((R/'MANIFEST.json').read_text())['members'];assert {str(p.relative_to(restored)) for p in restored.rglob('*') if p.is_file()}=={x['path'] for x in m}
for x in m:
 p=restored/x['path'];b=p.read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'] and stat.S_IMODE(p.stat().st_mode)==x['mode'],x['path']
assert git('ls-remote','origin','refs/heads/rook/7415-private-target-attribution').split()[0]=='36dbb87430ef858aa143b5fc3205b376b0caee11'
receipt=dict(commit=commit,tree=tree,parent=parent,branch=branch,url='https://github.com/EffortlessMetrics/ripr-swarm/tree/'+commit+'/'+prefix,evidence_only_paths=delta,files=digests,restored_members=len(m),all_member_bytes_sizes_modes_inventory_verified=True,candidate_ref_unchanged_during_publication=True,consumer='fresh separate bare Git repository and separate archive restoration')
(H/'publication-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
# Preserve the independently fetched/restored readback beside the immutable packet.
sibling='evidence/8004/bounded-owner-query8e-publication-readback.json';git('read-tree',commit,env_=env);blob=git('hash-object','-w',str(H/'publication-readback.json'));git('update-index','--add','--cacheinfo','100644',blob,sibling,env_=env);rtree=git('write-tree',env_=env);rcommit=git('commit-tree',rtree,'-p',commit,input='evidence: retain independent network readback for owner-query packet\n')
assert git('diff-tree','--no-commit-id','--name-only','-r',rcommit)==sibling
p=subprocess.run(['git','push','origin',rcommit+':refs/heads/'+branch],cwd=repo,capture_output=True,text=True);(H/'logs/readback-push.txt').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
git('fetch','--depth=1','https://github.com/EffortlessMetrics/ripr-swarm.git','refs/heads/'+branch,cwd=consumer);assert git('rev-parse','FETCH_HEAD',cwd=consumer)==rcommit
b=subprocess.check_output(['git','show',rcommit+':'+sibling],cwd=consumer);assert b==(H/'publication-readback.json').read_bytes()
(H/'publication-final.json').write_text(json.dumps(dict(packet_commit=commit,readback_commit=rcommit,packet_url=receipt['url'],readback_url='https://github.com/EffortlessMetrics/ripr-swarm/blob/'+rcommit+'/'+sibling,sibling_readback_equal=True,candidate_ref_unchanged_during_publication=git('ls-remote','origin','refs/heads/rook/7415-private-target-attribution').split()[0]=='36dbb87430ef858aa143b5fc3205b376b0caee11'),indent=2));print((H/'publication-final.json').read_text())
