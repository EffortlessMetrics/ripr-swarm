import os,subprocess,json,time,pathlib,shutil
root=pathlib.Path('/workspace/golden8004-evidence');env=os.environ.copy();env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_TARGET_DIR='/workspace/review36db-target',CARGO_BUILD_JOBS='4',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',RAYON_NUM_THREADS='4')
rows=json.loads((root/"baseline.json").read_text())
for i,args in enumerate([['goldens','check'],['check-fast']],start=1):
 cmd=['cargo','run','--locked','-p','xtask','--',*args];start=time.time();print('START',i,cmd,flush=True)
 with open(root/'raw'/f'baseline-{i}.log','w') as f:p=subprocess.run(cmd,cwd='/workspace/review36db',env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(argv=cmd,exit=p.returncode,elapsed_seconds=time.time()-start,log=f'baseline-{i}.log'));(root/'baseline.json').write_text(json.dumps(rows,indent=2));print('END',i,p.returncode,flush=True)
 reports=pathlib.Path('/workspace/review36db/target/ripr/reports');dest=root/'raw'/f'baseline-reports-{i}';dest.mkdir(exist_ok=True)
 if reports.exists():
  for n in ['worktree-doctor.md','goldens.md','golden-drift.md','check-fast.md','check-fast-selector.md']:
   if (reports/n).exists():shutil.copyfile(reports/n,dest/n)
 if p.returncode and i!=1:break
