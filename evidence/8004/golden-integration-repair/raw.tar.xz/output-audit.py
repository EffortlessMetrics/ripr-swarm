import pathlib,json,re,hashlib,shutil,subprocess as s
work=pathlib.Path('/workspace/review36db');raw=pathlib.Path('/workspace/golden8004-evidence/raw');report=(work/'target/ripr/reports/goldens.md').read_text();rows=re.findall(r'^- `([^`]+)` `(check\.json|human\.txt|human-full\.txt)`: (\w+)$',report,re.M);assert len(rows)==1157 and all(status=='pass' for _,_,status in rows);assert len({f for f,_,_ in rows})==465
base=json.loads((raw/'pre-edit-audit.json').read_text());jsons=[]
for row in base['compared_json_files']:
 rel=pathlib.Path(row['path']);p=work/'target/ripr/fixtures'/rel.parts[1]/rel.name;expected=(work/rel).read_bytes();actual=p.read_bytes();assert hashlib.sha256(expected).hexdigest()==row['expected_sha256'];assert json.loads(expected)==json.loads(actual);assert expected.decode().replace('\r\n','\n').rstrip('\n')==actual.decode().replace('\r\n','\n').rstrip('\n');jsons.append(dict(path=row['path'],expected_sha256=hashlib.sha256(expected).hexdigest(),actual_sha256=hashlib.sha256(actual).hexdigest()))
for f in sorted({r['path'].split('/')[1] for r in base['changed_files']}):
 d=raw/'after'/f;d.mkdir(parents=True,exist_ok=True)
 for n in ['check.json','human.txt','human-full.txt']:
  p=work/'target/ripr/fixtures'/f/n
  if p.exists():shutil.copyfile(p,d/('actual-'+n))
result=dict(head=s.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),fixtures=465,golden_comparisons=1157,golden_comparisons_passed=1157,json_comparisons=465,all_json_semantics_and_normalized_bytes_equal_to_original=True,comparison_scope='Complete stored golden JSON after unchanged repository normalizer; canonical_next_action is omitted by that established normalizer. Separate raw affected-fixture controls retain and check its stop case.',json_hashes=jsons,honesty_gate_report=(work/'target/ripr/reports/evidence-promotion-honesty.md').read_text())
(raw/'output-parity.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k not in ['json_hashes','honesty_gate_report']})
