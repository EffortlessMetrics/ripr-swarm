import json,pathlib,hashlib,subprocess as s,re
work=pathlib.Path('/workspace/review36db');root=pathlib.Path('/workspace/golden8004-evidence');audit=json.loads((root/'raw/pre-edit-audit.json').read_text())
assert s.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip()=='36dbb87430ef858aa143b5fc3205b376b0caee11'
assert s.check_output(['git','status','--porcelain'],cwd=work)==b''
assert audit['semantic_drift'] is False and audit['json_files_compared']==465 and audit['changed_file_count']==15 and audit['removed_terminal_stops']==60
fixtures={}
for row in audit['changed_files']:
 rel=pathlib.Path(row['path']);p=work/rel;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['before_sha256']
 actual=(work/'target/ripr/fixtures'/rel.parts[1]/rel.name).read_bytes();assert hashlib.sha256(actual).hexdigest()==row['actual_sha256']
 lines=b.splitlines(keepends=True)
 for change in row['changes']:
  i=change['line']-1;old=lines[i];body=old.rstrip(b'\r\n');ending=old[len(body):];assert body.decode()==change['old'] and body.endswith(b'.') and not body.endswith(b'..');lines[i]=body[:-1]+ending;assert lines[i].rstrip(b'\r\n').decode()==change['new']
 p.write_bytes(b''.join(lines));assert p.read_bytes().decode()==actual.decode()
 fixtures.setdefault(rel.parts[1],[]).append((rel.name,len(row['changes'])))
for fixture,files in fixtures.items():
 p=work/'fixtures'/fixture/'expected/CHANGELOG.md';old=p.read_text();nums=[int(n) for n in re.findall(r'^## Pending .*\((\d+)\)$',old,re.M)];n=max(nums,default=0)+1
 reason=('RIPR-SPEC-0002 / #7756 / #8004 integration: adopt the labelled-field and list-item terminal-period rule landed in fdcb75cf3f9acc928967d8ab4764d0caf8dbb31b (#8096). '
 'Only the independently audited terminal periods are removed; classifications, counts, evidence, recommendations, JSON, native truth labels and corpus claims are unchanged.')
 entry=f'\n## Pending — {fixture} ({n})\n\nReason:\n{reason}\n\nVerification:\n`cargo xtask goldens check` after an audited line-only adjustment.\n\nUpdated:\n'+''.join(f'- `expected/{name}` ({count} terminal periods)\n' for name,count in files)
 p.write_text(old+entry)
(root/'raw/adjustment.json').write_text(json.dumps(dict(human_files=15,removed_terminal_periods=60,fixture_changelogs=len(fixtures),json_changes=0,product_changes=0,fixtures=fixtures),indent=2)+'\n')
