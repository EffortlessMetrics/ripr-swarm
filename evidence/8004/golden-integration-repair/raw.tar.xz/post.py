import os,subprocess,json,time,pathlib,shutil
root=pathlib.Path('/workspace/golden8004-evidence');work=pathlib.Path('/workspace/review36db');env=os.environ.copy();env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_TARGET_DIR='/workspace/review36db-target',CARGO_BUILD_JOBS='4',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',RAYON_NUM_THREADS='4')
xtask=lambda *args:['cargo','run','--locked','-p','xtask','--',*args]
cmds=[xtask('goldens','check'),xtask('fixtures'),xtask('check-evidence-promotion-honesty'),xtask('check-fast'),['cargo','test','--locked','-p','ripr','--lib','trim_field_period_tests'],['cargo','test','--locked','-p','ripr','--test','private_inherent_receiver'],['cargo','test','--locked','-p','xtask','--bin','xtask','evidence_promotion_semantic_assertions_reject_missing_human'],xtask('precommit')]
rows=[]
for i,cmd in enumerate(cmds):
 start=time.time();print('START',i,cmd,flush=True)
 with open(root/'raw'/f'post-{i}.log','w') as f:p=subprocess.run(cmd,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(argv=cmd,exit=p.returncode,elapsed_seconds=time.time()-start,log=f'post-{i}.log',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip()));(root/'post.json').write_text(json.dumps(rows,indent=2));print('END',i,p.returncode,flush=True)
 reports=work/'target/ripr/reports';dest=root/'raw'/f'post-reports-{i}';dest.mkdir(exist_ok=True)
 for n in ['goldens.md','golden-drift.md','fixtures.md','evidence-promotion-honesty.md','evidence-promotion-honesty.json','check-fast.md','check-fast-selector.md','precommit.md','precommit.json','precommit-clippy.md']:
  if (reports/n).exists():shutil.copyfile(reports/n,dest/n)
 if p.returncode:break
