import pathlib,subprocess as s,json,hashlib
work=pathlib.Path('/workspace/review36db');raw=pathlib.Path('/workspace/golden8004-evidence/raw');audit=json.loads((raw/'pre-edit-audit.json').read_text())
def git(*a):return s.check_output(['git',*a],cwd=work)
def inventory(ref):
 rows={}
 for row in git('ls-tree','-r',ref).decode().splitlines():
  meta,path=row.split('\t',1);rows[path]=meta
 return rows
old=inventory('36dbb8743');new=inventory('HEAD');assert old.keys()==new.keys()
changed={p for p in old if old[p]!=new[p]};expected={r['path'] for r in audit['changed_files']};fixtures={p.split('/')[1] for p in expected};logs={f'fixtures/{f}/expected/CHANGELOG.md' for f in fixtures};assert changed==expected|logs and len(changed)==26
for row in audit['changed_files']:
 before=git('show','36dbb8743:'+row['path']);after=(work/row['path']).read_bytes();lines=before.splitlines(keepends=True)
 for c in row['changes']:
  i=c['line']-1;body=lines[i].rstrip(b'\r\n');ending=lines[i][len(body):];assert body.decode()==c['old'];lines[i]=body[:-1]+ending
 assert b''.join(lines)==after
# Every other tracked blob, including every JSON, corpus, native source and production path, is identical.
protected_json=[p for p in old if p.endswith('.json')];assert all(old[p]==new[p] for p in protected_json)
corpus=git('rev-parse','HEAD:fixtures/evidence-promotion-honesty-corpus').decode().strip();assert corpus==git('rev-parse','36dbb8743:fixtures/evidence-promotion-honesty-corpus').decode().strip()
report=dict(head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),parent=git('show','-s','--format=%P','HEAD').decode().strip(),changed_files=sorted(changed),changed_human_files=len(expected),changed_fixture_changelogs=len(logs),removed_terminal_periods=60,total_tracked_paths=len(old),unchanged_other_tracked_blobs=len(old)-len(changed),unchanged_json_files=len(protected_json),corpus_tree=corpus,production_native_truth_corpus_json_unchanged=True,changelog_disposition='mechanical expectation sync exempt under docs/CHANGELOG_POLICY.md; inherited #7756 fragment retained; per-fixture explicit reasons added',rollback='revert this text-only commit; no production or truth-label change')
(raw/'candidate-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
