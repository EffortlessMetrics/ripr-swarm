import pathlib,json,subprocess as s,hashlib,tarfile,shutil,re,datetime
root=pathlib.Path('/workspace/golden8004-evidence');raw=root/'raw';work=pathlib.Path('/workspace/review36db');dest=pathlib.Path('/workspace/golden8004-publish/evidence/8004/golden-integration-repair');dest.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return s.check_output(['git',*a],cwd=work).decode().strip()
assert git('rev-parse','36dbb8743^{tree}')==git('rev-parse','4232b045^{tree}')
checks=json.loads((root/'post.json').read_text());assert len(checks)==8 and all(x['exit']==0 and x['head']=='5e34bad2a9d066387d72777f37d1134987c27698' for x in checks)
pre=json.loads((raw/'precommit-v2.json').read_text());assert pre['status']=='pass' and not pre['skipped'] and not pre['limitations'];assert len(pre['change_set']['changes'])==173
counts=[]
for i in [4,5,6]:
 log=(raw/f'post-{i}.log').read_text();m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',log);assert m and m[2]=='0' and m[3]=='0';counts.append(int(m[1]))
assert counts==[2,9,3]
p=raw/'environmental-diagnosis.json';j=json.loads(p.read_text());j.pop('source_or_lock_changes');j['fixture_input_or_lock_changes']=0;j['production_source_changes']=0;p.write_text(json.dumps(j,indent=2)+'\n')
identities=[]
for f in ['post-4.log','post-5.log','post-6.log']:
 log=(raw/f).read_text();paths=re.findall(r'\((/workspace/review36db-target/debug/deps/[^)]+)\)',log)
 for name in paths:
  p=pathlib.Path(name)
  if p.exists() and p.read_bytes()[:4]==b'\x7fELF':identities.append(dict(path=name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size))
p=pathlib.Path('/workspace/review36db-target/debug/ripr');identities.append(dict(path=str(p),sha256=sha(p.read_bytes()),bytes=p.stat().st_size));(raw/'executables.json').write_text(json.dumps(identities,indent=2)+'\n')
for p in root.glob('*.py'):shutil.copyfile(p,raw/p.name)
receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository='EffortlessMetrics/ripr-swarm',pr=8004,head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),parent=git('show','-s','--format=%P','HEAD'),canonical_branch='rook/7415-private-target-attribution',disposition='CANDIDATE_REPAIRED / FRESH_INDEPENDENT_REVIEW_REQUIRED',source_push='ordinary non-force36db→5e; remote readback verified',pr_state='open/Ready unchanged; no Ready/Draft action',adjustment={'human_files':15,'fixture_changelogs':11,'terminal_periods_removed':60,'json_files_changed':0,'production_native_corpus_changes':0},validation={'golden_fixtures':465,'golden_surfaces':1157,'goldens':'pass','fixtures':'pass','honesty_contract':'pass; does not clear accuracy costs','tests_passed':14,'test_counts':counts,'check_fast_gates':15,'selected_paths':173,'precommit':'pass; zero skips/limitations','raw_json_controls':11,'commands':checks},baseline_failures={'doctor':'behind-only7 commits; no restack','first_goldens':'15 presentation plus3 owner-fallible semantic surfaces from absent pinned anyhow100','hydrated_goldens':'15 presentation only, all465 JSON equal'},semantic_diagnosis=json.loads((raw/'environmental-diagnosis.json').read_text()),actual_new_merge={'sha':'740b6da9b2cc9fd402b9f588fe1c1f972d64745a','parents':['fabf21c8f8e5a06e61cb3e7c77c96f713dec8a13','5e34bad2a9d066387d72777f37d1134987c27698'],'tree':'778347a67ee2953192d7fd35ffcfde72175c7877','executed':False,'pr_base_metadata':'d08c77d144c016078364fcc1fcf2fa593d21cefc'},remaining=['fresh independent head/expectation and actual integration review','new required hosted qualification; no manual rerun or Ready action here','later-main combined tree unexecuted','old residual performance/censoring/unique-key-memory limits retained'],resources={'source_worktree':'/workspace/review36db retained for parent/reviewer','target':'/workspace/review36db-target retained exact-head binaries/log replay','raw':'/workspace/golden8004-evidence retained','publication_worktree':'remove after verified publication/readback','inherited_root':'/workspace/ripr-swarm untouched'})
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');shutil.copyfile(root/'README.md',dest/'README.md')
files=sorted(p for p in raw.rglob('*') if p.is_file());manifest={'members':[dict(path=p.relative_to(raw).as_posix(),bytes=p.stat().st_size,mode=0o644,sha256=sha(p.read_bytes())) for p in files]};(dest/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(dest/'raw.tar.xz','w:xz') as t:
 for p in files:
  info=t.gettarinfo(str(p),arcname=p.relative_to(raw).as_posix());info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  with p.open('rb') as f:t.addfile(info,f)
with tarfile.open(dest/'raw.tar.xz') as t:
 members=t.getmembers();assert len(members)==len(files)
 for m,x in zip(members,manifest['members']):
  b=t.extractfile(m).read();assert m.name==x['path'] and m.mode==x['mode'] and len(b)==x['bytes'] and sha(b)==x['sha256']
(dest/'SHA256SUMS').write_text(''.join(sha((dest/n).read_bytes())+'  '+n+'\n' for n in ['README.md','receipt.json','MANIFEST.json','raw.tar.xz']))
print(json.dumps(dict(members=len(files),archive_bytes=(dest/'raw.tar.xz').stat().st_size,archive_sha256=sha((dest/'raw.tar.xz').read_bytes()),head=receipt['head']),indent=2))
