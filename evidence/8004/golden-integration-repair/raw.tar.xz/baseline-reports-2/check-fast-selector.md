# check-fast selector

Status: pass
Base ref: origin/main
Selector: stable
Changed files: 173
Detail: selector and conditional gate receipt agree
