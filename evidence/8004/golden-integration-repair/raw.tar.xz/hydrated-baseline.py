import pathlib,subprocess as s,os,json,time,shutil
root=pathlib.Path('/workspace/golden8004-evidence');env=os.environ.copy();env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_TARGET_DIR='/workspace/review36db-target',CARGO_BUILD_JOBS='4',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',RAYON_NUM_THREADS='4')
cmd=['cargo','run','--locked','-p','xtask','--','goldens','check'];start=time.time()
with (root/'raw/hydrated-baseline.log').open('w') as f:r=s.run(cmd,cwd='/workspace/review36db',env=env,stdout=f,stderr=s.STDOUT)
(root/'raw/hydrated-baseline-command.json').write_text(json.dumps(dict(argv=cmd,exit=r.returncode,elapsed_seconds=time.time()-start),indent=2));print('goldens',r.returncode,flush=True)
for n in ['goldens.md','golden-drift.md']:shutil.copyfile(pathlib.Path('/workspace/review36db/target/ripr/reports')/n,root/'raw'/('hydrated-'+n))
with (root/'raw/pre-edit-audit.log').open('w') as f:a=s.run(['python3',str(root/'audit.py')],cwd='/workspace/review36db',stdout=f,stderr=s.STDOUT)
print('strict audit',a.returncode,flush=True);assert r.returncode==1 and a.returncode==0
