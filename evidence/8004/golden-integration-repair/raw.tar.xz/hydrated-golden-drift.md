# ripr golden drift report

Status: warn

This report summarizes expected-output drift for reviewer inspection. It never blesses goldens.

## Provenance

- binary: `/workspace/review36db-target/debug/ripr`
- ripr version: `ripr 0.11.0 (36dbb87430ef858aa143b5fc3205b376b0caee11)`
- revision: `36dbb87430ef858aa143b5fc3205b376b0caee11`

## Summary

- drift entries: 15
- fixture errors: 0

## Drift

### `inherent_receiver_async_function` `human.txt`

- expected: `fixtures/inherent_receiver_async_function/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_async_function/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_async_operand` `human.txt`

- expected: `fixtures/inherent_receiver_async_operand/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_async_operand/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_async_operand_helper` `human.txt`

- expected: `fixtures/inherent_receiver_async_operand_helper/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_async_operand_helper/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_dormant_body` `human.txt`

- expected: `fixtures/inherent_receiver_dormant_body/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_dormant_body/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_foreign_helper` `human.txt`

- expected: `fixtures/inherent_receiver_foreign_helper/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_foreign_helper/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_foreign_helper` `human-full.txt`

- expected: `fixtures/inherent_receiver_foreign_helper/expected/human-full.txt`
- actual: `target/ripr/fixtures/inherent_receiver_foreign_helper/human-full.txt`
- changed lines: 5
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_free_helper_identity` `human.txt`

- expected: `fixtures/inherent_receiver_free_helper_identity/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_free_helper_identity/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_helper_scope_shadow` `human.txt`

- expected: `fixtures/inherent_receiver_helper_scope_shadow/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_helper_scope_shadow/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_local_wrapper` `human.txt`

- expected: `fixtures/inherent_receiver_local_wrapper/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_local_wrapper/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_local_wrapper` `human-full.txt`

- expected: `fixtures/inherent_receiver_local_wrapper/expected/human-full.txt`
- actual: `target/ripr/fixtures/inherent_receiver_local_wrapper/human-full.txt`
- changed lines: 3
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_macro_discard` `human.txt`

- expected: `fixtures/inherent_receiver_macro_discard/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_macro_discard/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_macro_discard` `human-full.txt`

- expected: `fixtures/inherent_receiver_macro_discard/expected/human-full.txt`
- actual: `target/ripr/fixtures/inherent_receiver_macro_discard/human-full.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_module_type_shadow` `human.txt`

- expected: `fixtures/inherent_receiver_module_type_shadow/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_module_type_shadow/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_operand_item_shadow` `human.txt`

- expected: `fixtures/inherent_receiver_operand_item_shadow/expected/human.txt`
- actual: `target/ripr/fixtures/inherent_receiver_operand_item_shadow/human.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

### `inherent_receiver_operand_item_shadow` `human-full.txt`

- expected: `fixtures/inherent_receiver_operand_item_shadow/expected/human-full.txt`
- actual: `target/ripr/fixtures/inherent_receiver_operand_item_shadow/human-full.txt`
- changed lines: 4
- static-language boundary: pass
- blessing reason required: yes
- blessing reason present in PR: yes

## Fixture / Golden Violations

## Violations

```text
human.txt drift for fixture `inherent_receiver_async_function`
  expected: fixtures/inherent_receiver_async_function/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_async_function/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_async_operand`
  expected: fixtures/inherent_receiver_async_operand/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_async_operand/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_async_operand_helper`
  expected: fixtures/inherent_receiver_async_operand_helper/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_async_operand_helper/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_dormant_body`
  expected: fixtures/inherent_receiver_dormant_body/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_dormant_body/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_foreign_helper`
  expected: fixtures/inherent_receiver_foreign_helper/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_foreign_helper/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human-full.txt drift for fixture `inherent_receiver_foreign_helper`
  expected: fixtures/inherent_receiver_foreign_helper/expected/human-full.txt
  actual:   target/ripr/fixtures/inherent_receiver_foreign_helper/human-full.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_free_helper_identity`
  expected: fixtures/inherent_receiver_free_helper_identity/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_free_helper_identity/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_helper_scope_shadow`
  expected: fixtures/inherent_receiver_helper_scope_shadow/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_helper_scope_shadow/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_local_wrapper`
  expected: fixtures/inherent_receiver_local_wrapper/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_local_wrapper/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human-full.txt drift for fixture `inherent_receiver_local_wrapper`
  expected: fixtures/inherent_receiver_local_wrapper/expected/human-full.txt
  actual:   target/ripr/fixtures/inherent_receiver_local_wrapper/human-full.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_macro_discard`
  expected: fixtures/inherent_receiver_macro_discard/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_macro_discard/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human-full.txt drift for fixture `inherent_receiver_macro_discard`
  expected: fixtures/inherent_receiver_macro_discard/expected/human-full.txt
  actual:   target/ripr/fixtures/inherent_receiver_macro_discard/human-full.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_module_type_shadow`
  expected: fixtures/inherent_receiver_module_type_shadow/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_module_type_shadow/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human.txt drift for fixture `inherent_receiver_operand_item_shadow`
  expected: fixtures/inherent_receiver_operand_item_shadow/expected/human.txt
  actual:   target/ripr/fixtures/inherent_receiver_operand_item_shadow/human.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

```text
human-full.txt drift for fixture `inherent_receiver_operand_item_shadow`
  expected: fixtures/inherent_receiver_operand_item_shadow/expected/human-full.txt
  actual:   target/ripr/fixtures/inherent_receiver_operand_item_shadow/human-full.txt
  diff:    line 7 expected `Analysis outcome: findings below (analysis complete; complete_with_findings).` vs actual `Analysis outcome: findings below (analysis complete; complete_with_findings)`
```

