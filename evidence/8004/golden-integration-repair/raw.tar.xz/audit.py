import pathlib,json,subprocess as s,hashlib,difflib,shutil
work=pathlib.Path('/workspace/review36db');out=pathlib.Path('/workspace/golden8004-evidence/raw');rows=[];jsons=[]
def norm(b):return b.decode().replace('\r\n','\n').replace('\r','\n').rstrip('\n')+'\n'
def only_removed_stops(old,new):
 a=norm(old).splitlines();b=norm(new).splitlines()
 if len(a)!=len(b):return False
 return all(x==y or (x==y+'.' and not y.endswith('.')) for x,y in zip(a,b))
(out/'actual-differences.patch').write_text('')
files=s.check_output(['git','ls-files','fixtures'],cwd=work).decode().splitlines()
for name in files:
 p=pathlib.Path(name)
 if p.parent.name!='expected' or p.name not in ['check.json','human.txt','human-full.txt']:continue
 actual=work/'target/ripr/fixtures'/p.parts[1]/p.name
 assert actual.exists(),'MISSING ACTUAL SUBJECT: '+name
 before=(work/p).read_bytes();after=actual.read_bytes()
 if p.name=='check.json':
  assert json.loads(before)==json.loads(after),'SEMANTIC JSON DRIFT: '+name
  assert norm(before)==norm(after),'JSON BYTE DRIFT: '+name
  jsons.append(dict(path=name,expected_sha256=hashlib.sha256(before).hexdigest(),actual_sha256=hashlib.sha256(after).hexdigest(),json_equal=True,normalized_byte_equal=norm(before)==norm(after)));continue
 if norm(before)==norm(after):continue
 assert only_removed_stops(before,after),'NON-PUNCTUATION DRIFT: '+name
 a=norm(before).splitlines();b=norm(after).splitlines();changes=[dict(line=i+1,old=x,new=y) for i,(x,y) in enumerate(zip(a,b)) if x!=y]
 assert all(x==y for x,y in zip(a,b) if x.startswith('Summary:'))
 rows.append(dict(path=name,changes=changes,before_sha256=hashlib.sha256(before).hexdigest(),actual_sha256=hashlib.sha256(after).hexdigest()))
 (out/'actual-differences.patch').open('a').write(''.join(difflib.unified_diff(norm(before).splitlines(True),norm(after).splitlines(True),fromfile=name+' (committed)',tofile=name+' (actual36db)')))
for fixture in sorted({r['path'].split('/')[1] for r in rows}):
 dest=out/'before'/fixture;dest.mkdir(parents=True,exist_ok=True)
 for filename in ['check.json','human.txt','human-full.txt']:
  actual=work/'target/ripr/fixtures'/fixture/filename;expected=work/'fixtures'/fixture/'expected'/filename
  if actual.exists():shutil.copyfile(actual,dest/('actual-'+filename))
  if expected.exists():shutil.copyfile(expected,dest/('expected-'+filename))
# Independent rejection challenges: the audit must refuse semantic/token/denominator loss.
assert rows,'nonempty inherited drift required'
rel=pathlib.Path(rows[0]['path']);p=work/rel;actual=work/'target/ripr/fixtures'/rel.parts[1]/rel.name;old=p.read_bytes();new=actual.read_bytes();assert b'weakly_exposed' in new
negative=dict(classification_token=not only_removed_stops(old,new.replace(b'weakly_exposed',b'exposed',1)),probe_denominator=not only_removed_stops(old,new.replace(b'2 probe(s)',b'0 probe(s)',1)),empty_output=not only_removed_stops(old,b''))
assert all(negative.values())
example=json.loads((work/'fixtures'/rows[0]['path'].split('/')[1]/'expected/check.json').read_text());assert example['findings'];changed=json.loads(json.dumps(example));changed['findings'][0]['classification']='exposed';assert changed!=example;negative['json_classification']=True
report=dict(changed_files=rows,changed_file_count=len(rows),fixture_count=len({r['path'].split('/')[1] for r in rows}),removed_terminal_stops=sum(len(r['changes']) for r in rows),compared_json_files=jsons,json_files_compared=len(jsons),negative_challenges=negative,semantic_drift=False,renderer='fdcb75cf3f9acc928967d8ab4764d0caf8dbb31b / #8096/#7756',normalization='CRLF/CR -> LF and terminal newline only; complete JSON equality')
(out/'pre-edit-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['changed_files','compared_json_files']},indent=2));print((out/'actual-differences.patch').read_text())
