#[derive(Clone, Copy)]
pub(crate) enum JsonValue { Object(u32), Null }
impl JsonValue {
 pub(crate) fn as_object(&self) -> Option<u32> {
  match self { Self::Object(value) => None, _ => None }
 }
}
struct Foreign;
impl Foreign { fn as_object(&self) -> Option<u32> { Some(7) } }
#[cfg(test)] mod tests { use super::*;
#[test] fn subject() { let value=JsonValue::Object(7); fn dormant(){let value=Foreign; assert_eq!(value.as_object(),Some(7));} assert_eq!(value.as_object(),Some(7)); }
}
