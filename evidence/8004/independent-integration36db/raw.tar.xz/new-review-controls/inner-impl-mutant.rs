#[derive(Clone, Copy)]
pub(crate) enum JsonValue { Object(u32), Null }
impl JsonValue {
 pub(crate) fn as_object(&self) -> Option<u32> {
  match self { Self::Object(value) => None, _ => None }
 }
}
struct Foreign;
impl Foreign { fn as_object(&self) -> Option<u32> { Some(7) } }
#[cfg(test)] mod tests { use super::*;
#[test] fn subject() { let value=Foreign; struct Inner; impl Inner {fn dormant(){let value=JsonValue::Object(7); assert_eq!(value.as_object(),Some(7));}} assert_eq!(value.as_object(),Some(7)); }
}
