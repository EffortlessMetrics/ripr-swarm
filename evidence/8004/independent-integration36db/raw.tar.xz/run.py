import os,subprocess,json,time,pathlib
root=pathlib.Path('/workspace/review36db-evidence')
env=os.environ.copy();env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_TARGET_DIR='/workspace/review36db-target',CARGO_BUILD_JOBS='4',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
cmds=[['cargo','test','--locked','-p','ripr','--lib',x] for x in ['inherent','source_snapshot','module_shadow_snapshot']]+[['cargo','test','--locked','-p','ripr','--test',x] for x in ['private_inherent_receiver','cli_help_hierarchy','returned_element_field_pin']]+[['cargo','test','--locked','-p','xtask','--bin','xtask','create_zip_archive_writes_flat_package_contents'],['cargo','test','--locked','-p','xtask','--bin','xtask','strict_selector_inventory_rejects_non_utf8']]
records=[]
for i,cmd in enumerate(cmds):
 start=time.time(); print('START',i,cmd,flush=True)
 with open(root/'raw'/f'check-{i}.log','w') as f:
  p=subprocess.run(cmd,cwd='/workspace/review36db',env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(command=cmd,exit=p.returncode,elapsed=time.time()-start,log=f'check-{i}.log'))
 (root/'checks.json').write_text(json.dumps(records,indent=2));print('END',i,p.returncode,flush=True)
 if p.returncode:break
