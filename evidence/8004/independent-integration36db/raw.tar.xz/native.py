import subprocess as s,pathlib,json,hashlib,os
root=pathlib.Path('/workspace/review36db-evidence');out=root/'raw'/'native';out.mkdir(exist_ok=True)
rows=[]
for case,killed in [('entry',False),('named-sync-chain',True)]:
 p=pathlib.Path('/workspace/review36db/fixtures/inherent_receiver_async_function/controls')/(case+'.rs');src=p.read_text()
 for variant in ['original','mutant']:
  b=src if variant=='original' else src.replace('Self::Object(value) => Some(*value),','Self::Object(value) => None,');assert b!=src or variant=='original'
  path=out/(case+'-'+variant+'.rs');path.write_text(b);binary=path.with_suffix('')
  cmd=['/workspace/.cargo/bin/rustc','+1.95.0','--edition=2024','--test','--crate-name','control',str(path),'-o',str(binary)]
  env=os.environ.copy();env['RUSTUP_HOME']='/workspace/.rustup'
  c=s.run(cmd,env=env,capture_output=True);(path.with_suffix('.compile.log')).write_bytes(c.stdout+c.stderr);assert c.returncode==0
  run=s.run([str(binary)],capture_output=True);path.with_suffix('.run.log').write_bytes(run.stdout+run.stderr)
  expected=101 if variant=='mutant' and killed else 0;assert run.returncode==expected
  rows.append(dict(case=case,variant=variant,source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),compile_command=cmd,compile_exit=c.returncode,run_exit=run.returncode,expected=expected))
(root/'raw'/'native-results.json').write_text(json.dumps(rows,indent=2));print(rows)
