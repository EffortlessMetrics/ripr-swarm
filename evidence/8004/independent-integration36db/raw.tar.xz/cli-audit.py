import json,pathlib
root=pathlib.Path('/workspace/review36db-evidence/raw');rows=[]
for case,positive in [('entry',False),('named-sync-chain',True)]:
 f=json.loads((root/f'cli-{case}-repo-exposure-json.json').read_text());b=json.loads((root/f'cli-{case}-repo-badge-json.json').read_text())
 owner=[x for x in f['seams'] if x['owner']=='src/lib.rs::impl JsonValue::as_object'];assert len(owner)==4
 assert f['metrics']['seams_total']==b['counts']['analyzed_seams'];assert f['run_status']=='complete';assert b['analysis_complete'] is None
 for seam in owner:
  tests=seam['related_tests'];assert len(tests)==1 and tests[0]['name']=='subject'
  if positive:assert tests[0]['relation_reason']=='helper_owner_call' and tests[0]['relation_confidence']=='high' and seam['evidence']['reach']=='yes'
  else:assert tests[0]['relation_reason'] not in ['helper_owner_call','direct_owner_call'] and seam['evidence']['reach']!='yes'
 rows.append(dict(case=case,owner_seams=len(owner),relations=[s['related_tests'][0]['relation_reason'] for s in owner],full_and_badge_seam_count_equal=True,full_run_status=f["run_status"],badge_analysis_complete=b["analysis_complete"]))
(root/'cli-audit.json').write_text(json.dumps(rows,indent=2));print(rows)
