import subprocess as s,json,pathlib,hashlib,tarfile,re
root=pathlib.Path('/workspace/review36db-evidence'); raw=root/'raw'
def git(*a): return s.check_output(['git',*a],cwd='/workspace/review36db')
def sha(b):return hashlib.sha256(b).hexdigest()
packet='97ef1016514296079893d9df7168fae39949bb6d:evidence/8004/main-integration-maintenance/'
manifest=json.loads(git('show',packet+'MANIFEST.json')); verified=[]
with tarfile.open(raw/'author-maintenance.tar.xz') as t:
 members={m.name:m for m in t.getmembers() if m.isfile()}
 assert set(members)=={m['path'] for m in manifest['members']}
 for m in manifest['members']:
  b=t.extractfile(members[m['path']]).read();assert len(b)==m['bytes'] and sha(b)==m['sha256'] and members[m['path']].mode==m['mode'];verified.append(m['path'])
 counts=[]
 for i in range(6):
  b=t.extractfile(members[f'corrected-{i}.log']).read().decode(); counts.append(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',b));assert counts[-1]
old='8e0444b1a62ead18584d40b18278c6e8716dc56c';base='d08c77d144c016078364fcc1fcf2fa593d21cefc'; head=git('rev-parse','HEAD').decode().strip()
oldpaths=git('diff','--name-only','f2ba9522',old).splitlines(); paths=git('diff','--name-only',base,head).splitlines();assert oldpaths==paths and len(paths)==173
assert git('merge-tree','--write-tree',old,base).decode().strip()=='024d04e46de6ac531ca7485d9b7b6b4e7dafc2e4'
assert git('rev-parse','4232b04^{tree}')==git('rev-parse','HEAD^{tree}')
dep=['Cargo.lock','xtask/Cargo.toml','xtask/src/main.rs','xtask/src/reports/release_server.rs','xtask/src/tests.rs']
blobs={p:git('rev-parse',f'HEAD:{p}').decode().strip() for p in dep}
for p,v in blobs.items():assert git('rev-parse',f'{base}:{p}').decode().strip()==v
out=dict(head=head,tree=git('rev-parse','HEAD^{tree}').decode().strip(),parents=git('show','-s','--format=%P','HEAD').decode().strip().split(),clean_merge=True,pr_paths_preserved=len(paths),imported_paths=len(git('diff','--name-only',old,head).splitlines()),zip9_blobs_equal_base=blobs,author_packet_members_verified=len(verified),author_test_counts=counts,retained_test_sum=sum(int(c[0][0]) for c in counts),retained_archive_sha256=sha((raw/'author-maintenance.tar.xz').read_bytes()),owner_implementation_unchanged_paths=[p for p in ['crates/ripr/src/analysis/classify/related_tests.rs','crates/ripr/src/analysis/syntax/source_snapshot.rs','crates/ripr/src/analysis/test_grip_evidence/related_tests.rs','crates/ripr/src/analysis/test_grip_evidence/related_tests/context.rs'] if git('rev-parse',f'HEAD:{p}')==git('rev-parse',f'{old}:{p}')])
(raw/'integration-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
