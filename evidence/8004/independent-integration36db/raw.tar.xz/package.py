import pathlib,json,subprocess as s,hashlib,tarfile,datetime,shutil,os
root=pathlib.Path('/workspace/review36db-evidence');raw=root/'raw';dest=pathlib.Path('/workspace/review36db-publish/evidence/8004/independent-integration36db');dest.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
checks=json.loads((root/'checks.json').read_text());checks.append(dict(command=['cargo','test','--locked','-p','xtask','--bin','xtask','create_zip_archive_writes_flat_package_contents'],exit=0,log='check-8.log',native_status_observed=True))
for c in checks: assert c['exit']==0
counts=[]
import re
for i in range(9):
 text=(raw/f'check-{i}.log').read_text();match=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text);assert match;counts.append(int(match[1]));assert match[2]=='0' and match[3]=='0'
assert counts==[24,5,3,9,20,10,0,1,1]
(raw/'fresh-checks.json').write_text(json.dumps(dict(commands=checks,counts=counts,distinct_tests=73,excluded_zero_test_command=6),indent=2))
arts=[]
for p in list((raw/'native').iterdir())+list((raw/'new-review-controls').iterdir())+[pathlib.Path('/workspace/review36db-target/debug/ripr')]:
 if p.is_file() and p.read_bytes()[:4]==b'\x7fELF':arts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
(raw/'local-executable-identities.json').write_text(json.dumps(arts,indent=2))
for name in ['run.py','audit.py','native.py','cli.py','cli-audit.py','new-review-controls.py','package.py']:
 shutil.copyfile(root/name,raw/name)
# Freeze reviewed source/parents and patch, preserving main's whole imported inventory separately.
for name,args in [('commit-object.txt',['show','-s','--format=raw','HEAD']),('pr-delta.patch',['diff','d08c77d1','HEAD']),('imported-main.patch',['diff','8e0444b1','HEAD'])]:
 (raw/name).write_bytes(s.check_output(['git',*args],cwd='/workspace/review36db'))
receipt=dict(observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository='EffortlessMetrics/ripr-swarm',pr=8004,reviewed_head='36dbb87430ef858aa143b5fc3205b376b0caee11',basis='d08c77d144c016078364fcc1fcf2fa593d21cefc',tree='024d04e46de6ac531ca7485d9b7b6b4e7dafc2e4',actual_merge='4232b0459b58eb3283c9f9d1ee42faf690679446',disposition='REVIEW_INCOMPLETE for merge; independent pre-Ready technical review complete, no blocking source/oracle/integration finding',stale_material_subject_hold='cleared',local_distinct_tests=73,local_native_processes=12,local_cli_reports=8,zero_test_selection_misses=1,maintenance_archive_members_verified=25,final_checks={'total':25,'success':15,'skipped':10},threads={'returned':13,'unresolved':12,'changed':0,'pagination_metadata':'unexposed'},review_inventory=22,nonblocking_findings=['BOUNDARIES.md:3 says 34 entries; actual/test denominator 50; unbenchmarked wording stale'],remaining_merge_proof=['required hosted product qualification and actual product checkout','current required protections/convergence','broader platform/full-workspace/runtime qualification as applicable'],residuals=['frozen8e ~15.225s compact sync64 residual','per-query AST/owner work and unique-key memo storage','two censored predecessor samples/two dependent warms not run','no new-head benchmark/general no-regression/base98 equivalence'],resources={'review_worktree':'/workspace/review36db (remove after completed publication)','target':'/workspace/review36db-target retained for parent replay','inputs':'/workspace/review36db-inputs retained for parent replay','raw':'/workspace/review36db-evidence retained','inherited':'/workspace/ripr-swarm unchanged'},mutations=['evidence branch only','COMMENT review; no Ready/merge/thread resolution/source update'])
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');shutil.copyfile(root/'README.md',dest/'README.md')
files=[]
for p in sorted(raw.rglob('*')):
 if p.is_file() and p.read_bytes()[:4]!=b'\x7fELF':files.append(p)
manifest=dict(members=[dict(path=p.relative_to(raw).as_posix(),bytes=p.stat().st_size,mode=0o644,sha256=sha(p.read_bytes())) for p in files],excluded='ELF executables retained locally with separate identities')
(dest/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(dest/'raw.tar.xz','w:xz') as t:
 for p in files:
  info=t.gettarinfo(str(p),arcname=p.relative_to(raw).as_posix());info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  with p.open('rb') as f:t.addfile(info,f)
# Every archived member re-read against frozen manifest.
with tarfile.open(dest/'raw.tar.xz') as t:
 members=t.getmembers();assert len(members)==len(manifest['members'])
 for m,item in zip(members,manifest['members']):
  b=t.extractfile(m).read();assert m.name==item['path'] and len(b)==item['bytes'] and sha(b)==item['sha256'] and m.mode==item['mode']
(dest/'SHA256SUMS').write_text(''.join(sha((dest/n).read_bytes())+'  '+n+'\n' for n in ['README.md','receipt.json','MANIFEST.json','raw.tar.xz']))
print(json.dumps(dict(members=len(files),archive_bytes=(dest/'raw.tar.xz').stat().st_size,archive_sha256=sha((dest/'raw.tar.xz').read_bytes()),tests=counts),indent=2))
