# Current substantive concerns, exact 36db review

All 13 connector-returned threads were inspected (12 unresolved, one already resolved). No thread mutation. The connector does not expose a pagination/completeness token; the REST review/comment inventories separately returned 21 reviews and 15 issue comments with per_page=100. No claim that review-thread API metadata establishes exhaustive coverage beyond its returned set.

| Comment | Concern | Current technical disposition |
| --- | --- | --- |
| 4277308099 | Repeated receiver parsing | Partially addressed, residual retained. Caller/operand parse_fragment uses immutable exact-content cache; executable walks/current predicates remain. Prior independent review 5543295375 establishes material recovery, not zero overhead or all-workspace performance. |
| 4277766911 | Foreign helper last hop | Repaired in inherited reviewed code: inherent_helper_path_reaches_owner resolves entry and actual owner last hop; local/foreign paired controls in inherent_receiver_review_last_hop_and_wrapper_controls. |
| 4277767036 | Module assertion shadow | Repaired: targeted_macro_binding_is_unambiguous runs at original caller/line; module-macro negative/standard positive integration remains. |
| 4277767155 | Expired sibling shadow | Repaired: syntax/live-scope authority replaces textual deny gate; expired_foreign_shadow_cannot_hide_actual_outer_receiver integration. |
| 4277767243 | Same-name wrapper | Repaired for repository helper reach, explicitly conservative diff affinity; paired exact relation assertions and foreign-entry/last-hop controls. |
| 4281627330 | Overbroad wrapper changelog claim | Already resolved historically; changelog scopes helper reach to repository consumer. No new resolution action. |
| 4281627347 | Per-invocation OwnerPinSyntax | Partially addressed rather than literal requested run-scoped threading. Fresh defaults remain at related_tests.rs:3056/3078. Shared snapshot scopes/answers/fragments materially reduce repeated work; unit-struct/workspace-scan and unique-key-memory limits persist. Prior independent performance judgment permits bounded follow-up; no new benchmark/general clearance. |
| 4281736026 | Repository module-type shadow | Repaired: repository direct route calls complete inherent_owner_call_resolves authority; matrix retains module-local shadow/genuine owner cases. |
| 4281736034 | Dormant nested function | Repaired: node_executes_in excludes Item/Closure/async bodies; matrix includes dormant declaration and genuine outer positives. Invoked nested function remains conservatively unsupported. |
| 4281736044 | Explicit foreign helper entry | Repaired: free_helper_call_resolves uses parsed actual path and same_file_free_helper_call_reaches_owner for each hop; matrix tests wrong/genuine imports and intermediate identities. |
| 4282848781 | Async in assertion operand | Repaired: synthetic operand uses the same node_executes_in and original macro call as lexical anchor; twelve dormant/outer controls retain separate native truth. |
| 4285435939 | Unpolled async-function helper | Repaired: declaration authority requires Some(false) at entry/intermediate/last hop; None/async refuse. Native async-entry survivor versus named synchronous-chain killed mutant independently rerun here. |
| 4286413179 | Sparse sync-chain documentation | Repaired: async fixture SPEC.md explicitly distinguishes one-line function-header capture, named full-callee tokens and multiline positive. No polling inference added. |

## Review 5543012062 and other substantive review prose

The latest prior source review is 5543295375; review 5543012062 was also read rather than silently omitted. Its claimed operand-cache bypass is refuted by both executable_call_resolves and assertion_arguments_resolve selecting index.source_syntax.parse_fragment for Some(index). There is no test.text short-circuit in this current implementation. The helper declaration concern has the complete-function same-name guard plus inherent_helper_declarations_are_not_executable_self_edges (split-line declaration versus genuine wrapper), while actual execution is separately gated by parsed entry/last-hop identity.

Its alleged missing positive relation assertion is refuted: inherent_receiver_review_last_hop_and_wrapper_controls compares the expected RelationReason exactly, counts one subject in each consumer, and compares complete row maps. The 50-row matrix additionally enforces one test/four seams, complete row parity, exact positive relation, and no direct/helper plus no reach-Yes negatives. The snapshot replacement test clones the RustIndex, asserts non-shared snapshot Arc, mutates the clone to async and confirms the original remains synchronous; unknown/removal also refuse. No clone proof gap follows from the cited premise. No unsupported full Cargo-target/type resolver or arbitrary async activation is claimed.

A real nonblocking documentation mismatch remains: BOUNDARIES.md opens with '34 entries' although cases.json/test denominator is 50, and its final performance wording is stale ('unbenchmarked') relative to the frozen measured evidence. This does not change test inventory, truth rows, relation assertions, current PR performance limits, or integration correctness. Existing source owner may update this wording later; this review changes no candidate files. The original34-plus-16 distinction in other prose is intentional and must not be mechanically rewritten.

The earlier a5 PERFORMANCE_REPAIR_REQUIRED observation is retained history, superseded in the repair dimension by independently established 8e recovery; it does not justify claiming base98 equivalence. Remaining latency/censored-sample limits are expressly retained.

## New current-head automated review 5543715849 (read before publication)

No new inline thread; review prose was not ignored. The alleged inner-fn/impl let leak is refuted by current `visible_receiver_binding_names_type`: it inspects only direct `StmtList.children()` lets (not descendant inner-body lets) and returns false at the enclosing `ast::Fn`; `node_executes_in` excludes calls inside declared items before receiver lookup. Synthetic operands also reject local items and preserve the original anchor.

Fresh exact-36db CLI/native challenges are retained in new-review-controls/: declared inner fn, declared inner impl, and item inside an assertion operand all leave the root owner's four seams without direct/helper execution credit; each native original and owner mutant passes. A paired genuine outer JsonValue call beside a dormant foreign helper retains four direct/high edges; its original passes and owner mutant fails101. These are eight native processes/four real CLI reports; no candidate modification. The observed negative relation may be same_test_file or assertion_target_affinity, never high/direct/helper.

Same-name/same-line ambiguous declarations are deliberately tested at the snapshot/scope authority (fresh source_snapshot group); lack of a duplicate row in the native matrix is not absence of that discriminator. Helper recursion has explicit remaining==0 refusal, decrements remaining-1, visited identity cycle checking and a caller-supplied HELPER_OWNER_CALL_GRAPH_MAX_HOPS. A generic unbounded-recursion assertion is refuted. Split fn-header versus real wrapper self edges have the directly exercised library control cited above.

Externally supplied fresh &str data intentionally takes a standalone snapshot when pointer/length does not match the indexed Arc. It cannot borrow indexed semantic answers; no claim that external-source callers receive indexed memo-hit performance. The retained/current indexed path uses indexed source bytes. Per-query/standalone performance limits remain rather than broadening this review.

The five false-actionable accuracy costs are retained from the original behavioral repair and prior independent evidence; this integration merge does not rewrite those original truth rows into successes. Native-positive explicitly-polled controls remain statically unsupported. No new issue8005 request, source change or expanded resolver/polling contract follows.
