import subprocess as s,pathlib,json,hashlib
root=pathlib.Path('/workspace/review36db-evidence');binary='/workspace/review36db-target/debug/ripr';rows=[]
for case in ['entry','named-sync-chain']:
 p=pathlib.Path('/workspace/review36db-inputs')/case;(p/'src').mkdir(parents=True,exist_ok=True)
 (p/'Cargo.toml').write_text('[package]\nname="bounded-control"\nversion="0.0.0"\nedition="2024"\n[workspace]\n')
 (p/'src/lib.rs').write_bytes((pathlib.Path('/workspace/review36db/fixtures/inherent_receiver_async_function/controls')/(case+'.rs')).read_bytes())
 for fmt in ['repo-exposure-json','repo-badge-json']:
  cmd=[binary,'check','--root',str(p),'--mode','ready','--format',fmt];r=s.run(cmd,capture_output=True);assert r.returncode==0,(cmd,r.stderr)
  (root/'raw'/f'cli-{case}-{fmt}.json').write_bytes(r.stdout);(root/'raw'/f'cli-{case}-{fmt}.stderr').write_bytes(r.stderr)
  j=json.loads(r.stdout);rows.append(dict(case=case,format=fmt,argv=cmd,exit=r.returncode,top_keys=list(j)))
(root/'raw'/'cli-results.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(),rows=rows),indent=2));print(rows)
