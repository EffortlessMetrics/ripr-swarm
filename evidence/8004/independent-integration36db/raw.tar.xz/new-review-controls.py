import pathlib,subprocess as s,os,json,hashlib
out=pathlib.Path('/workspace/review36db-evidence/raw/new-review-controls');out.mkdir(exist_ok=True)
base='''#[derive(Clone, Copy)]
pub(crate) enum JsonValue { Object(u32), Null }
impl JsonValue {
 pub(crate) fn as_object(&self) -> Option<u32> {
  match self { Self::Object(value) => Some(*value), _ => None }
 }
}
struct Foreign;
impl Foreign { fn as_object(&self) -> Option<u32> { Some(7) } }
#[cfg(test)] mod tests { use super::*;
#[test] fn subject() { BODY }
}
'''
cases=[('inner-fn',False,'let value=Foreign; fn dormant(){let value=JsonValue::Object(7); assert_eq!(value.as_object(),Some(7));} assert_eq!(value.as_object(),Some(7));'),('inner-impl',False,'let value=Foreign; struct Inner; impl Inner {fn dormant(){let value=JsonValue::Object(7); assert_eq!(value.as_object(),Some(7));}} assert_eq!(value.as_object(),Some(7));'),('operand-fn',False,'let value=Foreign; assert_eq!({fn dormant(){let value=JsonValue::Object(7); assert_eq!(value.as_object(),Some(7));} value.as_object()},Some(7));'),('genuine-outer',True,'let value=JsonValue::Object(7); fn dormant(){let value=Foreign; assert_eq!(value.as_object(),Some(7));} assert_eq!(value.as_object(),Some(7));')]
env=os.environ.copy();env['RUSTUP_HOME']='/workspace/.rustup';rows=[]
for case,positive,body in cases:
 source=base.replace('BODY',body);p=pathlib.Path('/workspace/review36db-inputs')/case;(p/'src').mkdir(parents=True,exist_ok=True);(p/'src/lib.rs').write_text(source);(p/'Cargo.toml').write_text('[package]\nname="bounded-control"\nversion="0.0.0"\nedition="2024"\n[workspace]\n')
 cmd=['/workspace/review36db-target/debug/ripr','check','--root',str(p),'--mode','ready','--format','repo-exposure-json'];r=s.run(cmd,capture_output=True);assert r.returncode==0;(out/(case+'.json')).write_bytes(r.stdout);j=json.loads(r.stdout);owner=[a for a in j['seams'] if a['owner']=='src/lib.rs::impl JsonValue::as_object'];assert len(owner)==4
 relations=[]
 for seam in owner:
  tests=seam['related_tests'];assert len(tests)==1;relation=tests[0]['relation_reason'];relations.append(relation)
  if positive:assert relation=='direct_owner_call' and seam['evidence']['reach']=='yes'
  else:assert relation not in ['direct_owner_call','helper_owner_call'] and seam['evidence']['reach']!='yes'
 natives=[]
 for variant in ['original','mutant']:
  text=source if variant=='original' else source.replace('Self::Object(value) => Some(*value),','Self::Object(value) => None,');assert text!=source or variant=='original';path=out/(case+'-'+variant+'.rs');path.write_text(text);binary=path.with_suffix('');c=s.run(['/workspace/.cargo/bin/rustc','+1.95.0','--edition=2024','--test','--crate-name','control',str(path),'-o',str(binary)],env=env,capture_output=True);path.with_suffix('.compile.log').write_bytes(c.stdout+c.stderr);assert c.returncode==0
  n=s.run([str(binary)],capture_output=True);path.with_suffix('.run.log').write_bytes(n.stdout+n.stderr);expected=101 if variant=='mutant' and positive else 0;assert n.returncode==expected;natives.append(dict(variant=variant,compile_exit=c.returncode,run_exit=n.returncode,source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
 rows.append(dict(case=case,positive=positive,cli_command=cmd,cli_exit=r.returncode,owner_relations=relations,native=natives))
(out/'results.json').write_text(json.dumps(rows,indent=2));print([(r['case'],r['owner_relations'],[n['run_exit'] for n in r['native']]) for r in rows])
