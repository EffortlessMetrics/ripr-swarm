import subprocess,pathlib,json,time,re,os
p=pathlib.Path('/workspace/review8004-raw');rows=[]
commands=[['cargo','test','--locked','-p','ripr','--test','private_inherent_receiver'],['cargo','test','--locked','-p','ripr','--lib','inherent_'],['cargo','test','--locked','-p','ripr','--lib','trim_field_period_tests'],['cargo','test','--locked','-p','xtask','--bin','xtask','evidence_promotion_semantic_assertions_reject_missing_human'],['cargo','test','--locked','-p','xtask','--bin','xtask','reports::fixtures::preparation::tests']]
for i,args in enumerate(commands):
    log=p/('focused-'+str(i)+'.log');start=time.time()
    with log.open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
    text=log.read_text();counts=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    row={'argv':args,'subject':'740b6da9b2cc9fd402b9f588fe1c1f972d64745a','cwd':os.getcwd(),'exit':r.returncode,'elapsed':time.time()-start,'summaries':counts,'log':log.name};rows.append(row);(p/'focused-receipt.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
    assert r.returncode==0 and counts and sum(int(x[1]) for x in counts)>0,row
