# Independent cumulative source/oracle review

- Repository: EffortlessMetrics/ripr-swarm, Draft PR #8004.
- Reviewed source: `8e0444b1a62ead18584d40b18278c6e8716dc56c`, tree `da4222d49d37aa82662003e0b6ef4ca8715dbac3`.
- Delta basis: `77474e347bbdd8ef2101b7f9865e65f094df44c1`.
- Method: independent context/source review of committed Git objects; no candidate edits or HEAD movement. Source inspection first completed at `666b4e0a4c53312c9d7e1b52f9e304bf62e9e857`; both subsequent test-only corrections were inspected, extending currentness through exact 8e.

## Surfaces inspected

All eight delta files: `.ripr/traceability.toml`, `changelog.d/7415-inherent-receiver-admission.md`, `crates/ripr/src/analysis/classify/owner_pin.rs`, its `tests.rs`, `classify/related_tests.rs`, `syntax/mod.rs`, `syntax/source_snapshot.rs`, and `docs/specs/RIPR-SPEC-0005-repo-seam-inventory.md`.

Necessary retained consumers/authorities inspected included `named_or_slice`, `owner_call_relation_reason`, `executable_call_resolves`, `assertion_arguments_resolve`, `inherent_call_node_resolves`, `node_executes_in`, `scoped_receiver_names_type`, owner resolution/root and module-ancestor helpers, `module_item_names_type`, `file_aliases_type`, `file_renames_to`, source snapshot lookup/clone behavior, lexical name/nesting consumers, and `ra::LineIndex`.

## Challenges and conclusions

- Shadow answers retain every effective non-source input: test name/start/end, requested spelling, type/trait kind, and owner file/name/start. Per-path snapshot slots retain the source Arc and replace on source identity changes. The supplied-source pointer guard prevents borrowing an indexed snapshot for unrelated bytes; standalone inputs get standalone snapshots. Clones start empty.
- Inclusive line calculations match the previous newline-count logic. Byte ancestry, all ambiguous same-line test matches, unique owner resolution, nearest owner-module exemption, raw identifiers, type aliases, malformed-source refusal, and macro-shaped inclusive-line fallback preserve prior semantics by source comparison. A same-line sibling cannot become an exempt ancestor.
- Imported aliases remain refused by outer `file_renames_to` authority. The module declaration helper does not claim to recognize `use ... as` imports.
- Caller/operand memoization shares immutable parse storage by complete bytes only. Each reader reconstructs its red syntax view. Owner decisions and original macro invocation lexical anchors remain per query; execution/item/closure/async and operand-local binding/scope refusals remain unchanged.
- Added controls discriminate reuse, source replacement, external-source isolation, clone isolation, owner file/name/start, type-versus-trait, raw/type-alias names, same-line ambiguity, and malformed syntax. Some coordinate-key checks observe computation counts rather than behavior, so those do not independently prove end-to-end classification.

## Findings and followups

The initial new test incorrectly expected the module declaration helper to recognize an imported alias. Exact successor `246c3063ac970b5541e7364fef1786d2e00b3f82` corrected that expectation to false and explicitly asserts `file_renames_to(source, "Widget")`; production behavior was unchanged. Exact 8e then removed four invalid `.as_ref()` calls from test `green()` pointer comparisons, retaining the intended identical/different-byte sharing oracle. Both followups were inspected. No blocking source/oracle findings remain.

Independent execution of the author-built frozen candidate passed five `source_snapshot` and three `module_shadow_snapshot` tests. Independent execution of the isolated memo-removal binary produced the two intended runtime assertion failures, with six other controls passing. These are execution witnesses, not independent builds or a full suite rerun. Separate receipts retain identity, commands, outputs, and negative-control composition.

## Limits and disposition

`REVIEW_INCOMPLETE`: this cumulative source/oracle review and the separate retained-data audits do not establish hosted/latest-main integration, native Windows, full-workspace runtime acceptance, release qualification, or general performance bounds. Broader runtime/gates/profile evidence was author-built/executed and independently data-audited, not independently rebuilt or broadly rerun. Existing unsupported semantic boundaries and index-local memo cardinality costs remain. Three descriptive timing repetitions are not general no-regression evidence; inclusive profile spans overlap, fingerprint groups are not semantic query identities, and the selected benchmark supplies no measured shadow-answer hit benefit.

No new blocking source/oracle/data inconsistency found. Candidate source remains exact 8e; isolated removal and profiling experiments are not canonical candidate source. No Ready/merge/publication disposition is supplied.
