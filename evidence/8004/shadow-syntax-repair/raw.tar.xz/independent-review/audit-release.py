import pathlib,json,subprocess,hashlib,statistics as S,collections,datetime
R=pathlib.Path('/workspace/shadow8004');L=R/'logs';O=R/'independent-review';H='8e0444b1a62ead18584d40b18278c6e8716dc56c'
def load(p):return json.loads((R/p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd='/workspace/ripr-swarm',text=True).strip()
c=load('logs/candidate-release-binary.json');assert c['source']==H and not c['dirty'] and sha(c['path'])==c['sha256'] and pathlib.Path(c['path']).stat().st_size==c['bytes'] and git('rev-parse',H+'^{tree}')==c['tree']
rows=[json.loads(s) for s in (L/'candidate-release.jsonl').read_text().splitlines() if s.startswith('{')];assert c['artifact'] in rows and rows[-1]=={'reason':'build-finished','success':True};env=[dict(r['env']) for r in rows if r.get('reason')=='build-script-executed' and r.get('package_id')==c['artifact']['package_id']];assert any(e.get('RIPR_BUILD_COMMIT')==H and e.get('RIPR_BUILD_COMMIT_DIRTY')=='false' for e in env)
b=load('logs/base-release-binary.json');assert sha(R/'bin/base')==b['sha256']
def norm(v,root):
 if isinstance(v,dict):return {k:norm(x,root) for k,x in v.items()}
 if isinstance(v,list):return [norm(x,root) for x in v]
 if isinstance(v,str):return v.replace(root,'$REPLAY')
 return v
par=load('logs/cli-parity.json');assert par['reports']==len(par['rows'])==189 and not par['differences']
for row in par['rows']:
 ds=[]
 for v,key in [('cli-base','baseline_sha256'),('cli','candidate_sha256')]:
  p=R/'replay'/v/f"{row['case']:02}"/row['format']/'output.json';assert sha(p)==row[key];d=json.loads(p.read_text());d.pop('artifact',None);ds.append(norm(d,str(R/'replay'/v)))
 assert ds[0]==ds[1]
inv=load('invalidation/results.json');assert len(inv)==12;stim=load('review/inputs/immutable-stimuli.json')
for row in inv:
 assert row['exit']==0 and row['case']==[61,60,61][row['step']] and hashlib.sha256(stim[row['case']]['source'].encode()).hexdigest()==row['source_sha256']
 p=R/'invalidation'/f"{row['step']}-{row['format']}-{row['cache']}.json";d=json.loads(p.read_text());d.pop('artifact',None)
 if row['format']=='repo-exposure-json':
  seams=[s for s in d['seams'] if s['owner']=='src/lib.rs::impl JsonValue::as_object'];assert len(seams)==4;rels=[r['relation_reason'] for s in seams for r in s['related_tests']];assert rels==row['relations'];assert ('helper_owner_call' in rels)==(row['case']==61)
 if row['cache']=='fresh':
  other=json.loads((R/'invalidation'/f"{row['step']}-{row['format']}-reused.json").read_text());other.pop('artifact',None);assert d==other
rs=[s.split('\t') for s in (R/'evidence/measurements.tsv').read_text().splitlines()];assert len(rs)==len({tuple(r[:6]) for r in rs})==120
manifest=load('logs/benchmark-output-manifest.json');assert len(manifest)==120;mi={x['path']:x for x in manifest};perf=load('logs/performance.json');res=load('logs/resources.json');groups=collections.defaultdict(list);proj={};costs={}
for r in rs:
 label,w,m,i,v,cache,t,ex,size,ns=r;id='-'.join(r[:6]);p=R/'evidence/raw'/(id+'.json');raw=p.read_bytes();assert ex=='0' and len(raw)==int(size);z=mi[str(p.relative_to(R))];assert z['bytes']==len(raw) and z['sha256']==hashlib.sha256(raw).hexdigest();d=json.loads(raw);d.pop('artifact',None);expected=98 if w=='fixture-mix-16' else 112 if '16' in w else 448
 if m=='full':assert d['run_status']=='complete' and d['metrics']['seams_total']==expected
 else:assert d['metrics']['raw_seams']==expected
 proj[id]=d;groups[w,m,v,cache].append((int(i),float(t)));receipts=[json.loads(s.split(' ',1)[1]) for s in p.with_suffix('.stderr').read_text().splitlines() if s.startswith('ripr_resource_cost_receipt ')];assert len(receipts)==1;co=receipts[0];assert co['cpu']['state']==co['peak_resident_bytes']['state']=='observed';costs[id]=((co['cpu']['user_ms']+co['cpu']['system_ms'])/1000,co['peak_resident_bytes']['value'],co)
ws=['fixture-mix-16','sync-16-single','sync-16-split','sync-64-single','sync-64-split'];expected={(w,m,v,c) for w in ws for m in ['full','compact'] for v in ['base','candidate'] for c in ['cold','warm']};assert set(groups)==expected and all(sorted(x[0] for x in val)==[0,1,2] for val in groups.values())
for g in perf['groups']:
 k=tuple(g[x] for x in ['workload','mode','variant','cache']);val=[x[1] for x in groups[k]];med=S.median(val);assert (g['n'],g['median_s'],g['MAD_s'],g['min_s'],g['max_s'],g['samples_s'])==(3,med,S.median(abs(x-med) for x in val),min(val),max(val),val)
for p in perf['paired']:
 w,m,cach=p['workload'],p['mode'],p['cache'];base=dict(groups[w,m,'base',cach]);ratios=[t/base[i] for i,t in groups[w,m,'candidate',cach]];assert ratios==p['repair_over_774_ratios'] and S.median(ratios)==p['median_ratio']
for p in res['processes']:assert costs[p['id']]==(p['cpu_s'],p['peak_resident_bytes'],p['receipt'])
assert len(res['processes'])==120
for g in res['groups']:
 w,m,v,cach=[g[x] for x in ['workload','mode','variant','cache']];cs=[costs[f'repair8e-{w}-{m}-{i}-{v}-{cach}'] for i in range(3)];cp=[x[0] for x in cs];rss=[x[1] for x in cs];assert (g['cpu_median_s'],g['cpu_range_s'],g['rss_median_bytes'],g['rss_range_bytes'])==(S.median(cp),[min(cp),max(cp)],S.median(rss),[min(rss),max(rss)])
for w in ws:
 for m in ['full','compact']:
  ds=[proj[f'repair8e-{w}-{m}-{i}-{v}-{cach}'] for i in range(3) for v in ['base','candidate'] for cach in ['cold','warm']];assert all(x==ds[0] for x in ds)
 for v in ['base','candidate']:
  a=proj[f'repair8e-{w}-full-0-{v}-cold']['metrics'];z=proj[f'repair8e-{w}-compact-0-{v}-cold']['metrics'];assert z['raw_seams']==a['seams_total'] and all(a[k]==val for k,val in z['grip_class'].items())
profile='88ee314a0e14ef9a768032d4587ce8d26adadc2e';assert git('rev-parse',profile+'^{tree}')=='1cf613b295cf8883aa6e9a8773d94dc5efd44e75';assert subprocess.check_output(['git','diff',H,profile],cwd='/workspace/ripr-swarm')==(L/'profile-experiment-final.patch').read_bytes()
summary=[]
for w in ws:
 for m in ['full','compact']:
  a=S.median(t for _,t in groups[w,m,'base','cold']);z=S.median(t for _,t in groups[w,m,'candidate','cold']);ratio=next(p['median_ratio'] for p in perf['paired'] if (p['workload'],p['mode'],p['cache'])==(w,m,'cold'));summary.append({'workload':w,'mode':m,'baseline_median_s':a,'candidate_median_s':z,'paired_median_ratio':ratio})
receipt={'candidate':H,'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary':{'sha256':c['sha256'],'compiler_artifact_stamp_hash_verified':True,'baseline_hash_verified':True},'release_cli_reports_recomputed':189,'invalidation_reports_recomputed':12,'timed_rows_unique':120,'raw_manifest_hash_size_matches':120,'groups_recomputed':40,'paired_groups_recomputed':20,'resources_recomputed':120,'normalization':'top-level artifact removal only for timed/invalidation; exact replay-root rebase additionally for CLI','cold_summary':summary,'profile_experiment':{'commit':profile,'tree':'1cf613b295cf8883aa6e9a8773d94dc5efd44e75','patch_exactly_matches_git_diff':True,'inspection':'Instrumentation guards/track_caller/profile module/dump only. Inclusive spans overlap. Hash+length fingerprint groups can collide; dump errors ignored: inspect actual outputs before credit.'},'limits':['Independent data recomputation of author-built/author-run evidence; no independent build or timing rerun','Three descriptive paired repetitions; analyzer-cache cold, not OS cold','CPU/RSS process self-observations; no exclusive attribution','Profile runtime outputs pending','REVIEW_INCOMPLETE; no hosted/fullruntime/general performance qualification']}
(O/'release-raw-audit.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
