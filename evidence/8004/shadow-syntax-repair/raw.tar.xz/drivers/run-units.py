import json,pathlib,subprocess,hashlib,sys
H=pathlib.Path('/workspace/shadow8004');bins=[]
for l in (H/'logs/libtest-build.jsonl').read_text().splitlines():
 try:d=json.loads(l)
 except:continue
 if d.get('reason')=='compiler-artifact' and d.get('executable') and d.get('profile',{}).get('test'):bins.append(d['executable'])
assert len(bins)==1,bins
b=bins[0];results=[];subjects=set()
for f in ['source_snapshot','analysis::classify::owner_pin::','analysis::classify::call_identity::','analysis::syntax::name_scope::','analysis::classify::related_tests::','analysis::test_grip_evidence::']:
 argv=[b,f,'--test-threads=2'];p=subprocess.run(argv,capture_output=True,text=True,timeout=300);(H/'logs'/('unit-'+f.replace(':','_')+'.log')).write_text(p.stdout+p.stderr)
 for line in p.stdout.splitlines():
  if line.startswith('test ') and line.endswith(' ... ok'):subjects.add(line[5:-7])
 results.append({'filter':f,'argv':argv,'exit':p.returncode,'summary':[l for l in p.stdout.splitlines() if l.startswith('test result:')]})
 (H/'logs/unit-results.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/ripr-swarm',text=True).strip(),'binary':b,'sha256':hashlib.sha256(pathlib.Path(b).read_bytes()).hexdigest(),'results':results,'distinct_passed_subjects':len(subjects),'subjects':sorted(subjects)},indent=2));print(f,p.returncode,results[-1]['summary'],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
