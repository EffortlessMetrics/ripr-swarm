from pathlib import Path
import json,datetime,hashlib
H=Path('/workspace/shadow8004');P=H/'packet'
def load(n):return json.loads((H/n).read_text())
subjects=load('logs/source-subjects.json');perf=load('logs/performance.json');profiles=load('logs/profile-summary.json');b=load('logs/base-release-binary.json');c=load('logs/candidate-release-binary.json');p=load('logs/profile-release-binary.json')
assert perf['processes']==120 and not perf['cross_variant_differences'];assert load('logs/cli-parity.json')['reports']==189
cold=[]
for w in ['fixture-mix-16','sync-16-single','sync-16-split','sync-64-single','sync-64-split']:
 for mode in ['full','compact']:
  groups={g['variant']:g for g in perf['groups'] if g['workload']==w and g['mode']==mode and g['cache']=='cold'};ratio=next(r for r in perf['paired'] if (r['workload'],r['mode'],r['cache'])==(w,mode,'cold'));cold.append(dict(workload=w,mode=mode,baseline=groups['base'],candidate=groups['candidate'],paired=ratio))
sync=next(r for r in profiles if r['workload']=='sync-64-single' and r['mode']=='compact')
nonclaims=['Three paired descriptive repeats, no general no-regression/full performance qualification, no new a5/base98 equivalence.','Inclusive profile spans overlap: never sum or claim exclusive wall/CPU attribution. Instrumented elapsed time is not release benchmark time.','Broader runtime evidence author-executed and independently data-audited; independent reviewer reused author-built frozen binaries for eight controls and memo-removal failures, not an independent build/full rerun.','Latest-main/hosted actual checkout, native Windows and full workspace runtime qualification remain separate.','Honesty corpus 324 pass/0 fail/1 pinned-external not run; precommit zero skips is a separate denominator.','Existing unsupported async, closures/items, lexical/module ambiguities and bounded resolver limits remain. Index-local memo memory follows unique source/fragment/query cardinality; per-query AST walks and short-lived owner syntax scans remain.','Prior censored runs, accuracy costs, setup/compiler failures and resource interruptions retained, no corpus rebless.','Open Draft REVIEW_INCOMPLETE; no Ready/merge/thread resolution/release/deploy/bot contact. Issue8005 not read or retried.']
failures=['initial local publication staging copied archive before packaging completed; verifier rejected checksum, failed local commit4e815 retained without push; final packet staged only after terminal verification','baseline worktree doctor behind-main failure retained; no material main integration prerequisite identified','baseline parallel release build interrupted at memory pressure; serial exact 774 build reproduced retained digest','initial workload --locked attempt lacked lock; preserved and generated offline lock before native replay','new use-alias test oracle corrected to existing file_renames_to authority before execution','246 test-only green.as_ref API compile failure; fixed8e','test build begun during test-only commit had246 dirty stamp; deliberately interrupted and clean8e rebuilt']
receipt=dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository='EffortlessMetrics/ripr-swarm',pr=8004,disposition='CANDIDATE_REPAIRED / MATERIAL_RECOVERY_OBSERVED / REVIEW_INCOMPLETE; keep Draft',subjects=subjects,binaries=dict(baseline=b,candidate=c,instrumented=p),recovery=load('logs/recovery.json'),validation=dict(units=888,integrations=14,native_originals=63,native_mutants=dict(fail=28,survive=35),native_workload_tests=176,release_CLI=189,development_CLI=189,baseline_CLI=189,invalidation_reports=12,check_fast_gates=15,typed_precommit_paths=173,precommit_skips=[],precommit_limitations=[],golden_fixtures=465,golden_surfaces=1157,drift=0,honesty=dict(passed=324,failed=0,not_run=1,total=325),dogfood='pass advisory'),performance=perf,resources=load('logs/resources.json')['groups'],profile=profiles,isolated_removal=load('logs/memo-removal-results.json'),independent_review_files=[str(x.relative_to(H)) for x in sorted((H/'independent-review').glob('*.json'))],source_composition=load('logs/composition-final.json'),preserved_failures=failures,remaining_limits=nonclaims)
(P/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
rows=['| Workload / cold mode |774 median [range] s|8e median [range] s|Median paired8e/774|','|---|---:|---:|---:|']
for r in cold:
 a=r['baseline'];z=r['candidate'];rows.append(f"|{r['workload']} / {r['mode']}|{a['median_s']:.3f} [{a['min_s']:.3f}, {a['max_s']:.3f}]|{z['median_s']:.3f} [{z['min_s']:.3f}, {z['max_s']:.3f}]|{r['paired']['median_ratio']:.3f}|")
profile_lines=[]
for s in sync['sites']:
 if s['kind'] in ['shadow_scope_build','shadow_answer_miss','fragment_query','fragment_miss','executable_query','parse_clean_source_file']:
  profile_lines.append(f"- `{s['kind']}` `{s['file']}:{s['line']}`: {s['calls']:,} calls, {s['unique_inputs']} fingerprint groups, {s['inclusive_s']:.6f}s inclusive.")
text=f'''# Draft #8004 immutable shadow/fragment syntax repair

Source `{subjects['candidate']}`, tree `{subjects['candidate_tree']}`; baseline `{subjects['source']}`. Source basis `{subjects['basis']}` remains distinct from the observed main/composition subjects in `receipt.json`. Exact compiler artifacts, source patches and original failures are in the archive. Keep Draft; fresh full exact-head review remains required.

## Change and retained semantics

`test_module_shadows_item` now shares immutable complete-source parse, line and scope facts and fully keyed shadow answers. The snapshot supplies exact file/source identity; the query retains test name/start/end, base, type-or-trait and full available owner file/name/start. A foreign source uses a standalone snapshot, source replacement invalidates, clones start empty. Owner-module exemption, raw names, aliases, same-line ambiguity and macro-shaped fallback stay conservative. Caller and assertion-operand content shares immutable green parses only; per-call lexical anchors, current owner predicates, async/item/closure/scope refusals still execute.

## Measured retained release inputs

Locked Rust 1.95.0/default features/unchanged opt3,LTO,codegen-units1 profile, Linux four-CPU quota,16GiB, Rayon4. Three alternating paired repetitions, analyzer-cache-cold plus immediate warm partner,120 processes, zero timeouts. No build/setup/profile overlaps timed samples. Cold is not OS-cold. Full medians/MAD/ranges, paired ratios, CPU/RSS process receipts and all raw reports remain in the archive.

{chr(10).join(rows)}

All 120 complete reports have zero within-variant, cross-variant or full/compact metric-control failures after only top-level artifact removal. No root rebasing is needed for these same-root benchmarks. Warm results and raw resource counters are in `receipt.json`; these observations are descriptive, not a general no-regression claim.

## Isolated bounded profiling

Experiment `{subjects['profile_experiment']}`, tree `{subjects['profile_tree']}`, instrumentation-only patch against 8e. The composition parents and patch hash are explicit; this is not a main integration. All 10 cold instrumented reports equal the unmodified candidate after only artifact removal. Prior compact sync64 profile counted 12,288 complete-file shadow reparses/39.153s inclusive, caller 1,292,640 reparses/four contents and operand 516,160/two contents. New compact sync64 observations:

{chr(10).join(profile_lines)}

All 12,288 shadow-answer entries are distinct misses in this selected compact workload: do not credit shadow-answer hits for its timing recovery. Repeated-query unit/removal controls establish answer reuse separately. Executable queries remain 1,292,640/7.513s inclusive; shared complete-file parse/scope construction occurs once, fragment misses six across 1,808,800 queries. No UnitStructFacts scan is observed in these selected profiles; this does not clear other workspace workloads.

Inclusive spans overlap, including parser wrappers and concurrent full-mode work. Do not sum or interpret them as exclusive wall attribution. Profile unique_inputs fields count hash/length fingerprint groups and can collide; production fragment keys compare complete bytes. Instrumentation overhead is outside benchmark results. Remaining per-query traversal and owner syntax work remains visible in the full profile.

## Correctness, invalidation and review

Exact 8e:888 distinct affected units,14 integrations,189 release CLI reports pass; development and baseline 189 replays also pass complete-report comparison after only top-level artifact removal and exact replay-root rebasing. Native 63 originals pass;28 owner mutants fail/35 survive, one real test each. Retained five workload native inventories total176 real tests. Same-path sync→async→sync source replacement passes12 reused/fresh complete-report controls.

15-gate check-fast and typed precommit pass on173 exact changed paths, zero precommit skips/limitations. All 465 fixtures/1,157 golden surfaces pass with zero drift; complete fixtures tree `{subjects['complete_fixtures_tree']}` is identical to774. No truth/golden refresh. Honesty 324 pass/0 fail/1 pinned-external not run (explicit opt-in required); advisory dogfood passes. Configured judged-panel departures remain visible, not relabeled zero accuracy errors.

Independent distinct-context source and retained-data audit found no blocking finding. It independently executed eight candidate sharing controls and eight isolated memo-removal controls on author-built frozen binaries; two removal controls fail at intended runtime assertions while candidate twins pass. It did not independently build or rerun888/14/189. Broader review remains incomplete. Removal experiment `{receipt['isolated_removal']['experiment']}` is isolated, not canonical source.

## Recovery, failures and remaining limits

Both requested immutable packets were recovered and checksum/all-member verified:4,660 plus5,464 files, full bytes/sizes/modes. Prior timestamp-rounding limits remain; no nanosecond-preservation claim. Prior accuracy costs and censored old runs stay in those immutable packets.

{chr(10).join('- '+x for x in failures)}

{chr(10).join('- '+x for x in nonclaims)}

## Reproduce and inspect

Recover this immutable commit with Git, run `sha256sum -c SHA256SUMS`, then `python drivers/verify-new-packet.py <packet-directory>` using the archived driver after extraction. `MANIFEST.json` inventories every raw member byte/size/mode. Archive mtime/uid/gid are explicitly normalized to zero; compiled executable witnesses are excluded but exact hashes, compiler receipts, native inventory and build/run drivers are retained. Task-owned executable witnesses and worktrees remain local for review; inherited target storage was not cleaned.

Extract `raw.tar.xz` to a new directory. Review `drivers/release-validation.sh`, `replay.py`, `bench.rs`, `analyze-bench.py`, `profile-validation.sh`, `profile-run.py`, source/profile/removal patches and logs. Drivers deliberately use recorded absolute task roots; adapt roots explicitly rather than silently changing normalization. Build baseline 774 and candidate8e separately with unchanged locked release/default-feature profile; verify compiler artifacts/version/source stamp before using them. Native setup lock failure and corrected offline lock receipts are retained. Do not reuse existing cold-cache roots on rerun.

## Handoff

Owner: Rook / Draft #8004, governing7415. Candidate 8e and all exact subjects above. Dependency: fresh full exact-head independent review; hosted/latest-main, native Windows and full-workspace runtime remain separate. Next action: reviewer consumes immutable packet and current source, evaluates remaining single-file residual and correctness boundaries; resume delivery only within existing Draft scope. No merge or Ready authority is supplied.
'''
(P/'README.md').write_text(text)
print('receipt and readable summary generated')
