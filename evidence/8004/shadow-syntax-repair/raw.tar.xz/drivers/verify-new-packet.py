from pathlib import Path
import json,tarfile,hashlib,sys
P=Path(sys.argv[1]);m=json.loads((P/'MANIFEST.json').read_text())['members'];expected={x['path']:x for x in m};assert len(expected)==len(m)
for line in (P/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
seen=set()
with tarfile.open(P/'raw.tar.xz','r:xz') as tf:
 for x in tf:
  assert x.isfile() and x.name in expected and x.name not in seen,x.name
  e=expected[x.name];raw=tf.extractfile(x).read();assert len(raw)==x.size==e['bytes'] and x.mode==e['mode'] and hashlib.sha256(raw).hexdigest()==e['sha256'],x.name;seen.add(x.name)
assert seen==set(expected)
print(json.dumps(dict(verified=True,members=len(seen),bytes=sum(x['bytes'] for x in m),checksums=True,full_bytes_sizes_modes=True)))
