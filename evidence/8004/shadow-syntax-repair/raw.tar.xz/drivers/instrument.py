from pathlib import Path
root=Path('/workspace/shadow8004/profile/crates/ripr/src')
patch=Path('/workspace/shadow8004/review/review/profile-experiment.patch').read_text()
last=patch.split('+++ b/crates/ripr/src/review_profile.rs\n')[1].splitlines()[1:]
code='\n'.join(x[1:] for x in last if x.startswith('+'))+'\n';assert 'pub struct Guard' in code
(root/'review_profile.rs').write_text(code)
p=root/'lib.rs';p.write_text(p.read_text()+'\n#[doc(hidden)]\npub mod review_profile;\n')
p=root/'main.rs';s=p.read_text();anchor='    run_startup(startup::run);';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n    ripr::review_profile::dump();');p.write_text(s)
p=root/'analysis/syntax/nesting.rs';s=p.read_text()
for fn in ['parse_clean_source_file','parse_source_file']:
 anchor='pub(crate) fn '+fn+'(text: &str)';assert s.count(anchor)==1
 s=s.replace(anchor,'#[track_caller]\n'+anchor)
 start=s.index(anchor);body=s.index('{',start)+1;s=s[:body]+f'\n    let _profile = crate::review_profile::Guard::new("{fn}", text);'+s[body:]
p.write_text(s)
p=root/'analysis/syntax/source_snapshot.rs';s=p.read_text()
anchor='    pub(crate) fn parse_fragment(&self, text: &str) -> Option<Parse<SourceFile>> {';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'\n        let _profile = crate::review_profile::Guard::new("fragment_query", text);')
anchor='                let parse = parse_clean_source_file(text);';assert s.count(anchor)==1
s=s.replace(anchor,'                let _profile = crate::review_profile::Guard::new("fragment_miss", text);\n'+anchor)
anchor='''        self.lexical_items
            .get_or_init(|| {''';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'\n                let _profile = crate::review_profile::Guard::new("shadow_scope_build", "");')
# Existing stable first-miss/query spans, preserving earlier profile meaning.
for anchor,kind in [('''        let compute = || {
            let tree = self.parse.as_ref()?.tree();''','declaration_miss'),('''        let compute = || {
            name_scopes_in_tree(''','name_scopes_miss')]:
 assert s.count(anchor)==1
 first,rest=anchor.split('\n',1);s=s.replace(anchor,first+f'\n            let _profile = crate::review_profile::Guard::new("{kind}", "");\n'+rest)
p.write_text(s)
p=root/'analysis/classify/owner_pin.rs';s=p.read_text()
anchor='    snapshot.shadow_answer(key, || {';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n        let _profile = crate::review_profile::Guard::new("shadow_answer_miss", "");')
anchor='    fn file_scopes(&self, index: &RustIndex, file: &Path) -> Option<Arc<FileScopes>> {';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n        let _profile = crate::review_profile::Guard::new("owner_file_scopes_query", "");')
anchor='    fn collect(index: &RustIndex) -> Self {';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n        let _profile = crate::review_profile::Guard::new("unit_struct_workspace_scan", "");')
p.write_text(s)
p=root/'analysis/classify/related_tests.rs';s=p.read_text();anchor='''    resolves: &dyn Fn(SyntaxNode, Option<&SyntaxNode>) -> bool,
) -> bool {
    let parse = match index''';assert s.count(anchor)==1;s=s.replace(anchor,anchor.replace('    let parse = match index','    let _profile = crate::review_profile::Guard::new("executable_query", "");\n    let parse = match index'));p.write_text(s)
