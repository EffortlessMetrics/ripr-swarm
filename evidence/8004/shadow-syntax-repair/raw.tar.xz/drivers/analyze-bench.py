from pathlib import Path
import json,statistics,collections,hashlib
E=Path('/workspace/shadow8004/logs');H=Path('/workspace/shadow8004');rows=[r.split('\t') for r in (H/'evidence/measurements.tsv').read_text().splitlines()];groups=collections.defaultdict(list);norm={};bad=[];hashes=[];reports={}
for r in rows:
 label,w,mode,round_,variant,cache,seconds,status,bytes_,ns=r
 f=H/'evidence/raw'/('-'.join(r[:6])+'.json');raw=f.read_bytes();d=json.loads(raw);d.pop('artifact',None);key=(w,mode,variant)
 expected=98 if w=='fixture-mix-16' else (112 if '16' in w else 448)
 assert int(status)==0 and len(raw)==int(bytes_),r
 if mode=='full':assert d['run_status']=='complete' and d['metrics']['seams_total']==expected,(w,mode,d['metrics'])
 else:assert d['metrics']['raw_seams']==expected,(w,mode,d['metrics'])
 groups[(w,mode,variant,cache)].append((int(round_),float(seconds)))
 if key in norm and norm[key]!=d:bad.append(r[:6])
 else:norm[key]=d
 hashes.append({'path':str(f.relative_to(H)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()});reports[(w,mode,variant,round_,cache)]=d
summary=[]
for (w,mode,v,cache),samples in sorted(groups.items()):
 vals=[x[1] for x in samples];med=statistics.median(vals);summary.append({'workload':w,'mode':mode,'variant':v,'cache':cache,'n':len(vals),'median_s':med,'MAD_s':statistics.median([abs(x-med) for x in vals]),'min_s':min(vals),'max_s':max(vals),'samples_s':vals})
paired=[]
for (w,mode,v,cache),samples in sorted(groups.items()):
 if v!='candidate' or (w,mode,'base',cache) not in groups:continue
 b=dict(groups[(w,mode,'base',cache)]);ratios=[s/b[i] for i,s in samples];paired.append({'workload':w,'mode':mode,'cache':cache,'repair_over_774_ratios':ratios,'median_ratio':statistics.median(ratios)})
def diff(a,b,path=''):
 if type(a)!=type(b):return [(path,a,b)]
 if isinstance(a,dict):
  return [d for k in a.keys()|b.keys() for d in (diff(a[k],b[k],path+'/'+k) if k in a and k in b else [(path+'/'+k,a.get(k),b.get(k))])]
 if isinstance(a,list):
  if len(a)!=len(b):return [(path+'/length',len(a),len(b))]
  return [d for i,(x,y) in enumerate(zip(a,b)) for d in diff(x,y,path+'/'+str(i))]
 return [] if a==b else [(path,a,b)]
cross=[];metricbad=[]
for (w,mode,v),d in norm.items():
 if v=='candidate' and (w,mode,'base') in norm:
  ds=diff(norm[(w,mode,'base')],d)
  if ds:cross.append({'workload':w,'mode':mode,'differences':ds})
 if mode=='full':
  c=norm[(w,'compact',v)]['metrics'];m=d['metrics']
  if c['raw_seams']!=m['seams_total'] or any(m[k]!=n for k,n in c['grip_class'].items()):metricbad.append([w,v])
out={'processes':len(rows),'nonzero_exits':[r for r in rows if r[7]!='0'],'groups':summary,'paired':paired,'within_variant_mismatches':bad,'full_compact_metric_mismatches':metricbad,'cross_variant_differences':cross,'denominator':'three paired descriptive repetitions of774 versus8e; no general no-regression, a5/base98 equivalence or qualification claim'};(E/'performance.json').write_text(json.dumps(out,indent=2));(E/'benchmark-output-manifest.json').write_text(json.dumps(hashes,indent=2));expected_groups={(w,m,v,c) for w in ['fixture-mix-16','sync-16-single','sync-16-split','sync-64-single','sync-64-split'] for m in ['full','compact'] for v in ['base','candidate'] for c in ['cold','warm']}; assert set(groups)==expected_groups; assert len({tuple(r[:6]) for r in rows})==120; assert len(rows)==120 and not bad and not metricbad and not cross; assert all(sorted(i for i,_ in v)==[0,1,2] for v in groups.values()); print('120 complete processes, zero output-control failures')

import re
resources=[]
for r in rows:
 stderr=H/'evidence/raw'/('-'.join(r[:6])+'.stderr')
 receipts=[json.loads(line.split(' ',1)[1]) for line in stderr.read_text().splitlines() if line.startswith('ripr_resource_cost_receipt ')]
 assert len(receipts)==1,r
 cost=receipts[0];assert cost['cpu']['state']=='observed' and cost['peak_resident_bytes']['state']=='observed'
 resources.append(dict(id='-'.join(r[:6]),workload=r[1],mode=r[2],round=int(r[3]),variant=r[4],cache=r[5],cpu_s=(cost['cpu']['user_ms']+cost['cpu']['system_ms'])/1000,peak_resident_bytes=cost['peak_resident_bytes']['value'],receipt=cost))
resource_groups=[]
for g in summary:
 values=[r for r in resources if (r['workload'],r['mode'],r['variant'],r['cache'])==(g['workload'],g['mode'],g['variant'],g['cache'])]
 assert len(values)==3
 resource_groups.append(dict(workload=g['workload'],mode=g['mode'],variant=g['variant'],cache=g['cache'],cpu_median_s=statistics.median(x['cpu_s'] for x in values),cpu_range_s=[min(x['cpu_s'] for x in values),max(x['cpu_s'] for x in values)],rss_median_bytes=statistics.median(x['peak_resident_bytes'] for x in values),rss_range_bytes=[min(x['peak_resident_bytes'] for x in values),max(x['peak_resident_bytes'] for x in values)]))
(E/'resources.json').write_text(json.dumps(dict(groups=resource_groups,processes=resources,limits='Process self-observation; Linux100Hz CPU counters, accumulated thread time; not exclusive query attribution'),indent=2))
