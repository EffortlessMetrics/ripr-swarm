from pathlib import Path
import json,sys
H=Path('/workspace/shadow8004');d=json.loads((H/'packet/receipt.json').read_text());packet_sha=sys.argv[1];readback_sha=sys.argv[2];subject=d['subjects'];url=f'https://github.com/EffortlessMetrics/ripr-swarm/tree/{packet_sha}/evidence/8004/shadow-syntax-repair';readback=f'https://github.com/EffortlessMetrics/ripr-swarm/blob/{readback_sha}/evidence/8004/shadow-syntax-repair-publication-readback.json';perf=d['performance'];rows=[]
for w in ['fixture-mix-16','sync-16-single','sync-64-single','sync-64-split']:
 for mode in ['full','compact']:
  g={x['variant']:x for x in perf['groups'] if (x['workload'],x['mode'],x['cache'])==(w,mode,'cold')};r=next(x for x in perf['paired'] if (x['workload'],x['mode'],x['cache'])==(w,mode,'cold'));rows.append(f"|{w}, {mode}|{g['base']['median_s']:.3f}s|{g['candidate']['median_s']:.3f}s|{r['median_ratio']:.3f}|")
sync=next(x for x in d['profile'] if (x['workload'],x['mode'])==('sync-64-single','compact'));counts={}
for x in sync['sites']:counts[x['kind']]=counts.get(x['kind'],0)+x['calls']
body=f'''## Problem and change

Refs #7415. Inherent-owner attribution still requires bounded nominal receiver evidence, complete declaration/module identity and executable calls. Dormant items, closures, async blocks and unpolled async-function helpers retain their conservative refusals. Genuine synchronous/mixed/public-library positives remain.

The independent runtime review of774 found material recovery but sync64 compact still took84.703s versus2.968s split. Its bounded profile identified12,288 complete-file shadow reparses (39.153s inclusive),1,292,640 caller reparses/four contents and516,160 operand reparses/two contents. Inclusive counters overlap; these are not exclusive wall attribution.

This repair shares immutable snapshot parse/line/module ancestry facts and fully keyed shadow answers. Test name/start/end, source/file, base, type-or-trait and complete available owner file/name/start stay in the identity. Source replacement, clone, explicit external-source and same-line ambiguity controls retain independent answers. Caller/operand parsing shares immutable green content only; current lexical anchors, owner predicates and every execution/scope refusal still run. No resolver, polling or macro-expansion scope is added.

## Candidate and immutable evidence

- **Open Draft**, source `{subject['candidate']}`, tree `{subject['candidate_tree']}`; normal history-preserving successor of774. Ownership and expected remote source were checked before editing and publication.
- [Immutable repair packet]({url}): protocol, exact compiler artifacts/hashes, source/profile/removal patches, all raw reports, timing/resource/profile records, replay drivers, negative controls, failures and independent audit receipts. [Fresh remote publication readback]({readback}).
- Both requested prior packets fully recovered/verified: [independent runtime774](https://github.com/EffortlessMetrics/ripr-swarm/tree/562cb1447b74a46fc86512500149c4b957cdb020/evidence/8004/independent-runtime774) and [source snapshot repair](https://github.com/EffortlessMetrics/ripr-swarm/tree/525d1e7d489710bb4cabb5b7a1cf2047eaf993ad/evidence/8004/source-snapshot-repair),10,124 archive members total, bytes/sizes/modes. Their prior timestamp limits, censored a5/base98 runs and accuracy costs remain intact.
- Integrated source basis remains `{subject['basis']}`. Observed main `{d['source_composition']['observed_main']}` composes cleanly as tree `{d['source_composition']['composition_tree']}`; that tree was **not executed or integrated**. GitHub merge object `{d['source_composition']['github_observed_merge']['commit']}` has exactly observed-main/source 8e parents and the same tree; no hosted actual checkout execution is inferred. Main still has the uncached method; unrelated movement supplies no integration prerequisite.

## Measured release recovery

Locked Rust 1.95.0/default features/unchanged release opt3,LTO,codegen-units1 profile; four-CPU quota,16GiB, Rayon4. Baseline774 rebuilt to the exact retained binary digest. Five retained workloads, both modes, three alternating paired repeats with cold/immediate warm partners: **120 successful processes, zero timeouts**. No build/setup/profile overlaps timing. Cold means analyzer-cache-cold, not OS-cold.

|Cold workload/mode|774 median|8e median|Median paired8e/774|
|---|---:|---:|---:|
{chr(10).join(rows)}

All 120 complete reports agree across variants/repeats after only top-level artifact removal, with full/compact metric parity. Full ranges/MAD/paired ratios and CPU/RSS are retained. Sync64 compact single-file still costs about4.6× split on 8e. Three repeats are descriptive; no general no-regression/full performance qualification or new a5/base98 equivalence claim.

Isolated instrumentation experiment `{subject['profile_experiment']}`, tree `{subject['profile_tree']}`, preserves production 8e and changes instrumentation only. All 10 profile reports equal the unmodified candidate after artifact removal. Compact sync64 observed {counts.get('shadow_scope_build',0):,} shared scope builds, {counts.get('shadow_answer_miss',0):,} shadow-answer misses, {counts.get('fragment_query',0):,} fragment queries and {counts.get('fragment_miss',0):,} fragment misses. All 12,288 shadow entries were distinct misses here; this benchmark does not establish a shadow-answer-hit benefit. Repeated-query controls establish reuse separately. Executable queries remain 1,292,640/7.513s inclusive. No UnitStructFacts scan was observed on these selected inputs, which does not clear other workspaces. Remaining AST traversal and owner syntax work stay in scope for a future bounded repair. Profile spans overlap; fingerprint groups are not exact-content identity proof, and instrumented elapsed time is outside release timings.

## Correctness and currentness

- Exact 8e: **888 distinct affected units,14 integrations,189 release CLI reports pass**. Separate baseline 189 and development 189 replays also pass. CLI complete equality admits only artifact removal and exact replay-root rebasing; negative reach/grip restrictions remain.
- Native 63 originals pass;28 owner mutants fail/35 survive, one real test each. Five retained workload setups execute176 tests. Same-path sync→async→sync source replacement passes12 reused/fresh complete-report controls.
- Sharing/full identity/raw names/aliases/same-line ambiguity/exemption/fallback/replacement/clone controls pass. Isolated memo removal makes the two intended runtime assertions fail; independent reviewer executed eight candidate controls and eight removal controls using verified author-built binaries. No independent build/full888 rerun is claimed.
- Exact 8e check-fast passes15 gates including workspace/all-targets Clippy. Typed precommit passes173 exact paths, zero precommit skips/limitations; independent Git/selector inventories agree.
- All 465 fixtures/1,157 golden surfaces pass, zero drift. Complete fixtures tree `{subject['complete_fixtures_tree']}` remains identical to774. **No rebless**. Honesty 324 pass/0 fail/1 pinned-external not run (opt-in required); advisory dogfood passes. Configured judged-panel departures and historical accuracy costs remain visible.
- Distinct-context reviewer inspected the exact source/oracle and independently recomputed189 release comparisons,12 invalidation reports,120 raw timing/resource records and their statistics. Broader evidence is author-run and independently audited, not independently rebuilt/rerun. Fresh full review remains required.

## Limits and continuation

**CANDIDATE_REPAIRED / MATERIAL_RECOVERY_OBSERVED / REVIEW_INCOMPLETE — keep Draft.** Per-query AST walks, short-lived owner syntax work, unique-query memo memory and existing unsupported boundaries remain. Hosted/latest-main actual checkout, native Windows and full-workspace runtime qualification are separate. All original failures remain in the packet: baseline memory-pressure interruption, behind-main doctor failure, native lock setup failure, corrected alias test oracle, test-only compile failure and interrupted dirty-stamp build. Successful clean8e receipts do not erase those attempts. Resource admission/reserves stayed bounded; no inherited target cleanup.

Owner / governing claim: Rook / #7415, existing Draft #8004.
Candidate: source 8e / source basis f2 / tree and unexecuted main composition above.
Review: exact 8e source/control/data audits linked in packet; fresh full exact-head runtime review incomplete.
Validation: commands/results above and raw packet; hosted/latest-main, Windows, full workspace runtime unqualified.
Dependency: fresh independent reviewer judgment; no source integration prerequisite identified.
Next: reviewer consumes exact 8e and immutable packet, evaluates residual cost and preserved refusal boundaries; Rook resumes at that judgment. This handoff does not arrange a background reviewer or authorize Ready/merge.

No Ready, merge, thread resolution, release/deploy, spending, credential/security changes, destructive cleanup or bot contact. Issue8005 was not read or retried.
'''
(H/'pr-body.md').write_text(body);print(len(body),'characters prepared')
