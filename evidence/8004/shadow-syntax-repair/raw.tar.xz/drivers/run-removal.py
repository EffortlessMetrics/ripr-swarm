from pathlib import Path
import json,subprocess,hashlib,shutil
H=Path('/workspace/shadow8004');art=[]
for l in (H/'logs/removal-build.jsonl').read_text().splitlines():
 try:d=json.loads(l)
 except:continue
 if d.get('reason')=='compiler-artifact' and d.get('executable') and d.get('profile',{}).get('test'):art.append(d)
assert len(art)==1
binary=H/'bin/unit-removal';shutil.copy2(art[0]['executable'],binary);rows=[]
for name,needle in [('module_shadow_snapshot_shares_facts_and_complete_answers','identical shadow queries must compute once'),('fragment_parses_share_only_exact_bytes_and_clones_start_empty','assertion failed: std::ptr::eq')]:
 argv=[str(binary),name,'--test-threads=1'];p=subprocess.run(argv,capture_output=True,text=True,timeout=120);text=p.stdout+p.stderr;(H/'logs'/('removal-'+name+'.log')).write_text(text)
 assert p.returncode==101 and 'running 1 test' in text and 'test result: FAILED. 0 passed; 1 failed' in text and needle in text,(name,p.returncode,text)
 rows.append(dict(test=name,argv=argv,exit=p.returncode,intended_failure=True,matched_diagnostic=needle));print(name,'intended runtime failure',flush=True)
(H/'logs/memo-removal-results.json').write_text(json.dumps(dict(parent='8e0444b1a62ead18584d40b18278c6e8716dc56c',experiment='13a423c05a5eaba2bc9dc0d1c7d91a10aa50eb39',tree='a06b1b1957ea5c72acce34d40dd6c7ed3fbeb5f1',binary=str(binary),bytes=binary.stat().st_size,sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),compiler_artifact=art[0],patch_sha256=hashlib.sha256((H/'logs/memo-removal.patch').read_bytes()).hexdigest(),results=rows),indent=2))
