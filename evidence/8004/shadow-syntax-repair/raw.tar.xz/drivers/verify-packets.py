from pathlib import Path
import json,tarfile,hashlib,datetime
h=Path('/workspace/shadow8004');rows=[]
for name,ref,manifest in [('independent-runtime774','562cb1447b74a46fc86512500149c4b957cdb020','MANIFEST.json'),('source-snapshot-repair','525d1e7d489710bb4cabb5b7a1cf2047eaf993ad','ARCHIVE-MANIFEST.json')]:
 p=h/'evidence/8004'/name;checks=[]
 for line in (p/'SHA256SUMS').read_text().splitlines():
  digest,file=line.split(maxsplit=1);file=file.lstrip('* ');b=(p/file).read_bytes();assert hashlib.sha256(b).hexdigest()==digest
  checks.append(dict(path=file,bytes=len(b),sha256=digest))
 expected={x['path']:x for x in json.loads((p/manifest).read_text())['members']}
 with tarfile.open(p/'raw.tar.xz') as t:
  files=[f for f in t if f.isfile()];assert len(files)==len(expected);total=0
  for f in files:
   e=expected[f.name];b=t.extractfile(f).read();total+=len(b)
   assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'] and f.mode==e['mode'],f.name
 rows.append(dict(packet=ref,path=str(p),checksums=checks,member_files=len(files),member_bytes=total,all_member_bytes_sizes_modes_match=True,timestamp_claim='No exact nanosecond claim; original packet timestamp-rounding limits retained'))
(h/'logs/recovery.json').write_text(json.dumps(dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),packets=rows),indent=2));print([(r['packet'][:8],r['member_files']) for r in rows])
