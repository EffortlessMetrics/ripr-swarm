from pathlib import Path
import json,hashlib,sys
H=Path('/workspace/shadow8004');E=H/'replay';rows=[];variant=sys.argv[1] if len(sys.argv)>1 else 'cli'
def normalize(value,variant):
 if isinstance(value,dict):return {k:normalize(v,variant) for k,v in value.items()}
 if isinstance(value,list):return [normalize(v,variant) for v in value]
 if isinstance(value,str):return value.replace(str(E/variant),'$REPLAY')
 return value
for i in range(63):
 for fmt in ['repo-exposure-json','repo-exposure-summary-json','json']:
  a=E/'cli-base'/f'{i:02}'/fmt/'output.json';b=E/variant/f'{i:02}'/fmt/'output.json'
  old=json.loads(a.read_text());new=json.loads(b.read_text());old.pop('artifact',None);new.pop('artifact',None);assert normalize(old,'cli-base')==normalize(new,variant),(i,fmt,'complete semantic report drift')
  rows.append(dict(case=i,format=fmt,baseline_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256(b.read_bytes()).hexdigest(),equal_after_artifact_removal_and_replay_root_rebase=True))
(H/('logs/'+variant+'-parity.json')).write_text(json.dumps(dict(reports=len(rows),differences=[],allowed_normalization=['artifact removal','exact replay-root rebase'],rows=rows),indent=2));print(len(rows),'complete reports agree after only artifact removal and exact replay-root rebase')
