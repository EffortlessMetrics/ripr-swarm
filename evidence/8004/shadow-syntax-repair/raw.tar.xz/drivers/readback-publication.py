from pathlib import Path
import subprocess,json,hashlib,datetime,sys
H=Path('/workspace/shadow8004');sha=sys.argv[1];bare=H/'readback.git';out=H/'readback-packet';rel='evidence/8004/shadow-syntax-repair';assert not bare.exists() and not out.exists()
subprocess.run(['git','init','--bare',str(bare)],check=True,capture_output=True);url='https://github.com/EffortlessMetrics/ripr-swarm.git';subprocess.run(['git','-C',str(bare),'remote','add','origin',url],check=True)
r=subprocess.run(['git','-C',str(bare),'fetch','--no-tags','--depth=1','origin',sha],capture_output=True,text=True);(H/'logs/publication-fresh-fetch.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
assert subprocess.check_output(['git','-C',str(bare),'rev-parse','FETCH_HEAD'],text=True).strip()==sha
paths=subprocess.check_output(['git','-C',str(bare),'ls-tree','--name-only',sha,rel+'/'],text=True).splitlines();expected=sorted(str(Path(rel)/p.name) for p in (H/'packet').iterdir() if p.is_file());assert sorted(paths)==expected and len(paths)==6,(paths,expected)
out.mkdir();records=[]
for path in paths:
 raw=subprocess.check_output(['git','-C',str(bare),'show',sha+':'+path]);local=(H/'packet'/Path(path).name).read_bytes();assert raw==local,path;(out/Path(path).name).write_bytes(raw);records.append(dict(path=path,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),local_bytes_equal=True))
r=subprocess.run(['python',str(H/'drivers/verify-new-packet.py'),str(out)],capture_output=True,text=True);(H/'logs/publication-archive-readback.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr;verified=json.loads(r.stdout)
receipt=dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository='EffortlessMetrics/ripr-swarm',source_head='8e0444b1a62ead18584d40b18278c6e8716dc56c',packet_commit=sha,network_fetch=dict(remote=url,fresh_bare=str(bare),no_local_reference=True,depth=1,fetch_head_verified=True),published_files=records,archive=verified,claim='All six published packet file bytes and every archive member byte/size/mode independently read back via new network-only bare consumer; no archive timestamp precision claim. This sibling receipt is outside the immutable packet to avoid self-reference.');(H/'publication-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(packet=sha,files=len(records),archive=verified)))
