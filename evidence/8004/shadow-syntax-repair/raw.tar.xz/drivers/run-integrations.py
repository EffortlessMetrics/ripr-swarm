import json,pathlib,subprocess,hashlib
E=pathlib.Path('/workspace/shadow8004/logs');bins=[]
for l in (E/'integration-build.jsonl').read_text().splitlines():
 try:d=json.loads(l)
 except:continue
 if d.get('reason')=='compiler-artifact' and d.get('executable') and d.get('profile',{}).get('test'):bins.append(d['executable'])
assert len(bins)==2,bins
results=[]
for b in bins:
 p=subprocess.run([b,'--test-threads=2'],capture_output=True,text=True,timeout=300);(E/(pathlib.Path(b).name+'.log')).write_text(p.stdout+p.stderr);row={'binary':b,'sha256':hashlib.sha256(pathlib.Path(b).read_bytes()).hexdigest(),'exit':p.returncode,'summary':[l for l in p.stdout.splitlines() if l.startswith('test result:')]};results.append(row);(E/'integration-results.json').write_text(json.dumps(results,indent=2));print(row,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
