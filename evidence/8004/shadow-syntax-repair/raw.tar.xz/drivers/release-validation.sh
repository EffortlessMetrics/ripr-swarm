#!/bin/bash
set -euo pipefail
export PATH=/workspace/.cargo/bin:$PATH CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup RAYON_NUM_THREADS=4
TASK_HOME=/workspace/shadow8004
python "$TASK_HOME/drivers/freeze-release.py" candidate > "$TASK_HOME/logs/candidate-freeze.log"
python "$TASK_HOME/drivers/replay.py" cli "$TASK_HOME/bin/candidate" > "$TASK_HOME/logs/cli189.log" 2>&1
python "$TASK_HOME/drivers/compare-cli.py" > "$TASK_HOME/logs/cli-parity.log" 2>&1
python "$TASK_HOME/drivers/cache-invalidation.py" > "$TASK_HOME/logs/invalidation.log" 2>&1
printf 'release189 parity and12 invalidation controls pass\n'
test ! -e "$TASK_HOME/evidence/measurements.tsv"
export BENCH_RUN_LABEL=repair8e
for task_workload in fixture-mix-16 sync-16-single sync-16-split sync-64-single sync-64-split; do
 "$TASK_HOME/bin/bench-driver" measure "$TASK_HOME" 3 "$task_workload" > "$TASK_HOME/logs/bench-$task_workload.log" 2>&1
 printf 'finished retained benchmark: %s\n' "$task_workload"
done
python "$TASK_HOME/drivers/analyze-bench.py" > "$TASK_HOME/logs/analyze-bench.log" 2>&1
printf '120 timed processes and complete report controls pass\n'
