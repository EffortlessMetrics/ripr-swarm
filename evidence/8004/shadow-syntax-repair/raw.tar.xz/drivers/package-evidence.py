from pathlib import Path
import json,hashlib,tarfile,io,os,stat
H=Path('/workspace/shadow8004');P=H/'packet';files={}
def add(p,relative=None):
 if p.is_file() and not p.is_symlink():
  rel=relative or str(p.relative_to(H));assert rel not in files,(rel,p);files[rel]=p
def walk(root,exclude=()):
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if any(x in exclude for x in rel.parts):continue
  if root==H/'replay/native' and p.is_file() and p.stat().st_mode&0o111:continue
  add(p)
for name in ['logs','drivers','independent-review','replay','evidence/raw','caches','profile-results','profile-caches','invalidation']:
 root=H/name
 for p in sorted(root.rglob('*')):
  if '__pycache__' in p.parts or p.name=='packet-local-verification.json':continue
  if 'native' in p.relative_to(H).parts and p.is_file() and p.stat().st_mode&0o111:continue
  add(p)
for name in ['resource-admission.md','evidence/measurements.tsv']:add(H/name)
walk(H/'workloads',('target',))
# Preserve actual official corpus/golden/dogfood observations, excluding executable/lock caches.
walk(H/'checks/target/ripr')
manifest=[]
with tarfile.open(P/'raw.tar.xz','w:xz',preset=6) as tf:
 for rel,p in sorted(files.items()):
  raw=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode);manifest.append(dict(path=rel,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),mode=mode))
  info=tarfile.TarInfo(rel);info.size=len(raw);info.mode=mode;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tf.addfile(info,io.BytesIO(raw))
(P/'MANIFEST.json').write_text(json.dumps(dict(schema=1,members=manifest,normalization='Archive mtime/uid/gid normalized to zero; source bytes and POSIX mode preserved. No timestamp precision claim. Compiled executable witnesses excluded, hashes/build recipes retained locally.'),indent=2)+'\n')
print(json.dumps(dict(members=len(manifest),uncompressed_bytes=sum(x['bytes'] for x in manifest),archive_bytes=(P/'raw.tar.xz').stat().st_size)))
