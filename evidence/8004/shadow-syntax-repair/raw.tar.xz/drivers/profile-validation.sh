#!/bin/bash
set -euo pipefail
export PATH=/workspace/.cargo/bin:$PATH CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/shadow8004/target-release CARGO_INCREMENTAL=0
TASK_HOME=/workspace/shadow8004
python - <<'PY'
from pathlib import Path
import json,subprocess,datetime
H=Path('/workspace/shadow8004');src=H/'profile';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()=='88ee314a0e14ef9a768032d4587ce8d26adadc2e';assert not subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True).strip();(H/'logs/profile-release-build-source.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=src,text=True).strip(),parents=subprocess.check_output(['git','show','-s','--format=%P','HEAD'],cwd=src,text=True).strip().split(),dirty=False,start=datetime.datetime.now(datetime.timezone.utc).isoformat(),note='Isolated instrumentation on production source8e, not a latest-main composition'),indent=2))
PY
cargo build --locked --release -p ripr --bin ripr -j2 --message-format=json > "$TASK_HOME/logs/profile-release.jsonl" 2> "$TASK_HOME/logs/profile-release.log"
python "$TASK_HOME/drivers/freeze-release.py" profile > "$TASK_HOME/logs/profile-freeze.log"
python "$TASK_HOME/drivers/profile-run.py" > "$TASK_HOME/logs/profile-run.log" 2>&1
printf '10 isolated profile outputs agree with unmodified candidate\n'
