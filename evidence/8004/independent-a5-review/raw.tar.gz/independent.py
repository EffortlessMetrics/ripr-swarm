import pathlib,json,subprocess,hashlib,difflib,sys,os
R=pathlib.Path('/tmp/review8004'); E=pathlib.Path('/workspace/8004-independent-review'); mode=sys.argv[1]
rows=json.loads((R/'fixtures/inherent_receiver_free_helper_identity/cases.json').read_text())
cases=[dict(c,source=(R/'fixtures'/c['path']).read_text()) for c in rows]
base=cases[34]['source'].split('async fn read_as_object')[0]
def extra(name,helpers,body,relation=None,native=False):
 cases.append(dict(path=name,name='subject',relation=relation,native_reaches=native,source=base+helpers+'\n#[cfg(test)] mod tests { use super::*; #[test] fn subject() { '+body+' } }\n'))
extra('multiline-async-entry','#[allow(dead_code)]\npub(crate)\nasync\nfn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }','assert_eq!({ let _ = read_as_object(); 7 }, 7);')
extra('multiline-sync-entry','#[allow(dead_code)]\npub(crate)\nfn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }','assert_eq!(read_as_object(), Some(7));','helper_owner_call',True)
extra('multiline-async-last','async\nfn load_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }\nfn read_load_as_object() -> Option<u32> { let _ = load_as_object(); Some(7) }','assert_eq!(read_load_as_object(), Some(7));')
extra('multiline-async-middle','fn load_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }\nasync\nfn read_load_as_object() -> Option<u32> { load_as_object() }\nfn read_read_load_as_object() -> Option<u32> { let _ = read_load_as_object(); Some(7) }','assert_eq!(read_read_load_as_object(), Some(7));')
extra('sibling-async-foreign','mod real { use super::*; pub fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() } }\nmod foreign { use super::*; pub async fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() } }','assert_eq!({ let _ = foreign::read_as_object(); 7 }, 7);')
extra('sibling-sync-genuine','mod real { use super::*; pub fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() } }\nmod foreign { use super::*; pub async fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() } }','assert_eq!(real::read_as_object(), Some(7));',None,True)
cases[55]['relation']='helper_owner_call' # Declarations are on separate lines: actual scope resolves uniquely.
extra('multiline-sparse-sync','fn fetch_as_object() -> Option<u32> {\n JsonValue::Object(7).as_object()\n}\nfn load_as_object() -> Option<u32> {\n fetch_as_object()\n}\nfn read_as_object() -> Option<u32> {\n load_as_object()\n}','assert_eq!(read_as_object(), Some(7));','helper_owner_call',True)
extra('operand-sync-with-async-item','fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }','assert_eq!({ async fn read_as_object() -> Option<u32> { None } let _ = read_as_object(); 7 }, 7);')
extra('async-doc-comment','/// async fn decoy\nfn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }','assert_eq!(read_as_object(), Some(7));','helper_owner_call',True)
extra('same-line-same-name-ambiguity','mod real { use super::*; pub fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() } } mod foreign { use super::*; pub async fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() } }','assert_eq!(real::read_as_object(), Some(7));',None,True)
extra('second-operand-async','async fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }','assert_eq!(7, { let _ = read_as_object(); 7 });')
extra('second-operand-sync','fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }','assert_eq!(Some(7), read_as_object());','helper_owner_call',True)
extra('diagnostic-only-sync','fn read_as_object() -> Option<u32> { JsonValue::Object(7).as_object() }','assert_eq!(7, 7, "{}", { let _ = read_as_object(); 0 });')
(E/'stimuli.json').write_text(json.dumps(cases,indent=2))
results=[]; violations=[]
for i,c in list(enumerate(cases))[int(os.getenv('REVIEW_START','0')):int(os.getenv('REVIEW_END',str(len(cases))))]:
 d=E/mode/f'{i:02}'; d.mkdir(parents=True,exist_ok=True); source=c['source']; digest=hashlib.sha256(source.encode()).hexdigest(); row=dict(index=i,path=c['path'],source_sha256=digest)
 if mode.startswith('native'):
  for variant,s in [('original',source),('mutant',source.replace('Self::Object(value) => Some(*value)','Self::Object(value) => None'))]:
   assert source.count('Self::Object(value) => Some(*value)')==1
   f=d/(variant+'.rs'); f.write_text(s); b=d/variant
   argv=['/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc','--edition=2024','--test',str(f),'-o',str(b)]
   run=subprocess.run(argv,capture_output=True,text=True); (d/(variant+'.compile.log')).write_text(run.stdout+run.stderr)
   assert run.returncode==0,(i,variant,run.stderr)
   run=subprocess.run([str(b)],capture_output=True,text=True); (d/(variant+'.run.log')).write_text(run.stdout+run.stderr)
   expected=101 if variant=='mutant' and c['native_reaches'] else 0
   assert 'running 1 test' in run.stdout,(i,run.stdout)
   row[variant]=dict(argv=argv,exit=run.returncode,expected=expected,sha256=hashlib.sha256(b.read_bytes()).hexdigest())
   if run.returncode!=expected: violations.append([i,variant,run.returncode,expected])
 else:
  binary=sys.argv[2]; row['reports']=[]; full=None
  for fmt in ['repo-exposure-json','repo-exposure-summary-json','json']:
   p=d/fmt;(p/'src').mkdir(parents=True,exist_ok=True); (p/'src/lib.rs').write_text(source); (p/'Cargo.toml').write_text('[package]\nname="independent-control"\nversion="0.0.0"\nedition="2024"\n[workspace]\n')
   patch='diff --git a/src/lib.rs b/src/lib.rs\n'+''.join(difflib.unified_diff(source.replace('Self::Object(value) => Some(*value),','Self::Object(value) => None,').splitlines(True),source.splitlines(True),fromfile='a/src/lib.rs',tofile='b/src/lib.rs'))
   (p/'diff.patch').write_text(patch); argv=[binary,'check','--root',str(p),'--mode','ready','--format',fmt]
   if fmt=='json': argv+=['--diff',str(p/'diff.patch')]
   run=subprocess.run(argv,capture_output=True,text=True);(p/'output.json').write_text(run.stdout);(p/'stderr.log').write_text(run.stderr);assert run.returncode==0,(i,fmt,run.stderr)
   data=json.loads(run.stdout); report=dict(argv=argv,exit=run.returncode)
   if fmt=='repo-exposure-json':
    assert data['run_status']=='complete'; full=data; seams=[s for s in data['seams'] if s['owner']=='src/lib.rs::impl JsonValue::as_object'];assert len(seams)==4,(i,len(seams)); rel=[]
    for s in seams:
     rs=s['related_tests']; assert len(rs)==1 and rs[0]['name']==c['name'],(i,rs); v=rs[0]['relation_reason'];rel.append(v)
     if c['relation'] is not None and v!=c['relation'] or c['relation'] is None and v in ['helper_owner_call','direct_owner_call']:violations.append([i,fmt,v,c['relation']])
    report['relations']=rel;report['metrics']=data['metrics']
   elif fmt=='repo-exposure-summary-json':
    m=data['metrics']; assert m['raw_seams']==full['metrics']['seams_total'];assert all(full['metrics'][k]==v for k,v in m['grip_class'].items()),i;report['metrics']=m
   else:
    assert len(data['findings'])==2,(i,len(data['findings']));rel=[]
    for f in data['findings']:
     assert f['related_tests'] and all(t['name']==c['name'] for t in f['related_tests']);rel.extend(t['relation_reason'] for t in f['related_tests'])
    if c['relation'] is None and any(r in ['direct_owner_call','helper_owner_call'] for r in rel):violations.append([i,fmt,rel,None])
    if c['relation']=='direct_owner_call' and any(r!='direct_owner_call' for r in rel):violations.append([i,fmt,rel,c['relation']])
    report['relations']=rel
   row['reports'].append(report)
 results.append(row);(E/mode/'results.json').write_text(json.dumps(results,indent=2));(E/mode/'violations.json').write_text(json.dumps(violations,indent=2));print(i,c['path'],flush=True)
print(json.dumps(dict(cases=len(cases),violations=violations)));assert not violations
