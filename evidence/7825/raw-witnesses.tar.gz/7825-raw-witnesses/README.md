# Raw witnesses for EffortlessMetrics/ripr-swarm#7825

These are the retained raw outputs, syscall traces, measurement receipts, and focused validation logs for the sample-output CLI fixture change. They preserve the previously local evidence needed to audit the published measurements and exact-read proof.

Identities: original base `4ad9553adc77ef63f6cb8a134d0cfc30ce638158`; published candidate `54e73e4b0fde7297203fb42a729e4ce621514e0c` with tree `c9f068b2a1340a06a3572768e66f31c5b68f17c6`; current main at integration start `bbdbae9332828ceb2729f6238fa5465164b6c267`. The same measured CLI bytes were used before and after (SHA-256 `dde62baeabd0afedae2c9ef2d87a4bef648564e66331bda80e344eea394c31c3`).

`witnesses/` contains six family outputs per before/fixture/grown subject, plus all 18 traced family runs. Root files retain the measurements JSON, build-selection receipts, process/read-checker and fixture/oracle validation output, the final focused identity, and final precommit-v2 receipt. `sibling-descriptor-control.trace` is the valid physical-FD sibling-root substitution used to test checker discrimination.

The archive intentionally excludes the measured CLI executable, compiled checker binaries, build targets, private analysis caches, and temporary fixture state. The source checker and measurement interpretation are in the published PR at https://github.com/EffortlessMetrics/ripr-swarm/pull/7923.
